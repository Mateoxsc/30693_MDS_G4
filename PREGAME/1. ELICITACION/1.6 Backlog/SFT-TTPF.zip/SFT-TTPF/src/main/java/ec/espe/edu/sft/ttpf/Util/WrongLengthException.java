package ec.espe.edu.sft.ttpf.Util;

public class WrongLengthException extends Exception {
    
    public WrongLengthException(String message) {
        super(message);
    }    
}
