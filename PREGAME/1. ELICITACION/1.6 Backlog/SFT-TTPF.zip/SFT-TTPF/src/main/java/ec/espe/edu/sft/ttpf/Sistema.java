package ec.espe.edu.sft.ttpf;

import ec.espe.edu.sft.ttpf.Util.MensajesSistema;
import ec.espe.edu.sft.ttpf.Util.TituloVentanas;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;

public class Sistema {

    private JFrame ventanaAdministrador;
    private JFrame ventanaIniciarSesion;
    private JFrame ventnaEmpleado;
    private JTextField campoTextoUsuario;
    private JPasswordField campoTextoContrasenia;

    public void iniciar() {
        ventanaIniciarSesion = new JFrame("Inciar Sesion");
        ventanaIniciarSesion.setSize(385, 350);
        ventanaIniciarSesion.setLayout(new GridLayout(4, 1));

        Color colorVentana = new Color(230, 240, 255);
        ventanaIniciarSesion.getContentPane().setBackground(colorVentana);

        JPanel panelBienvenido = new JPanel(new GridLayout(1, 1));
        JPanel panelUsuario = new JPanel(new GridLayout(1, 2));
        JPanel panelContrasenia = new JPanel(new GridLayout(1, 2));
        JPanel panelSesion = new JPanel(new FlowLayout(FlowLayout.CENTER));

        panelBienvenido.setBackground(colorVentana);
        panelUsuario.setBackground(colorVentana);
        panelContrasenia.setBackground(colorVentana);
        panelSesion.setBackground(colorVentana);

        JLabel etiquetaBienvenida = new JLabel("Bienvenido", JLabel.CENTER);
        JLabel etiquetaUsuario = new JLabel("Usuario", JLabel.CENTER);
        JLabel etiquetaContrasenia = new JLabel("Contraseña", JLabel.CENTER);

        campoTextoUsuario = new JTextField();
        campoTextoUsuario.setPreferredSize(new Dimension(150, 25));
        campoTextoUsuario.setHorizontalAlignment(JLabel.CENTER);

        campoTextoContrasenia = new JPasswordField();
        campoTextoContrasenia.setPreferredSize(new Dimension(150, 25));
        campoTextoContrasenia.setHorizontalAlignment(JLabel.CENTER);

        JButton botonInicarSesion = new JButton("Iniciar Sesion");
        botonInicarSesion.setPreferredSize(new Dimension(160, 65));
        botonInicarSesion.setHorizontalAlignment(JLabel.CENTER);
        botonInicarSesion.setBackground(new Color(100, 150, 255));
        botonInicarSesion.setForeground(Color.WHITE);

        botonInicarSesion.addActionListener(e -> {
            String usuario = campoTextoUsuario.getText();
            String contrasenia = new String(campoTextoContrasenia.getPassword());
            validacionLoggin(usuario, contrasenia);
        });

        panelBienvenido.add(etiquetaBienvenida);
        panelUsuario.add(etiquetaUsuario);
        panelUsuario.add(this.campoTextoUsuario);
        panelContrasenia.add(etiquetaContrasenia);
        panelContrasenia.add(this.campoTextoContrasenia);
        panelSesion.add(botonInicarSesion);

        this.ventanaIniciarSesion.add(panelBienvenido);
        this.ventanaIniciarSesion.add(panelUsuario);
        this.ventanaIniciarSesion.add(panelContrasenia);
        this.ventanaIniciarSesion.add(panelSesion);
        this.ventanaIniciarSesion.setVisible(true);

    }

    private void ventanaAdmin() {
        ventanaAdministrador = new JFrame("Ventana Administrador");
        ventanaAdministrador.setSize(600, 500);

        this.ventanaAdministrador.setVisible(true);

    }

    private void validacionLoggin(String usuario, String contrasenia) {
        try {
            if (usuario == null || usuario.isBlank() || contrasenia == null || contrasenia.isBlank()) {
                JOptionPane.showMessageDialog(null, MensajesSistema.ERROR_CAMPOS_VACIOS, TituloVentanas.VENTANA_ADVERTENCIA,
                        JOptionPane.WARNING_MESSAGE);
                return;
            }

            if (usuario.equals("MERYADMIN") && contrasenia.equals("ADMINISTRADOR_2003*")) {
                JOptionPane.showMessageDialog(null, MensajesSistema.EXITO_LOGGIN, TituloVentanas.VENTANA_INICIO, JOptionPane.INFORMATION_MESSAGE);
                ventanaAdmin();
                ventanaIniciarSesion.dispose();
            } else {
                JOptionPane.showMessageDialog(null, MensajesSistema.ERROR_USUARIO_O_CONTRASENIA, TituloVentanas.VENTANA_ERROR, JOptionPane.ERROR_MESSAGE);
                return;
            }

        } catch (Exception ex) {
            JOptionPane.showMessageDialog(null, MensajesSistema.ERROR_DESCONOCIDO_LOGGIN, TituloVentanas.VENTANA_ERROR, JOptionPane.ERROR_MESSAGE);
        }
    }
}
