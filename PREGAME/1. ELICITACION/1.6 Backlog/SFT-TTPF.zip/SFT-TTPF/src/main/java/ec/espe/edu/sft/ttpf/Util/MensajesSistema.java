package ec.espe.edu.sft.ttpf.Util;

public class MensajesSistema {

    public MensajesSistema() {
    }
    
    ////////Mensajes Error///////////
    public static final String ERROR_USUARIO_O_CONTRASENIA = "Usuario y contraseña incorrectos";
     public static final String ERROR_CAMPOS_VACIOS= "Los campos no pueden estar vacios";
    public static final String ERROR_DESCONOCIDO_LOGGIN = "Error iniciar sesion";
    
    
    
    //////Mensajes EXITO///////////
    
    public static final String EXITO_LOGGIN = "Sesion Iniciada con exito";
    
    //////Mensajes Info//////////////


}
