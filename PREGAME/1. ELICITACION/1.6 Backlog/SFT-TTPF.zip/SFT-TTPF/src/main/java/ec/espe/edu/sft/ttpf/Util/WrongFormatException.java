package ec.espe.edu.sft.ttpf.Util;

public class WrongFormatException extends Exception {
    
    public WrongFormatException(String message) {
        super(message);
    }   
}
