package ec.espe.edu.sft.ttpf.Util;

class CedulaValidationException extends Exception {

    public CedulaValidationException(String message) {
        super(message);
    }
}
