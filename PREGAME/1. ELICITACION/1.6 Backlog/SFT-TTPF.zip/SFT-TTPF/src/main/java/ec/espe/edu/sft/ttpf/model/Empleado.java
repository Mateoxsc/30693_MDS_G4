package ec.espe.edu.sft.ttpf.model;

public class Empleado {

    private int idEmpleado;
    private static int idActual = 0;
    private String nombre;
    private String apellido;
    private String sucursal;
    private String usuario;
    private String contrasenia;

    public Empleado(String nombre, String apellido, String sucursal, String usuario, String contrasenia) {
        this.idEmpleado = idActual++;
        this.nombre = nombre;
        this.apellido = apellido;
        this.sucursal = sucursal;
        this.usuario = usuario;
        this.contrasenia = contrasenia;
    }

    public int getIdEmpleado() {
        return idEmpleado;
    }

    public String getNombre() {
        return nombre;
    }

    public String getApellido() {
        return apellido;
    }

    public String getSucursal() {
        return sucursal;
    }

    public String getUsuario() {
        return usuario;
    }

    public String getContrasenia() {
        return contrasenia;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public void setApellido(String apellido) {
        this.apellido = apellido;
    }

    public void setSucursal(String sucursal) {
        this.sucursal = sucursal;
    }

    public void setUsuario(String usuario) {
        this.usuario = usuario;
    }

    public void setContrasenia(String contrasenia) {
        this.contrasenia = contrasenia;
    }

}
