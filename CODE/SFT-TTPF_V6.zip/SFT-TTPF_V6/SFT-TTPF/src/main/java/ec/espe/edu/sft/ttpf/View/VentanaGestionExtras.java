package ec.espe.edu.sft.ttpf.View;

import ec.espe.edu.sft.ttpf.model.Extra;
import java.awt.*;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;

public class VentanaGestionExtras extends JFrame {

    private JTable tablaExtras;
    private DefaultTableModel modeloTablaExtras;
    private JButton botonRegistrarExtra;
    private JButton botonEditarExtra;
    private JButton botonBuscarExtra;
    private JButton botonEliminarExtra;
    private JButton botonRegresar;

    private final Color colorFondoBase = new Color(245, 230, 226);
    private final Color colorTarjetaBlanca = new Color(253, 246, 244);
    private final Color colorAzulBotones = new Color(134, 203, 233);
    private final Color colorSalmonTitulo = new Color(246, 187, 142);
    private final Color colorRosaRegresar = new Color(243, 151, 151);
    private final Color colorTextoEstilo = new Color(84, 72, 70);
    private final Color colorBordeInterno = new Color(230, 212, 207);

    private final Font fuentePrincipal = new Font("Segoe UI", Font.BOLD, 17);
    private final Font fuenteBotones = new Font("Segoe UI", Font.BOLD, 13);
    private final Font fuenteLabels = new Font("Segoe UI", Font.BOLD, 13);
    private final Font fuenteCampos = new Font("Segoe UI", Font.PLAIN, 13);
    private final Font fuenteTablas = new Font("SansSerif", Font.PLAIN, 13);

    public VentanaGestionExtras() {
        setTitle("Gestión de Artículos Extras");
        setSize(1075, 600);
        setLayout(new BorderLayout());
        getContentPane().setBackground(colorFondoBase);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        String[] columnas = {"ID Extra", "Artículo Extra", "Precio Adicional"};
        modeloTablaExtras = new DefaultTableModel(columnas, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        this.tablaExtras = new JTable(modeloTablaExtras);

        this.tablaExtras.setFont(fuenteTablas);
        this.tablaExtras.setForeground(colorTextoEstilo);
        this.tablaExtras.setRowHeight(28);
        this.tablaExtras.setGridColor(colorBordeInterno);
        this.tablaExtras.setSelectionBackground(new Color(205, 233, 245));
        this.tablaExtras.setSelectionForeground(colorTextoEstilo);

        this.tablaExtras.getTableHeader().setFont(fuenteBotones);
        this.tablaExtras.getTableHeader().setBackground(colorAzulBotones);
        this.tablaExtras.getTableHeader().setForeground(colorTextoEstilo);
        this.tablaExtras.getTableHeader().setReorderingAllowed(false);
        this.tablaExtras.getTableHeader().setBorder(BorderFactory.createLineBorder(colorAzulBotones));

        JScrollPane scrollTabla = new JScrollPane(this.tablaExtras);
        scrollTabla.setBorder(BorderFactory.createLineBorder(colorBordeInterno, 1));
        scrollTabla.getViewport().setBackground(colorTarjetaBlanca);

        JPanel panelEncabezado = new JPanel(new FlowLayout(FlowLayout.CENTER, 0, 15));
        panelEncabezado.setBackground(colorFondoBase);

        JPanel panelTablaExtras = new JPanel(new BorderLayout());
        panelTablaExtras.setBackground(colorTarjetaBlanca);
        panelTablaExtras.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createEmptyBorder(5, 25, 5, 25),
                BorderFactory.createEmptyBorder(15, 15, 15, 15)
        ));

        JPanel panelBotones = new JPanel(new FlowLayout(FlowLayout.CENTER, 15, 20));
        panelBotones.setBackground(colorFondoBase);

        JLabel etiquetaBienvenidaMenu = new JLabel("PANEL DE GESTIÓN DE ARTÍCULOS EXTRAS", JLabel.CENTER);
        etiquetaBienvenidaMenu.setFont(fuentePrincipal);
        etiquetaBienvenidaMenu.setForeground(colorTextoEstilo);

        JLabel etiquetaTablaDeExtras = new JLabel("  CATÁLOGO DE ELEMENTOS ADICIONALES CONFIGURADOS  ", JLabel.CENTER);
        etiquetaTablaDeExtras.setFont(fuenteBotones);
        etiquetaTablaDeExtras.setForeground(colorTextoEstilo);
        etiquetaTablaDeExtras.setOpaque(true);
        etiquetaTablaDeExtras.setBackground(colorSalmonTitulo);
        etiquetaTablaDeExtras.setBorder(BorderFactory.createLineBorder(colorSalmonTitulo, 4, true));

        JPanel panelContenedorTituloTabla = new JPanel(new FlowLayout(FlowLayout.LEFT, 0, 8));
        panelContenedorTituloTabla.setBackground(colorTarjetaBlanca);
        panelContenedorTituloTabla.add(etiquetaTablaDeExtras);

        Dimension tamanoBotones = new Dimension(185, 42);

        botonRegistrarExtra = new JButton("Registrar Extra");
        configurarBoton(botonRegistrarExtra, colorAzulBotones, colorTextoEstilo, fuenteBotones, tamanoBotones);

        botonEditarExtra = new JButton("Editar Extra");
        configurarBoton(botonEditarExtra, colorAzulBotones, colorTextoEstilo, fuenteBotones, tamanoBotones);

        botonBuscarExtra = new JButton("Buscar Extra");
        configurarBoton(botonBuscarExtra, colorAzulBotones, colorTextoEstilo, fuenteBotones, tamanoBotones);

        botonEliminarExtra = new JButton("Eliminar Extra");
        configurarBoton(botonEliminarExtra, colorAzulBotones, colorTextoEstilo, fuenteBotones, tamanoBotones);

        botonRegresar = new JButton("Regresar al Menú");
        configurarBoton(botonRegresar, colorRosaRegresar, colorTextoEstilo, fuenteBotones, tamanoBotones);

        panelEncabezado.add(etiquetaBienvenidaMenu);

        panelTablaExtras.add(panelContenedorTituloTabla, BorderLayout.NORTH);
        panelTablaExtras.add(scrollTabla, BorderLayout.CENTER);

        panelBotones.add(botonRegistrarExtra);
        panelBotones.add(botonEditarExtra);
        panelBotones.add(botonBuscarExtra);
        panelBotones.add(botonEliminarExtra);
        panelBotones.add(botonRegresar);

        add(panelEncabezado, BorderLayout.NORTH);
        add(panelTablaExtras, BorderLayout.CENTER);
        add(panelBotones, BorderLayout.SOUTH);

        setLocationRelativeTo(null);
    }

    private void configurarBoton(JButton btn, Color fondo, Color texto, Font fuente, Dimension tamano) {
        btn.setPreferredSize(tamano);
        btn.setFont(fuente);
        btn.setBackground(fondo);
        btn.setForeground(texto);
        btn.setFocusPainted(false);
        btn.setBorder(BorderFactory.createLineBorder(fondo.darker(), 1, true));
    }

    public String solicitarId(String mensaje, String titulo) {
        return JOptionPane.showInputDialog(this, mensaje, titulo, JOptionPane.QUESTION_MESSAGE);
    }

    public void mostrarMensajeError(String mensaje, String titulo) {
        JOptionPane.showMessageDialog(this, mensaje, titulo, JOptionPane.ERROR_MESSAGE);
    }

    public void mostrarMensajeInformativo(String mensaje, String titulo) {
        JOptionPane.showMessageDialog(this, mensaje, titulo, JOptionPane.INFORMATION_MESSAGE);
    }

    public void mostrarDetalleExtra(Extra ex) {
        JPanel panelInfo = crearPanelContenedorEstilizado(new GridLayout(3, 1, 5, 5));
        panelInfo.add(crearLabelEstilizado("Código de Artículo: " + ex.getIdExtra()));
        panelInfo.add(crearLabelEstilizado("Descripción/Nombre: " + ex.getArticuloExtra()));
        panelInfo.add(crearLabelEstilizado("Precio Unitario: $" + ex.getPrecioExtra()));

        JOptionPane.showMessageDialog(this, panelInfo, "Información del Artículo Extra Encontrado", JOptionPane.INFORMATION_MESSAGE);
    }

    public int confirmarEliminacion(Extra ex) {
        JPanel panelConfirmacion = crearPanelContenedorEstilizado(new GridLayout(3, 1, 4, 4));
        panelConfirmacion.add(crearLabelEstilizado("¿Está seguro de que desea eliminar el siguiente artículo extra?"));
        panelConfirmacion.add(crearLabelEstilizado("• ID: " + ex.getIdExtra() + " | Artículo: " + ex.getArticuloExtra() + " | Precio: $" + ex.getPrecioExtra()));
        panelConfirmacion.add(new JLabel(" "));

        return JOptionPane.showConfirmDialog(this, panelConfirmacion, "Confirmar Eliminación", JOptionPane.YES_NO_OPTION, JOptionPane.WARNING_MESSAGE);
    }

    public Object[] mostrarFormularioExtra(Extra ex) {
        boolean esEdicion = (ex != null);

        JTextField txtArticulo = configurarCampoTexto(new JTextField(esEdicion ? ex.getArticuloExtra() : ""));
        JTextField txtPrecio = configurarCampoTexto(new JTextField(esEdicion ? String.valueOf(ex.getPrecioExtra()) : ""));

        JPanel panelForm = crearPanelContenedorEstilizado(new GridBagLayout());
        panelForm.setPreferredSize(new Dimension(450, 110));

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(8, 8, 8, 8);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.weightx = 0.0; 
        panelForm.add(crearLabelEstilizado("Artículo Extra:"), gbc);

        gbc.gridx = 1;
        gbc.weightx = 1.0; 
        panelForm.add(txtArticulo, gbc);

        gbc.gridx = 0;
        gbc.gridy = 1;
        gbc.weightx = 0.0;
        panelForm.add(crearLabelEstilizado("Precio Extra ($):"), gbc);

        gbc.gridx = 1;
        gbc.weightx = 1.0;
        panelForm.add(txtPrecio, gbc);

        String titulo = esEdicion ? "Modificar Extra N° " + ex.getIdExtra() : "Registrar Nuevo Artículo Extra";
        int resultado = JOptionPane.showConfirmDialog(this, panelForm, titulo, JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);

        if (resultado == JOptionPane.OK_OPTION) {
            return new Object[]{
                txtArticulo.getText().trim(),
                txtPrecio.getText().trim()
            };
        }
        return null;
    }

    private JPanel crearPanelContenedorEstilizado(LayoutManager layout) {
        JPanel panel = new JPanel(layout);
        panel.setBackground(colorTarjetaBlanca);
        panel.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(colorFondoBase, 2, true),
                BorderFactory.createEmptyBorder(15, 15, 15, 15)
        ));
        return panel;
    }

    private JLabel crearLabelEstilizado(String texto) {
        JLabel label = new JLabel(texto);
        label.setFont(fuenteLabels);
        label.setForeground(colorTextoEstilo);
        return label;
    }

    private JTextField configurarCampoTexto(JTextField campo) {
        campo.setFont(fuenteCampos);
        campo.setForeground(colorTextoEstilo);
        campo.setBackground(Color.WHITE);
        campo.setCaretColor(colorTextoEstilo);
        campo.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(colorFondoBase, 1, true),
                BorderFactory.createEmptyBorder(4, 6, 4, 6)
        ));
        return campo;
    }

    public JTable getTablaExtras() {
        return tablaExtras;
    }

    public DefaultTableModel getModeloTablaExtras() {
        return modeloTablaExtras;
    }

    public JButton getBotonRegistrarExtra() {
        return botonRegistrarExtra;
    }

    public JButton getBotonEditarExtra() {
        return botonEditarExtra;
    }

    public JButton getBotonBuscarExtra() {
        return botonBuscarExtra;
    }

    public JButton getBotonEliminarExtra() {
        return botonEliminarExtra;
    }

    public JButton getBotonRegresar() {
        return botonRegresar;
    }
}
