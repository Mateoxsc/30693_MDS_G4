package ec.espe.edu.sft.ttpf.View;

import java.awt.*;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;

public class VentanaGestionClientes extends JFrame {

    private JTextField campoTextoCedulaCliente;
    private JTextField campoTextoNombreCliente;
    private JTextField campoTextoApellidoCliente;
    private JTextField campoTextoContactoCliente;

    private JButton botonAgregar;
    private JButton botonEditar;
    private JButton botonEliminar;
    private JButton botonBuscar;
    private JButton botonRegresarMenu;

    private JTable tablaClientes;
    private DefaultTableModel modeloTablaClientes;

    private final Color colorFondoBase = new Color(245, 230, 226);
    private final Color colorTarjetaBlanca = new Color(253, 246, 244);
    private final Color colorAzulBotones = new Color(134, 203, 233);
    private final Color colorRosaSalir = new Color(243, 151, 151);
    private final Color colorTextoEstilo = new Color(84, 72, 70);
    private final Color colorBordeInterno = new Color(230, 212, 207);

    private final Font fuenteLabels = new Font("Segoe UI", Font.BOLD, 12);
    private final Font fuenteCampos = new Font("Segoe UI", Font.PLAIN, 13);
    private final Font fuenteBotones = new Font("Segoe UI", Font.BOLD, 13);
    private final Font fuenteTablas = new Font("SansSerif", Font.PLAIN, 13);
    private final Font fuenteTitulado = new Font("Segoe UI", Font.BOLD, 14);

    public VentanaGestionClientes() {
        setTitle("Gestionar Clientes");
        setSize(1200, 650);
        setLayout(new BorderLayout());
        getContentPane().setBackground(colorFondoBase);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        JPanel panelDatos = new JPanel(new GridLayout(2, 4, 12, 12));
        panelDatos.setBackground(colorTarjetaBlanca);
        panelDatos.setPreferredSize(new Dimension(750, 110));

        javax.swing.border.TitledBorder bordeTitulo = javax.swing.BorderFactory.createTitledBorder(
                javax.swing.BorderFactory.createLineBorder(colorBordeInterno, 1, true), " Datos del Cliente "
        );
        bordeTitulo.setTitleFont(fuenteTitulado);
        bordeTitulo.setTitleColor(colorTextoEstilo);
        panelDatos.setBorder(bordeTitulo);

        JLabel lblCedula = new JLabel("  Cédula:");
        lblCedula.setFont(fuenteLabels);
        lblCedula.setForeground(colorTextoEstilo);
        panelDatos.add(lblCedula);
        campoTextoCedulaCliente = new JTextField();
        campoTextoCedulaCliente.setFont(fuenteCampos);
        campoTextoCedulaCliente.setForeground(colorTextoEstilo);
        panelDatos.add(campoTextoCedulaCliente);

        JLabel lblNombre = new JLabel("  Nombre:");
        lblNombre.setFont(fuenteLabels);
        lblNombre.setForeground(colorTextoEstilo);
        panelDatos.add(lblNombre);
        campoTextoNombreCliente = new JTextField();
        campoTextoNombreCliente.setFont(fuenteCampos);
        campoTextoNombreCliente.setForeground(colorTextoEstilo);
        panelDatos.add(campoTextoNombreCliente);

        JLabel lblApellido = new JLabel("  Apellido:");
        lblApellido.setFont(fuenteLabels);
        lblApellido.setForeground(colorTextoEstilo);
        panelDatos.add(lblApellido);
        campoTextoApellidoCliente = new JTextField();
        campoTextoApellidoCliente.setFont(fuenteCampos);
        campoTextoApellidoCliente.setForeground(colorTextoEstilo);
        panelDatos.add(campoTextoApellidoCliente);

        JLabel lblContacto = new JLabel("  Contacto:");
        lblContacto.setFont(fuenteLabels);
        lblContacto.setForeground(colorTextoEstilo);
        panelDatos.add(lblContacto);
        campoTextoContactoCliente = new JTextField();
        campoTextoContactoCliente.setFont(fuenteCampos);
        campoTextoContactoCliente.setForeground(colorTextoEstilo);
        panelDatos.add(campoTextoContactoCliente);

        JPanel panelBotones = new JPanel(new FlowLayout(FlowLayout.CENTER, 12, 15));
        panelBotones.setBackground(colorFondoBase);

        Dimension tamanoBotones = new Dimension(175, 40);

        botonAgregar = new JButton("Agregar Cliente");
        botonAgregar.setPreferredSize(tamanoBotones);
        botonAgregar.setFont(fuenteBotones);
        botonAgregar.setBackground(colorAzulBotones);
        botonAgregar.setForeground(colorTextoEstilo);
        botonAgregar.setFocusPainted(false);
        botonAgregar.setBorder(javax.swing.BorderFactory.createLineBorder(colorAzulBotones.darker(), 1, true));

        botonBuscar = new JButton("Buscar Cliente");
        botonBuscar.setPreferredSize(tamanoBotones);
        botonBuscar.setFont(fuenteBotones);
        botonBuscar.setBackground(colorAzulBotones);
        botonBuscar.setForeground(colorTextoEstilo);
        botonBuscar.setFocusPainted(false);
        botonBuscar.setBorder(javax.swing.BorderFactory.createLineBorder(colorAzulBotones.darker(), 1, true));

        botonEditar = new JButton("Editar Info. Cliente");
        botonEditar.setPreferredSize(tamanoBotones);
        botonEditar.setFont(fuenteBotones);
        botonEditar.setBackground(colorAzulBotones);
        botonEditar.setForeground(colorTextoEstilo);
        botonEditar.setFocusPainted(false);
        botonEditar.setBorder(javax.swing.BorderFactory.createLineBorder(colorAzulBotones.darker(), 1, true));

        botonEliminar = new JButton("Eliminar Cliente");
        botonEliminar.setPreferredSize(tamanoBotones);
        botonEliminar.setFont(fuenteBotones);
        botonEliminar.setBackground(colorAzulBotones);
        botonEliminar.setForeground(colorTextoEstilo);
        botonEliminar.setFocusPainted(false);
        botonEliminar.setBorder(javax.swing.BorderFactory.createLineBorder(colorAzulBotones.darker(), 1, true));

        botonRegresarMenu = new JButton("Regresar al menú");
        botonRegresarMenu.setPreferredSize(tamanoBotones);
        botonRegresarMenu.setFont(fuenteBotones);
        botonRegresarMenu.setBackground(colorRosaSalir);
        botonRegresarMenu.setForeground(colorTextoEstilo);
        botonRegresarMenu.setFocusPainted(false);
        botonRegresarMenu.setBorder(javax.swing.BorderFactory.createLineBorder(colorRosaSalir.darker(), 1, true));

        panelBotones.add(botonAgregar);
        panelBotones.add(botonBuscar);
        panelBotones.add(botonEditar);
        panelBotones.add(botonEliminar);
        panelBotones.add(botonRegresarMenu);

        JPanel panelSuperior = new JPanel(new BorderLayout());
        panelSuperior.setBackground(colorFondoBase);
        panelSuperior.setBorder(javax.swing.BorderFactory.createEmptyBorder(15, 20, 5, 20));
        panelSuperior.add(panelDatos, BorderLayout.CENTER);
        panelSuperior.add(panelBotones, BorderLayout.SOUTH);

        String[] columnas = {"Cédula", "Nombre", "Apellido", "Contacto"};
        modeloTablaClientes = new DefaultTableModel(columnas, 0);
        tablaClientes = new JTable(modeloTablaClientes);

        tablaClientes.setFont(fuenteTablas);
        tablaClientes.setForeground(colorTextoEstilo);
        tablaClientes.setRowHeight(28);
        tablaClientes.setGridColor(colorBordeInterno);
        tablaClientes.setSelectionBackground(new java.awt.Color(205, 233, 245));
        tablaClientes.setSelectionForeground(colorTextoEstilo);

        tablaClientes.getTableHeader().setFont(fuenteBotones);
        tablaClientes.getTableHeader().setBackground(colorAzulBotones);
        tablaClientes.getTableHeader().setForeground(colorTextoEstilo);
        tablaClientes.getTableHeader().setReorderingAllowed(false);
        tablaClientes.getTableHeader().setBorder(javax.swing.BorderFactory.createLineBorder(colorAzulBotones));

        JScrollPane scrollPane = new JScrollPane(tablaClientes);
        scrollPane.setBorder(javax.swing.BorderFactory.createCompoundBorder(
                javax.swing.BorderFactory.createEmptyBorder(10, 20, 20, 20),
                javax.swing.BorderFactory.createLineBorder(colorBordeInterno, 1)
        ));
        scrollPane.getViewport().setBackground(colorTarjetaBlanca);

        add(panelSuperior, BorderLayout.NORTH);
        add(scrollPane, BorderLayout.CENTER);

        setLocationRelativeTo(null);
    }

    public JDialog crearFormularioEditar(String nombreAct, String apellidoAct, String contactoAct, JTextField txtNom, JTextField txtApe, JTextField txtCon, JButton btnG, JButton btnS) {
        JDialog formulario = new JDialog(this, "Formulario de Edición", true);
        formulario.setSize(380, 250);
        formulario.setLocationRelativeTo(this);
        formulario.getContentPane().setBackground(colorFondoBase);
        formulario.setLayout(new GridLayout(5, 2, 10, 10));
        ((JPanel) formulario.getContentPane()).setBorder(javax.swing.BorderFactory.createEmptyBorder(15, 15, 15, 15));

        txtNom.setText(nombreAct);
        txtNom.setFont(fuenteCampos);
        txtNom.setForeground(colorTextoEstilo);

        txtApe.setText(apellidoAct);
        txtApe.setFont(fuenteCampos);
        txtApe.setForeground(colorTextoEstilo);

        txtCon.setText(contactoAct);
        txtCon.setFont(fuenteCampos);
        txtCon.setForeground(colorTextoEstilo);

        JLabel lblN = new JLabel("  Nombre:");
        lblN.setFont(fuenteLabels);
        lblN.setForeground(colorTextoEstilo);
        JLabel lblA = new JLabel("  Apellido:");
        lblA.setFont(fuenteLabels);
        lblA.setForeground(colorTextoEstilo);
        JLabel lblC = new JLabel("  Contacto:");
        lblC.setFont(fuenteLabels);
        lblC.setForeground(colorTextoEstilo);

        btnG.setFont(fuenteBotones);
        btnG.setBackground(colorAzulBotones);
        btnG.setForeground(colorTextoEstilo);
        btnG.setFocusPainted(false);
        btnG.setBorder(javax.swing.BorderFactory.createLineBorder(colorAzulBotones.darker(), 1, true));

        btnS.setFont(fuenteBotones);
        btnS.setBackground(colorRosaSalir);
        btnS.setForeground(colorTextoEstilo);
        btnS.setFocusPainted(false);
        btnS.setBorder(javax.swing.BorderFactory.createLineBorder(colorRosaSalir.darker(), 1, true));

        formulario.add(lblN);
        formulario.add(txtNom);
        formulario.add(lblA);
        formulario.add(txtApe);
        formulario.add(lblC);
        formulario.add(txtCon);
        formulario.add(btnG);
        formulario.add(btnS);

        return formulario;
    }

    public void configurarModoColaborador() {
        if (this.botonEliminar != null) {
            this.botonEliminar.setEnabled(false);
            this.botonEliminar.setVisible(false);
        }
        if (this.botonEditar != null) {
            this.botonEditar.setEnabled(false);
            this.botonEditar.setVisible(false);
        }
        if (this.tablaClientes != null) {
            this.tablaClientes.setDefaultEditor(Object.class, null);
        }
    }

    public JTextField getTxtCedulaCliente() {
        return campoTextoCedulaCliente;
    }

    public JTextField getTxtNombreCliente() {
        return campoTextoNombreCliente;
    }

    public JTextField getTxtApellidoCliente() {
        return campoTextoApellidoCliente;
    }

    public JTextField getTxtContactoCliente() {
        return campoTextoContactoCliente;
    }

    public JButton getBtnAgregar() {
        return botonAgregar;
    }

    public JButton getBtnBuscar() {
        return botonBuscar;
    }

    public JButton getBtnEditar() {
        return botonEditar;
    }

    public JButton getBtnEliminar() {
        return botonEliminar;
    }

    public JButton getBtnRegresar() {
        return botonRegresarMenu;
    }

    public JTable getTablaClientes() {
        return tablaClientes;
    }

    public DefaultTableModel getModeloTablaClientes() {
        return modeloTablaClientes;
    }
}
