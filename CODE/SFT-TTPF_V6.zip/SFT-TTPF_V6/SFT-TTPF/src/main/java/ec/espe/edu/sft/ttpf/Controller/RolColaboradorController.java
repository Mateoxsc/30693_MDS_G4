package ec.espe.edu.sft.ttpf.controller;

import ec.espe.edu.sft.ttpf.View.VentanaColaborador;
import ec.espe.edu.sft.ttpf.View.VentanaGestionClientes;
import javax.swing.JFrame;

public class RolColaboradorController {

    private final VentanaColaborador vista;
    private final JFrame vistaPadre;

    public RolColaboradorController(VentanaColaborador vista, JFrame vistaPadre) {
        this.vista = vista;
        this.vistaPadre = vistaPadre;
        inicializarEventos();
    }

    private void inicializarEventos() {
        this.vista.getBotonGestionClientes().addActionListener(e -> {
            VentanaGestionClientes vClientes = new VentanaGestionClientes();

            vClientes.configurarModoColaborador();

            if (this.vistaPadre instanceof ec.espe.edu.sft.ttpf.View.VentanaIniciarSesion) {
                this.vista.setVisible(false);

                new ClientesController(vClientes, this.vista);

                vClientes.setVisible(true);
            }
        });

        this.vista.getBotonGestionReservas().addActionListener(e -> {
            JFrame ventanaReservasBlanca = new JFrame("Gestión de Reservas - Sección Colaborador");
            ventanaReservasBlanca.setSize(600, 400);
            ventanaReservasBlanca.setLocationRelativeTo(vista);
            ventanaReservasBlanca.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

            javax.swing.JLabel mensaje = new javax.swing.JLabel("Módulo de reservas (Espacio en blanco para desarrollo futuro)", javax.swing.JLabel.CENTER);
            ventanaReservasBlanca.add(mensaje);

            ventanaReservasBlanca.setVisible(true);
        });

        this.vista.getBotonSalir().addActionListener(e -> {
            this.vista.dispose();
            if (this.vistaPadre != null) {
                this.vistaPadre.setVisible(true);
            }
        });
    }
}