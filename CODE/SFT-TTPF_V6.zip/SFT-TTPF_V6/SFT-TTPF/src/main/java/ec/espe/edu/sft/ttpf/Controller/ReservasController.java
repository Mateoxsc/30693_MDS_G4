package ec.espe.edu.sft.ttpf.controller;

import ec.espe.edu.sft.ttpf.View.VentanaGestionReservas;
import ec.espe.edu.sft.ttpf.View.VentanaAdministrador;

public class ReservasController {

    private VentanaGestionReservas vista;
    private VentanaAdministrador vAdminPadre;

    public ReservasController(VentanaGestionReservas vista, VentanaAdministrador vAdminPadre) {
        this.vista = vista;
        this.vAdminPadre = vAdminPadre;

        this.vista.getBtnRegresar().addActionListener(e -> {
            this.vista.dispose();
            if (this.vAdminPadre != null) {
                this.vAdminPadre.setVisible(true);
            }
        });
    }
}
