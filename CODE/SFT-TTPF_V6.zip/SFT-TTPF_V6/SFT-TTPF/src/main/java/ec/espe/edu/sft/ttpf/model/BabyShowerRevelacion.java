package ec.espe.edu.sft.ttpf.model;

public class BabyShowerRevelacion extends Evento {

    public BabyShowerRevelacion(String nombreEvento, String descripcionEvento, float precioEvento, String tipoEvento) {
        super(nombreEvento, descripcionEvento, precioEvento, tipoEvento);
    }

}
