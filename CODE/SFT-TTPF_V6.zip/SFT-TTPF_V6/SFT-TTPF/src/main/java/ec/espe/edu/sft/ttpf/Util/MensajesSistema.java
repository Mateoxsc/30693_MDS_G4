package ec.espe.edu.sft.ttpf.Util;

public class MensajesSistema {
  
    //////// Mensajes Error ///////////
    public static final String ERROR_USUARIO_O_CONTRASENIA = "Usuario o contraseña incorrectos";
    public static final String ERROR_CAMPOS_VACIOS = "Los campos no pueden estar vacios";
    public static final String ERROR_DESCONOCIDO_LOGGIN = "Error iniciar sesion";
    public static final String ERROR_SISTEMA_BLOQUEADO = "Sistema desbloqueado. Ya puede intentar iniciar sesión nuevamente.";
    public static final String ERROR_LIMITE_DE_INTENTOS_LOGGIN = "Ha superado el límite de intentos.\nEl sistema se ha bloqueado por 3 minutos.\nTiempo restante:";
    
    // --- NUEVOS MENSAJES DE ERROR (CRUD COLABORADORES) ---
    public static final String ERROR_CEDULA_INVALIDA = "La cédula ingresada no es válida.";
    public static final String ERROR_CEDULA_SOLO_NUMEROS = "La cédula debe contener únicamente números.";
    public static final String ERROR_CEDULA_DUPLICADA = "Error: Ya existe un colaborador registrado con esta Cédula.";
    public static final String ERROR_USUARIO_DUPLICADO = "Error: El nombre de usuario ingresado ya está en uso por otro colaborador.";

    ///////// Mensajes EXITO ///////////
    public static final String EXITO_LOGGIN = "Sesion Iniciada con exito";
    
    // --- NUEVOS MENSAJES DE ÉXITO (CRUD COLABORADORES) ---
    public static final String EXITO_COLABORADOR_AGREGADO = "Colaborador añadido correctamente.";
    public static final String EXITO_COLABORADOR_ELIMINADO = "Colaborador eliminado exitosamente.";

    ////// Mensajes Info / Advertencia /////////////
    public static final String INFO_INTENTOS_RESTANTES = "Número de intentos restantes";
    
    // --- NUEVOS MENSAJES DE INFO / ADVERTENCIA (CRUD COLABORADORES) ---
    public static final String ADVERTENCIA_COLABORADOR_NO_ENCONTRADO = "No se encontró ningún colaborador con la cédula proporcionada.";
    public static final String INFO_INGRESO_CEDULA_BUSCAR = "Ingrese la Cédula del colaborador a buscar:";
    public static final String INFO_INGRESO_CEDULA_ELIMINAR = "Ingrese la Cédula del colaborador a eliminar:";
    public static final String CONFIRMACION_ELIMINAR_COLABORADOR = "¿Está seguro de eliminar al colaborador con cédula: ";
}
