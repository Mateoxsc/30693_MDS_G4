package ec.espe.edu.sft.ttpf.controller;

import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import static com.mongodb.client.model.Filters.eq;
import com.mongodb.client.model.Updates;
import ec.espe.edu.sft.ttpf.Util.MongoConnection;
import ec.espe.edu.sft.ttpf.View.VentanaGestionEventos;
import ec.espe.edu.sft.ttpf.model.*;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import java.util.Optional;
import org.bson.Document;

public class EventosController {

    private final VentanaGestionEventos vista;
    private final JFrame vistaPadre;

    private final MongoCollection<Document> coleccionEventos;

    public EventosController(VentanaGestionEventos vista, JFrame vistaPadre) {
        this.vista = vista;
        this.vistaPadre = vistaPadre;

        MongoDatabase db = MongoConnection.getDatabase();
        this.coleccionEventos = db.getCollection("eventos");

        inicializarEventos();
        actualizarTabla();
    }

    private Optional<Evento> buscarPorId(int id) {
        Document doc = coleccionEventos.find(eq("idEvento", id)).first();
        if (doc == null) {
            return Optional.empty();
        }

        String tipoGrupo = doc.getString("tipoEvento");
        String nombre = doc.getString("nombreEvento");
        String descripcion = doc.getString("descripcionEvento");
        float precio = doc.getDouble("precioEvento").floatValue();

        Evento ev;
        switch (tipoGrupo) {
            case "Decoraciones":
                ev = new Decoracion(nombre, descripcion, precio, tipoGrupo);
                break;
            case "Fiestas infantiles":
                ev = new FiestaInfantil(nombre, descripcion, precio, tipoGrupo);
                break;
            case "Paquetes infantiles":
                ev = new PaqueteInfantil(nombre, descripcion, precio, tipoGrupo);
                break;
            case "Baby Shower/Revelacion":
                ev = new BabyShowerRevelacion(nombre, descripcion, precio, tipoGrupo);
                break;
            case "Paquetes Baby Shower Revelacion":
                ev = new PaqueteBabyShowerRevelacion(nombre, descripcion, precio, tipoGrupo);
                break;
            default:
                ev = new Evento(nombre, descripcion, precio, tipoGrupo);
                break;
        }
        ev.setIdEvento(doc.getInteger("idEvento"));
        return Optional.of(ev);
    }

    private void inicializarEventos() {
        this.vista.getBotonRegistrarEventos().addActionListener(e -> procesarFormulario(null));

        this.vista.getBotonEditarEvento().addActionListener(e -> {
            String idStr = vista.solicitarId("Ingrese el ID del evento que desea editar:", "Editar por ID");
            if (idStr == null || idStr.trim().isEmpty()) {
                return;
            }

            try {
                int id = Integer.parseInt(idStr.trim());
                Optional<Evento> eventoOpt = buscarPorId(id);

                if (eventoOpt.isPresent()) {
                    procesarFormulario(eventoOpt.get());
                } else {
                    vista.mostrarMensajeError("No se encontró ningún evento con el ID: " + id, "No encontrado");
                }
            } catch (NumberFormatException nfe) {
                vista.mostrarMensajeError("El ID ingresado debe ser un número entero válido.", "Error de formato");
            }
        });

        this.vista.getBotonBuscarEvento().addActionListener(e -> {
            String idStr = vista.solicitarId("Ingrese el ID del evento a buscar:", "Buscar por ID");
            if (idStr == null || idStr.trim().isEmpty()) {
                return;
            }

            try {
                int id = Integer.parseInt(idStr.trim());
                Optional<Evento> eventoOpt = buscarPorId(id);

                if (eventoOpt.isPresent()) {
                    Evento ev = eventoOpt.get();

                    for (int i = 0; i < vista.getTablaEventos().getRowCount(); i++) {
                        if ((int) vista.getTablaEventos().getValueAt(i, 0) == id) {
                            vista.getTablaEventos().setRowSelectionInterval(i, i);
                            break;
                        }
                    }

                    vista.mostrarDetalleEvento(ev);
                } else {
                    vista.mostrarMensajeInformativo("No existe un evento registrado con el ID especificado.", "Sin resultados");
                }
            } catch (NumberFormatException nfe) {
                vista.mostrarMensajeError("El ID debe ser numérico.", "Error");
            }
        });

        this.vista.getBotonEliminarEvento().addActionListener(e -> {
            String idStr = vista.solicitarId("Ingrese el ID del evento que desea eliminar:", "Eliminar por ID");
            if (idStr == null || idStr.trim().isEmpty()) {
                return;
            }

            try {
                int id = Integer.parseInt(idStr.trim());
                Optional<Evento> eventoOpt = buscarPorId(id);

                if (eventoOpt.isPresent()) {
                    Evento ev = eventoOpt.get();
                    int confirmacion = vista.confirmarEliminacion(ev);

                    if (confirmacion == JOptionPane.YES_OPTION) {
                        coleccionEventos.deleteOne(eq("idEvento", id));
                        actualizarTabla();
                        vista.mostrarMensajeInformativo("El evento ha sido eliminado correctamente.", "Éxito");
                    } else {
                        vista.mostrarMensajeInformativo("La eliminación del evento ha sido cancelada.", "Información");
                    }
                } else {
                    vista.mostrarMensajeError("No se encontró ningún evento con el ID proporcionado.", "Error");
                }
            } catch (NumberFormatException nfe) {
                vista.mostrarMensajeError("Formato incorrecto del ID.", "Error");
            }
        });

        this.vista.getBotonRegresar().addActionListener(e -> {
            this.vista.dispose();
            if (this.vistaPadre != null) {
                this.vistaPadre.setVisible(true);
            }
        });
    }

    private void procesarFormulario(Evento eventoExistente) {
        Object[] datos = vista.mostrarFormularioEvento(eventoExistente);
        if (datos == null) {
            return;
        }

        try {
            String nombre = (String) datos[0];
            float precio = Float.parseFloat((String) datos[1]);
            String descripcion = (String) datos[2];
            String tipoGrupo = (String) datos[3];

            if (nombre.isEmpty()) {
                throw new IllegalArgumentException("Campos vacíos detectados.");
            }

            if (eventoExistente != null) {
                coleccionEventos.updateOne(
                        eq("idEvento", eventoExistente.getIdEvento()),
                        Updates.combine(
                                Updates.set("nombreEvento", nombre),
                                Updates.set("precioEvento", (double) precio),
                                Updates.set("descripcionEvento", descripcion),
                                Updates.set("tipoEvento", tipoGrupo)
                        )
                );
                vista.mostrarMensajeInformativo("Evento actualizado con éxito.", "Éxito");
            } else {
                Evento nuevoEvento;
                switch (tipoGrupo) {
                    case "Decoraciones":
                        nuevoEvento = new Decoracion(nombre, descripcion, precio, tipoGrupo);
                        break;
                    case "Fiestas infantiles":
                        nuevoEvento = new FiestaInfantil(nombre, descripcion, precio, tipoGrupo);
                        break;
                    case "Paquetes infantiles":
                        nuevoEvento = new PaqueteInfantil(nombre, descripcion, precio, tipoGrupo);
                        break;
                    case "Baby Shower/Revelacion":
                        nuevoEvento = new BabyShowerRevelacion(nombre, descripcion, precio, tipoGrupo);
                        break;
                    case "Paquetes Baby Shower Revelacion":
                        nuevoEvento = new PaqueteBabyShowerRevelacion(nombre, descripcion, precio, tipoGrupo);
                        break;
                    default:
                        nuevoEvento = new Evento(nombre, descripcion, precio, tipoGrupo);
                        break;
                }

                int siguienteId = generarSiguienteId();
                nuevoEvento.setIdEvento(siguienteId);

                Document nuevoDoc = new Document("idEvento", nuevoEvento.getIdEvento())
                        .append("tipoEvento", nuevoEvento.getTipoEvento())
                        .append("nombreEvento", nuevoEvento.getNombreEvento())
                        .append("precioEvento", (double) nuevoEvento.getPrecioEvento())
                        .append("descripcionEvento", nuevoEvento.getDescripcionEvento());

                coleccionEventos.insertOne(nuevoDoc);
                vista.mostrarMensajeInformativo("Servicio del grupo '" + tipoGrupo + "' creado con éxito.", "Éxito");
            }
            actualizarTabla();
        } catch (Exception ex) {
            vista.mostrarMensajeError("Verifique que los campos no estén vacíos y el formato del precio sea correcto.", "Error en datos");
        }
    }

    private void actualizarTabla() {
        this.vista.getModeloTablaEventos().setRowCount(0);
        for (Document doc : coleccionEventos.find()) {
            Object[] fila = {
                doc.getInteger("idEvento"),
                doc.getString("tipoEvento"),
                doc.getString("nombreEvento"),
                doc.getDouble("precioEvento").floatValue(),
                doc.getString("descripcionEvento")
            };
            this.vista.getModeloTablaEventos().addRow(fila);
        }
    }

    private int generarSiguienteId() {
        Document maxDoc = coleccionEventos.find().sort(new Document("idEvento", -1)).first();
        if (maxDoc != null) {
            return maxDoc.getInteger("idEvento") + 1;
        }
        return 1;
    }
}
