package ec.espe.edu.sft.ttpf.controller;

import ec.espe.edu.sft.ttpf.View.VentanaAdministrador;
import ec.espe.edu.sft.ttpf.View.VentanaGestionColaboradores;
import ec.espe.edu.sft.ttpf.View.VentanaGestionClientes;
import ec.espe.edu.sft.ttpf.View.VentanaGestionReservas;
import ec.espe.edu.sft.ttpf.View.VentanaGestionEventos;
import ec.espe.edu.sft.ttpf.View.VentanaGestionExtras;
import ec.espe.edu.sft.ttpf.View.VentanaIniciarSesion;
import javax.swing.JFrame;

public class AdministradorController {

    private VentanaAdministrador vista;
    private JFrame ventanaIniciarSesion;

    public AdministradorController(VentanaAdministrador vista, JFrame ventanaIniciarSesion) {
        this.vista = vista;
        this.ventanaIniciarSesion = ventanaIniciarSesion;
        inicializarEventos();
    }

    public AdministradorController(VentanaAdministrador vista) {
        this.vista = vista;
        this.ventanaIniciarSesion = null;
        inicializarEventos();
    }

    private void inicializarEventos() {
        vista.getBotonGestionColaboradores().addActionListener(e -> abrirGestionColaboradores());
        vista.getBotonGestionClientes().addActionListener(e -> abrirGestionClientes());
        vista.getBotonGestionReservas().addActionListener(e -> abrirGestionReservas());
        vista.getBotonGestionEventos().addActionListener(e -> abrirGestionEventos());
        vista.getBotonGestionExtras().addActionListener(e -> abrirGestionExtras());
        vista.getBotonSalir().addActionListener(e -> cerrarSesion());
    }

    private void abrirGestionColaboradores() {
        vista.setVisible(false);
        VentanaGestionColaboradores vistaColab = new VentanaGestionColaboradores();
        new ColaboradoresController(vistaColab, vista);
        vistaColab.setVisible(true);
    }

    private void abrirGestionClientes() {
        vista.setVisible(false);
        VentanaGestionClientes vistaClientes = new VentanaGestionClientes();
        new ClientesController(vistaClientes, vista);
        vistaClientes.setVisible(true);
    }

    private void abrirGestionReservas() {
        vista.setVisible(false);
        VentanaGestionReservas vistaReservas = new VentanaGestionReservas();
        new ReservasController(vistaReservas, vista);
        vistaReservas.setVisible(true);
    }

    private void abrirGestionEventos() {
        vista.setVisible(false);
        VentanaGestionEventos vistaEventos = new VentanaGestionEventos();
        new EventosController(vistaEventos, vista);
        vistaEventos.setVisible(true);
    }

    private void abrirGestionExtras() {
        vista.setVisible(false);
        VentanaGestionExtras vistaExtras = new VentanaGestionExtras();
        new ExtrasController(vistaExtras, vista);
        vistaExtras.setVisible(true);
    }

    private void cerrarSesion() {
        vista.dispose();
        if (this.ventanaIniciarSesion != null) {
            this.ventanaIniciarSesion.setVisible(true);
        } else {
            VentanaIniciarSesion nuevoLogin = new VentanaIniciarSesion();
            new LoginController(nuevoLogin);
            nuevoLogin.setVisible(true);
        }
    }
}
