package ec.espe.edu.sft.ttpf.model;

public class Cliente {

    private String cedula;
    private String nombre;
    private String apellido;
    private String contacto;

    public Cliente(String cedula, String nombre, String apellido, String contacto) {
        this.cedula = cedula;
        this.nombre = nombre;
        this.apellido = apellido;
        this.contacto = contacto;
    }

    public String getCedula() {
        return cedula;
    }

    public void setCedula(String cedula) {
        this.cedula = cedula;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getApellido() {
        return apellido;
    }

    public void setApellido(String apellido) {
        this.apellido = apellido;
    }

    public String getContacto() {
        return contacto;
    }

    public void setContacto(String contacto) {
        this.contacto = contacto;
    }

}
