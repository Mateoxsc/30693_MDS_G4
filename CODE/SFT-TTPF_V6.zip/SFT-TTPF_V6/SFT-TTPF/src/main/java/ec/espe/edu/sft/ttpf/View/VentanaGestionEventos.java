package ec.espe.edu.sft.ttpf.View;

import ec.espe.edu.sft.ttpf.model.Evento;
import java.awt.*;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;

public class VentanaGestionEventos extends JFrame {

    private JTable tablaEventos;
    private DefaultTableModel modeloTablaEventos;
    private JButton botonRegistrarEventos;
    private JButton botonEditarEvento;
    private JButton botonBuscarEvento;
    private JButton botonEliminarEvento;
    private JButton botonRegresar;

    private final Color colorFondoBase = new Color(245, 230, 226);
    private final Color colorTarjetaBlanca = new Color(253, 246, 244);
    private final Color colorAzulBotones = new Color(134, 203, 233);
    private final Color colorSalmonTitulo = new Color(246, 187, 142);
    private final Color colorRosaRegresar = new Color(243, 151, 151);
    private final Color colorTextoEstilo = new Color(84, 72, 70);
    private final Color colorBordeInterno = new Color(230, 212, 207);

    private final Font fuentePrincipal = new Font("Segoe UI", Font.BOLD, 17);
    private final Font fuenteBotones = new Font("Segoe UI", Font.BOLD, 13);
    private final Font fuenteLabels = new Font("Segoe UI", Font.BOLD, 13);
    private final Font fuenteCampos = new Font("Segoe UI", Font.PLAIN, 13);
    private final Font fuenteTablas = new Font("SansSerif", Font.PLAIN, 13);

    public VentanaGestionEventos() {
        setTitle("Gestión de Servicio");
        setSize(1150, 600);
        setLayout(new BorderLayout());
        getContentPane().setBackground(colorFondoBase);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        String[] columnas = {"ID Servicio", "Tipo de Servicio", "Nombre", "Precio Base", "Descripción"};
        modeloTablaEventos = new DefaultTableModel(columnas, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        this.tablaEventos = new JTable(modeloTablaEventos);

        this.tablaEventos.setFont(fuenteTablas);
        this.tablaEventos.setForeground(colorTextoEstilo);
        this.tablaEventos.setRowHeight(28);
        this.tablaEventos.setGridColor(colorBordeInterno);
        this.tablaEventos.setSelectionBackground(new Color(205, 233, 245));
        this.tablaEventos.setSelectionForeground(colorTextoEstilo);

        this.tablaEventos.getTableHeader().setFont(fuenteBotones);
        this.tablaEventos.getTableHeader().setBackground(colorAzulBotones);
        this.tablaEventos.getTableHeader().setForeground(colorTextoEstilo);
        this.tablaEventos.getTableHeader().setReorderingAllowed(false);
        this.tablaEventos.getTableHeader().setBorder(BorderFactory.createLineBorder(colorAzulBotones));

        // MODIFICACIÓN: Ajuste de proporciones para las 5 columnas
        this.tablaEventos.getColumnModel().getColumn(0).setPreferredWidth(80);
        this.tablaEventos.getColumnModel().getColumn(1).setPreferredWidth(180);
        this.tablaEventos.getColumnModel().getColumn(2).setPreferredWidth(180);
        this.tablaEventos.getColumnModel().getColumn(3).setPreferredWidth(100);
        this.tablaEventos.getColumnModel().getColumn(4).setPreferredWidth(400);

        JScrollPane scrollTabla = new JScrollPane(this.tablaEventos);
        scrollTabla.setBorder(BorderFactory.createLineBorder(colorBordeInterno, 1));
        scrollTabla.getViewport().setBackground(colorTarjetaBlanca);

        JPanel panelEncabezado = new JPanel(new FlowLayout(FlowLayout.CENTER, 0, 15));
        panelEncabezado.setBackground(colorFondoBase);

        JPanel panelTablaEventos = new JPanel(new BorderLayout());
        panelTablaEventos.setBackground(colorTarjetaBlanca);
        panelTablaEventos.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createEmptyBorder(5, 25, 5, 25),
                BorderFactory.createEmptyBorder(15, 15, 15, 15)
        ));

        JPanel panelBotones = new JPanel(new FlowLayout(FlowLayout.CENTER, 15, 20));
        panelBotones.setBackground(colorFondoBase);

        JLabel etiquetaBienvenidaMenu = new JLabel("PANEL DE GESTIÓN DE SERVICIOS", JLabel.CENTER);
        etiquetaBienvenidaMenu.setFont(fuentePrincipal);
        etiquetaBienvenidaMenu.setForeground(colorTextoEstilo);

        JLabel etiquetaTablaDeEventos = new JLabel("  CATÁLOGO DE SERVICIOS CONFIGURADOS  ", JLabel.CENTER);
        etiquetaTablaDeEventos.setFont(fuenteBotones);
        etiquetaTablaDeEventos.setForeground(colorTextoEstilo);
        etiquetaTablaDeEventos.setOpaque(true);
        etiquetaTablaDeEventos.setBackground(colorSalmonTitulo);
        etiquetaTablaDeEventos.setBorder(BorderFactory.createLineBorder(colorSalmonTitulo, 4, true));

        JPanel panelContenedorTituloTabla = new JPanel(new FlowLayout(FlowLayout.LEFT, 0, 8));
        panelContenedorTituloTabla.setBackground(colorTarjetaBlanca);
        panelContenedorTituloTabla.add(etiquetaTablaDeEventos);

        Dimension tamanoBotones = new Dimension(185, 42);

        botonRegistrarEventos = new JButton("Registrar Servicio");
        configurarBoton(botonRegistrarEventos, colorAzulBotones, colorTextoEstilo, fuenteBotones, tamanoBotones);

        botonEditarEvento = new JButton("Editar Servicio");
        configurarBoton(botonEditarEvento, colorAzulBotones, colorTextoEstilo, fuenteBotones, tamanoBotones);

        botonBuscarEvento = new JButton("Buscar Servicio");
        configurarBoton(botonBuscarEvento, colorAzulBotones, colorTextoEstilo, fuenteBotones, tamanoBotones);

        botonEliminarEvento = new JButton("Eliminar Servicio");
        configurarBoton(botonEliminarEvento, colorAzulBotones, colorTextoEstilo, fuenteBotones, tamanoBotones);

        botonRegresar = new JButton("Regresar al Menú");
        configurarBoton(botonRegresar, colorRosaRegresar, colorTextoEstilo, fuenteBotones, tamanoBotones);

        panelEncabezado.add(etiquetaBienvenidaMenu);

        panelTablaEventos.add(panelContenedorTituloTabla, BorderLayout.NORTH);
        panelTablaEventos.add(scrollTabla, BorderLayout.CENTER);

        panelBotones.add(botonRegistrarEventos);
        panelBotones.add(botonEditarEvento);
        panelBotones.add(botonBuscarEvento);
        panelBotones.add(botonEliminarEvento);
        panelBotones.add(botonRegresar);

        add(panelEncabezado, BorderLayout.NORTH);
        add(panelTablaEventos, BorderLayout.CENTER);
        add(panelBotones, BorderLayout.SOUTH);

        setLocationRelativeTo(null);
    }

    private void configurarBoton(JButton btn, Color fondo, Color texto, Font fuente, Dimension tamano) {
        btn.setPreferredSize(tamano);
        btn.setFont(fuente);
        btn.setBackground(fondo);
        btn.setForeground(texto);
        btn.setFocusPainted(false);
        btn.setBorder(BorderFactory.createLineBorder(fondo.darker(), 1, true));
    }

    public String solicitarId(String mensaje, String titulo) {
        return JOptionPane.showInputDialog(this, mensaje, titulo, JOptionPane.QUESTION_MESSAGE);
    }

    public void mostrarMensajeError(String mensaje, String titulo) {
        JOptionPane.showMessageDialog(this, mensaje, titulo, JOptionPane.ERROR_MESSAGE);
    }

    public void mostrarMensajeInformativo(String mensaje, String titulo) {
        JOptionPane.showMessageDialog(this, mensaje, titulo, JOptionPane.INFORMATION_MESSAGE);
    }

    public void mostrarDetalleEvento(Evento ev) {
        JPanel panelInfo = crearPanelContenedorEstilizado(new BorderLayout(10, 10));

        JPanel panelCampos = new JPanel(new GridLayout(4, 1, 5, 5));
        panelCampos.setBackground(colorTarjetaBlanca);
        panelCampos.add(crearLabelEstilizado("Código de Evento: " + ev.getIdEvento()));
        panelCampos.add(crearLabelEstilizado("Grupo/Tipo: " + ev.getTipoEvento()));
        panelCampos.add(crearLabelEstilizado("Nombre: " + ev.getNombreEvento()));
        panelCampos.add(crearLabelEstilizado("Precio Base: $" + ev.getPrecioEvento()));

        JTextArea txtDescVisor = new JTextArea(ev.getDescripcionEvento());
        txtDescVisor.setFont(fuenteCampos);
        txtDescVisor.setForeground(colorTextoEstilo);
        txtDescVisor.setEditable(false);
        txtDescVisor.setLineWrap(true);
        txtDescVisor.setWrapStyleWord(true);
        JScrollPane scrollDesc = new JScrollPane(txtDescVisor);
        scrollDesc.setPreferredSize(new Dimension(300, 80));
        scrollDesc.setBorder(BorderFactory.createTitledBorder(BorderFactory.createLineBorder(colorFondoBase), "Elementos Incluidos / Descripción"));

        panelInfo.add(panelCampos, BorderLayout.NORTH);
        panelInfo.add(scrollDesc, BorderLayout.CENTER);

        JOptionPane.showMessageDialog(this, panelInfo, "Información del Servicio Encontrado", JOptionPane.INFORMATION_MESSAGE);
    }

    public int confirmarEliminacion(Evento ev) {
        JPanel panelConfirmacion = crearPanelContenedorEstilizado(new GridLayout(3, 1, 4, 4));
        panelConfirmacion.add(crearLabelEstilizado("¿Está seguro de que desea eliminar el siguiente servicio?"));
        panelConfirmacion.add(crearLabelEstilizado("• ID: " + ev.getIdEvento() + " | Nombre: " + ev.getNombreEvento() + " | Precio: $" + ev.getPrecioEvento()));
        panelConfirmacion.add(new JLabel(" "));

        return JOptionPane.showConfirmDialog(this, panelConfirmacion, "Confirmar Eliminación", JOptionPane.YES_NO_OPTION, JOptionPane.WARNING_MESSAGE);
    }

    public Object[] mostrarFormularioEvento(Evento ev) {
        boolean esEdicion = (ev != null);

        String[] gruposDisponibles = {
            "Decoraciones",
            "Fiestas infantiles",
            "Paquetes infantiles",
            "Baby Shower/Revelacion",
            "Paquetes Baby Shower Revelacion"
        };

        JComboBox<String> cmbTipo = new JComboBox<>(gruposDisponibles);
        cmbTipo.setFont(fuenteCampos);
        cmbTipo.setForeground(colorTextoEstilo);
        cmbTipo.setBackground(Color.WHITE);

        if (esEdicion) {
            cmbTipo.setSelectedItem(ev.getTipoEvento());
        }

        JTextField txtNombre = configurarCampoTexto(new JTextField(esEdicion ? ev.getNombreEvento() : ""));
        JTextField txtPrecio = configurarCampoTexto(new JTextField(esEdicion ? String.valueOf(ev.getPrecioEvento()) : ""));

        JTextArea txtDescripcion = new JTextArea(esEdicion ? ev.getDescripcionEvento() : "");
        txtDescripcion.setFont(fuenteCampos);
        txtDescripcion.setForeground(colorTextoEstilo);
        txtDescripcion.setLineWrap(true);
        txtDescripcion.setWrapStyleWord(true);

        JScrollPane scrollDesc = new JScrollPane(txtDescripcion);
        scrollDesc.setPreferredSize(new Dimension(340, 110));
        scrollDesc.setBorder(BorderFactory.createLineBorder(colorFondoBase, 1, true));

        JPanel panelForm = crearPanelContenedorEstilizado(new GridBagLayout());
        panelForm.setPreferredSize(new Dimension(550, 260));

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(6, 6, 6, 6);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.weightx = 0.0;
        panelForm.add(crearLabelEstilizado("Tipo de Servicio:"), gbc);
        gbc.gridx = 1;
        gbc.weightx = 1.0;
        panelForm.add(cmbTipo, gbc);

        gbc.gridx = 0;
        gbc.gridy = 1;
        gbc.weightx = 0.0;
        panelForm.add(crearLabelEstilizado("Nombre:"), gbc);
        gbc.gridx = 1;
        gbc.weightx = 1.0;
        panelForm.add(txtNombre, gbc);

        gbc.gridx = 0;
        gbc.gridy = 2;
        gbc.weightx = 0.0;
        panelForm.add(crearLabelEstilizado("Precio Evento ($):"), gbc);
        gbc.gridx = 1;
        gbc.weightx = 1.0;
        panelForm.add(txtPrecio, gbc);

        gbc.gridx = 0;
        gbc.gridy = 3;
        gbc.weightx = 0.0;
        panelForm.add(crearLabelEstilizado("Descripción:"), gbc);
        gbc.gridx = 1;
        gbc.weightx = 1.0;
        gbc.fill = GridBagConstraints.BOTH;
        panelForm.add(scrollDesc, gbc);

        String titulo = esEdicion ? "Modificar Servicio N° " + ev.getIdEvento() : "Registrar Nuevo Servicio";
        int resultado = JOptionPane.showConfirmDialog(this, panelForm, titulo, JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);

        if (resultado == JOptionPane.OK_OPTION) {
            return new Object[]{
                txtNombre.getText().trim(),
                txtPrecio.getText().trim(),
                txtDescripcion.getText().trim(),
                cmbTipo.getSelectedItem().toString()
            };
        }
        return null;
    }

    private JPanel crearPanelContenedorEstilizado(LayoutManager layout) {
        JPanel panel = new JPanel(layout);
        panel.setBackground(colorTarjetaBlanca);
        panel.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(colorFondoBase, 2, true),
                BorderFactory.createEmptyBorder(15, 15, 15, 15)
        ));
        return panel;
    }

    private JLabel crearLabelEstilizado(String texto) {
        JLabel label = new JLabel(texto);
        label.setFont(fuenteLabels);
        label.setForeground(colorTextoEstilo);
        return label;
    }

    private JTextField configurarCampoTexto(JTextField campo) {
        campo.setFont(fuenteCampos);
        campo.setForeground(colorTextoEstilo);
        campo.setBackground(Color.WHITE);
        campo.setCaretColor(colorTextoEstilo);
        campo.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(colorFondoBase, 1, true),
                BorderFactory.createEmptyBorder(4, 6, 4, 6)
        ));
        return campo;
    }

    public JTable getTablaEventos() {
        return tablaEventos;
    }

    public DefaultTableModel getModeloTablaEventos() {
        return modeloTablaEventos;
    }

    public JButton getBotonRegistrarEventos() {
        return botonRegistrarEventos;
    }

    public JButton getBotonEditarEvento() {
        return botonEditarEvento;
    }

    public JButton getBotonBuscarEvento() {
        return botonBuscarEvento;
    }

    public JButton getBotonEliminarEvento() {
        return botonEliminarEvento;
    }

    public JButton getBotonRegresar() {
        return botonRegresar;
    }
}
