package ec.espe.edu.sft.ttpf.model;

public class Decoracion extends Evento {

    public Decoracion(String nombreEvento, String descripcionEvento, float precioEvento, String tipoEvento) {
        super(nombreEvento, descripcionEvento, precioEvento, tipoEvento);
    }

}
