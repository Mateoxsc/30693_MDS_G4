package ec.espe.edu.sft.ttpf.controller;

import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import static com.mongodb.client.model.Filters.eq;
import com.mongodb.client.model.Updates;
import ec.espe.edu.sft.ttpf.Util.MongoConnection;
import ec.espe.edu.sft.ttpf.Util.MensajesSistema;
import ec.espe.edu.sft.ttpf.Util.TituloVentanas;
import ec.espe.edu.sft.ttpf.Util.ValidacionCrearUsuarioCliente;
import ec.espe.edu.sft.ttpf.View.VentanaGestionClientes;
import ec.espe.edu.sft.ttpf.model.Cliente; 
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import org.bson.Document;

public class ClientesController {

    private final VentanaGestionClientes vista;
    private final JFrame vPadre;
    private final MongoCollection<Document> coleccionClientes;

    public ClientesController(VentanaGestionClientes vista, JFrame vPadre) {
        this.vista = vista;
        this.vPadre = vPadre;

        MongoDatabase db = MongoConnection.getDatabase();
        this.coleccionClientes = db.getCollection("clientes");

        if (vPadre != null && !vPadre.getClass().getSimpleName().contains("Administrador")) {
            this.vista.configurarModoColaborador();
        }

        inicializarEventos();
        cargarTablaInicial();
    }

    private void inicializarEventos() {
        this.vista.getBtnAgregar().addActionListener(e -> agregarCliente());
        this.vista.getBtnBuscar().addActionListener(e -> buscarCliente());
        this.vista.getBtnEditar().addActionListener(e -> editarCliente());
        this.vista.getBtnEliminar().addActionListener(e -> eliminarCliente());

        this.vista.getBtnRegresar().addActionListener(e -> {
            this.vista.dispose();
            if (this.vPadre != null) {
                this.vPadre.setVisible(true);
            }
        });
    }

    private void cargarTablaInicial() {
        this.vista.getModeloTablaClientes().setRowCount(0);

        for (Document doc : coleccionClientes.find()) {
            this.vista.getModeloTablaClientes().addRow(new Object[]{
                String.valueOf(doc.getInteger("cedula")),
                doc.getString("nombre"),
                doc.getString("apellido"),
                doc.getString("telefono")
            });
        }
    }

    private void agregarCliente() {
        String cedulaStr = vista.getTxtCedulaCliente().getText().trim();
        String nombre = vista.getTxtNombreCliente().getText().trim();
        String apellido = vista.getTxtApellidoCliente().getText().trim();
        String contacto = vista.getTxtContactoCliente().getText().trim();

        if (cedulaStr.isBlank() || nombre.isBlank() || apellido.isBlank() || contacto.isBlank()) {
            JOptionPane.showMessageDialog(vista, MensajesSistema.ERROR_CAMPOS_VACIOS, TituloVentanas.VENTANA_ADVERTENCIA, JOptionPane.WARNING_MESSAGE);
            return;
        }

        if (!ValidacionCrearUsuarioCliente.validarCedula(cedulaStr)) {
            JOptionPane.showMessageDialog(vista, MensajesSistema.ERROR_CEDULA_INVALIDA, TituloVentanas.VENTANA_ERROR, JOptionPane.ERROR_MESSAGE);
            return;
        }

        int cedulaInt;
        try {
            cedulaInt = Integer.parseInt(cedulaStr);
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(vista, MensajesSistema.ERROR_CEDULA_SOLO_NUMEROS, TituloVentanas.VENTANA_ERROR, JOptionPane.ERROR_MESSAGE);
            return;
        }

        Document clienteDuplicado = coleccionClientes.find(eq("cedula", cedulaInt)).first();
        if (clienteDuplicado != null) {
            JOptionPane.showMessageDialog(vista, MensajesSistema.ERROR_CEDULA_DUPLICADA, TituloVentanas.VENTANA_ERROR, JOptionPane.ERROR_MESSAGE);
            return;
        }

        if (!contacto.matches("^0\\d{9}$")) {
            JOptionPane.showMessageDialog(vista,
                    "El número de contacto no es válido.\nDebe comenzar con '0' y tener exactamente 10 dígitos.",
                    "Error de Validación",
                    JOptionPane.ERROR_MESSAGE);
            return;
        }

        Cliente nuevoCliente = new Cliente(String.valueOf(cedulaInt), nombre, apellido, contacto);

        Document nuevoClienteDoc = new Document("cedula", Integer.parseInt(nuevoCliente.getCedula()))
                .append("nombre", nuevoCliente.getNombre())
                .append("apellido", nuevoCliente.getApellido())
                .append("telefono", nuevoCliente.getContacto());

        coleccionClientes.insertOne(nuevoClienteDoc);

        cargarTablaInicial();

        vista.getTxtCedulaCliente().setText("");
        vista.getTxtNombreCliente().setText("");
        vista.getTxtApellidoCliente().setText("");
        vista.getTxtContactoCliente().setText("");

        JOptionPane.showMessageDialog(vista, "Cliente agregado exitosamente.", TituloVentanas.VENTANA_INFO, JOptionPane.INFORMATION_MESSAGE);
    }

    private void buscarCliente() {
        String cedulaBuscar = JOptionPane.showInputDialog(vista, MensajesSistema.INFO_INGRESO_CEDULA_BUSCAR, "Buscar Cliente", JOptionPane.QUESTION_MESSAGE);

        if (cedulaBuscar == null || cedulaBuscar.trim().isEmpty()) {
            return;
        }

        int cedulaBusqueda;
        try {
            cedulaBusqueda = Integer.parseInt(cedulaBuscar.trim());
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(vista, MensajesSistema.ERROR_CEDULA_SOLO_NUMEROS, TituloVentanas.VENTANA_ERROR, JOptionPane.ERROR_MESSAGE);
            return;
        }

        Document clie = coleccionClientes.find(eq("cedula", cedulaBusqueda)).first();

        if (clie != null) {
            Cliente clienteEncontrado = new Cliente(
                    String.valueOf(clie.getInteger("cedula")),
                    clie.getString("nombre"),
                    clie.getString("apellido"),
                    clie.getString("telefono")
            );

            String info = "Información del Cliente:\n\n"
                    + "Cédula: " + clienteEncontrado.getCedula() + "\n"
                    + "Nombre: " + clienteEncontrado.getNombre() + "\n"
                    + "Apellido: " + clienteEncontrado.getApellido() + "\n"
                    + "Contacto: " + clienteEncontrado.getContacto();
            JOptionPane.showMessageDialog(vista, info, "Cliente Encontrado", JOptionPane.INFORMATION_MESSAGE);
        } else {
            JOptionPane.showMessageDialog(vista, "El cliente no ha sido encontrado.", TituloVentanas.VENTANA_ADVERTENCIA, JOptionPane.WARNING_MESSAGE);
        }
    }

    private void editarCliente() {
        String cedulaBuscar = JOptionPane.showInputDialog(vista, "Ingrese la Cédula del cliente a editar:", "Editar Cliente", JOptionPane.QUESTION_MESSAGE);

        if (cedulaBuscar == null) {
            return;
        }

        cedulaBuscar = cedulaBuscar.trim();
        if (cedulaBuscar.isEmpty()) {
            JOptionPane.showMessageDialog(vista, "Debe ingresar una cédula para buscar.", "Error", JOptionPane.WARNING_MESSAGE);
            return;
        }

        int cedulaInt;
        try {
            cedulaInt = Integer.parseInt(cedulaBuscar);
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(vista, "La cédula debe ser numérica.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        Document clienteDoc = coleccionClientes.find(eq("cedula", cedulaInt)).first();

        if (clienteDoc == null) {
            JOptionPane.showMessageDialog(vista, "El cliente con cédula " + cedulaBuscar + " no está registrado.", "No Encontrado", JOptionPane.ERROR_MESSAGE);
            return;
        }

        Cliente clienteEditable = new Cliente(
                String.valueOf(clienteDoc.getInteger("cedula")),
                clienteDoc.getString("nombre"),
                clienteDoc.getString("apellido"),
                clienteDoc.getString("telefono")
        );

        JTextField txtNuevoNombre = new JTextField();
        JTextField txtNuevoApellido = new JTextField();
        JTextField txtNuevoContacto = new JTextField();
        JButton btnGuardar = new JButton("Guardar");
        JButton btnSalir = new JButton("Salir");

        JDialog formularioEditar = vista.crearFormularioEditar(
                clienteEditable.getNombre(),
                clienteEditable.getApellido(),
                clienteEditable.getContacto(),
                txtNuevoNombre, txtNuevoApellido, txtNuevoContacto, btnGuardar, btnSalir
        );

        final int cedulaFiltro = cedulaInt;

        btnGuardar.addActionListener(e -> {
            String nombre = txtNuevoNombre.getText().trim();
            String apellido = txtNuevoApellido.getText().trim();
            String contacto = txtNuevoContacto.getText().trim();

            if (nombre.isEmpty() || apellido.isEmpty() || contacto.isEmpty()) {
                JOptionPane.showMessageDialog(formularioEditar, "Error: No se pueden guardar campos vacíos.", "Campos Vacíos", JOptionPane.WARNING_MESSAGE);
                return;
            }

            if (!contacto.matches("^0\\d{9}$")) {
                JOptionPane.showMessageDialog(formularioEditar, "El número de contacto no es válido.\nDebe comenzar con '0' y tener exactamente 10 dígitos.", "Error de Validación", JOptionPane.ERROR_MESSAGE);
                return;
            }

            clienteEditable.setNombre(nombre);
            clienteEditable.setApellido(apellido);
            clienteEditable.setContacto(contacto);

            coleccionClientes.updateOne(
                    eq("cedula", cedulaFiltro),
                    Updates.combine(
                            Updates.set("nombre", clienteEditable.getNombre()),
                            Updates.set("apellido", clienteEditable.getApellido()),
                            Updates.set("telefono", clienteEditable.getContacto())
                    )
            );

            cargarTablaInicial();

            JOptionPane.showMessageDialog(vista, "Cambios guardados exitosamente", "Éxito", JOptionPane.INFORMATION_MESSAGE);
            formularioEditar.dispose();
        });

        btnSalir.addActionListener(e -> formularioEditar.dispose());
        formularioEditar.setVisible(true);
    }

    private void eliminarCliente() {
        String cedulaEliminar = JOptionPane.showInputDialog(vista, MensajesSistema.INFO_INGRESO_CEDULA_ELIMINAR, "Eliminar Cliente", JOptionPane.QUESTION_MESSAGE);

        if (cedulaEliminar == null || cedulaEliminar.trim().isEmpty()) {
            return;
        }

        int cedulaBusqueda;
        try {
            cedulaBusqueda = Integer.parseInt(cedulaEliminar.trim());
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(vista, MensajesSistema.ERROR_CEDULA_SOLO_NUMEROS, TituloVentanas.VENTANA_ERROR, JOptionPane.ERROR_MESSAGE);
            return;
        }

        Document clienteDoc = coleccionClientes.find(eq("cedula", cedulaBusqueda)).first();

        if (clienteDoc != null) {
            int confirmacion = JOptionPane.showConfirmDialog(vista, "¿Está seguro de eliminar al cliente con cédula " + cedulaBusqueda + "?", "Confirmar Eliminación", JOptionPane.YES_NO_OPTION);

            if (confirmacion == JOptionPane.YES_OPTION) {
                coleccionClientes.deleteOne(eq("cedula", cedulaBusqueda));
                cargarTablaInicial();
                JOptionPane.showMessageDialog(vista, "Cliente eliminado exitosamente.", TituloVentanas.VENTANA_INFO, JOptionPane.INFORMATION_MESSAGE);
            }
        } else {
            JOptionPane.showMessageDialog(vista, "El cliente no ha sido encontrado.", TituloVentanas.VENTANA_ADVERTENCIA, JOptionPane.WARNING_MESSAGE);
        }
    }
}
