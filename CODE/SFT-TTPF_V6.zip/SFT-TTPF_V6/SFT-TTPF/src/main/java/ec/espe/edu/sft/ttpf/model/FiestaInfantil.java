package ec.espe.edu.sft.ttpf.model;

public class FiestaInfantil extends Evento {

    public FiestaInfantil(String nombreEvento, String descripcionEvento, float precioEvento, String tipoEvento) {
        super(nombreEvento, descripcionEvento, precioEvento, tipoEvento);
    }

}
