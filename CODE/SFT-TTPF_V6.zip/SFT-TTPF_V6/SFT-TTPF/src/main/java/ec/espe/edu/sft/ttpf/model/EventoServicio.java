package ec.espe.edu.sft.ttpf.model;

import java.util.ArrayList;
import java.util.Optional;

public class EventoServicio {

    private final ArrayList<Evento> baseDatosEventos = new ArrayList<>();

    public ArrayList<Evento> obtenerTodos() {
        return baseDatosEventos;
    }

    public void agregar(Evento evento) {
        baseDatosEventos.add(evento);
    }

    public boolean eliminar(int id) {
        return baseDatosEventos.removeIf(e -> e.getIdEvento() == id);
    }

    public Optional<Evento> buscarPorId(int id) {
        return baseDatosEventos.stream().filter(e -> e.getIdEvento() == id).findFirst();
    }
}
