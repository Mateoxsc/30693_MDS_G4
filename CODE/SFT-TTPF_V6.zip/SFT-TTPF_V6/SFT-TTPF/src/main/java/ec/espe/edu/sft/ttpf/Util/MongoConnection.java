package ec.espe.edu.sft.ttpf.Util;

import com.mongodb.client.MongoClient;
import com.mongodb.client.MongoClients;
import com.mongodb.client.MongoDatabase;
import javax.swing.JOptionPane;

public class MongoConnection {

    private static final String DATABASE_NAME = "Tilin_Tilin_Planeta_Fiesta";

    private static final String CONNECTION_STRING = "mongodb://localhost:27017";

    private static MongoClient mongoClient = null;
    private static MongoDatabase database = null;

    private MongoConnection() {
    }

    public static MongoDatabase getDatabase() {
        if (database == null) {
            try {
                mongoClient = MongoClients.create(CONNECTION_STRING);
                database = mongoClient.getDatabase(DATABASE_NAME);
                System.out.println("¡Conexión exitosa a MongoDB - Base de datos: " + DATABASE_NAME + "!");
            } catch (Exception e) {
                JOptionPane.showMessageDialog(null,
                        "Error al conectar con MongoDB: " + e.getMessage(),
                        "Error de Conexión",
                        JOptionPane.ERROR_MESSAGE);
                e.printStackTrace();
            }
        }
        return database;
    }

    public static void closeConnection() {
        if (mongoClient != null) {
            mongoClient.close();
            mongoClient = null;
            database = null;
            System.out.println("Conexión a MongoDB cerrada de manera segura.");
        }
    }
}
