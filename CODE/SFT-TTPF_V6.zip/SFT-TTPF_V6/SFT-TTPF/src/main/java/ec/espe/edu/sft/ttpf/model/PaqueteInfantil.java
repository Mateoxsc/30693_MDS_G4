package ec.espe.edu.sft.ttpf.model;

public class PaqueteInfantil extends Evento {

    public PaqueteInfantil(String nombreEvento, String descripcionEvento, float precioEvento, String tipoEvento) {
        super(nombreEvento, descripcionEvento, precioEvento, tipoEvento);
    }

}
