package ec.espe.edu.sft.ttpf.controller;

import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import static com.mongodb.client.model.Filters.and;
import static com.mongodb.client.model.Filters.eq;
import ec.espe.edu.sft.ttpf.Util.MongoConnection;
import ec.espe.edu.sft.ttpf.Util.MensajesSistema;
import ec.espe.edu.sft.ttpf.Util.TituloVentanas;
import ec.espe.edu.sft.ttpf.View.VentanaIniciarSesion;
import ec.espe.edu.sft.ttpf.View.VentanaAdministrador;
import ec.espe.edu.sft.ttpf.View.VentanaColaborador; 
import ec.espe.edu.sft.ttpf.model.Credenciales;
import java.awt.HeadlessException;
import javax.swing.JOptionPane;
import javax.swing.Timer;
import org.bson.Document;

public class LoginController {

    private VentanaIniciarSesion vista;
    private int intentosFallidos = 0;
    private boolean sistemaBloqueado = false;
    private int tiempoRestanteSegundos = 180;

    private final MongoCollection<Document> coleccionColaboradores;

    public LoginController(VentanaIniciarSesion vista) {
        this.vista = vista;
        
        MongoDatabase db = MongoConnection.getDatabase();
        this.coleccionColaboradores = db.getCollection("colaboradores");
        
        inicializarEventos();
    }

    private void inicializarEventos() {
        this.vista.getBtnIngresar().addActionListener(e -> validarAcceso());
    }

    private void validarAcceso() {
        if (sistemaBloqueado) {
            mostrarMensajeBloqueo();
            return;
        }

        try {
            String usuario = vista.getUsuario();
            String contrasenia = vista.getContrasenia();

            if (usuario == null || usuario.isBlank() || contrasenia == null || contrasenia.isBlank()) {
                JOptionPane.showMessageDialog(vista, MensajesSistema.ERROR_CAMPOS_VACIOS, TituloVentanas.VENTANA_ADVERTENCIA, JOptionPane.WARNING_MESSAGE);
                return;
            }

            if (usuario.equals(Credenciales.USUARIO_ADMIN) && contrasenia.equals(Credenciales.CONTRASENIA_ADMIN)) {
                JOptionPane.showMessageDialog(vista, MensajesSistema.EXITO_LOGGIN, TituloVentanas.VENTANA_INICIO, JOptionPane.INFORMATION_MESSAGE);
                this.intentosFallidos = 0;

                vista.limpiarCampos();
                vista.setVisible(false);

                VentanaAdministrador vAdmin = new VentanaAdministrador();
                new AdministradorController(vAdmin, vista);
                vAdmin.setVisible(true);

            } else {
                Document colaboradorEncontrado = coleccionColaboradores.find(
                    and(
                        eq("usuario", usuario),
                        eq("contrasenia", contrasenia)
                    )
                ).first();

                if (colaboradorEncontrado != null) {
                    JOptionPane.showMessageDialog(vista, MensajesSistema.EXITO_LOGGIN, TituloVentanas.VENTANA_INICIO, JOptionPane.INFORMATION_MESSAGE);
                    this.intentosFallidos = 0;

                    vista.limpiarCampos();
                    vista.setVisible(false);

                    VentanaColaborador vColab = new VentanaColaborador();
                    new RolColaboradorController(vColab, vista);
                    vColab.setVisible(true);

                } else {
                    this.intentosFallidos++;
                    vista.limpiarCampos();
                    vista.enfocarUsuario();

                    if (this.intentosFallidos >= 3) {
                        iniciarContadorBloqueo();
                    } else {
                        int intentosRestantes = 3 - this.intentosFallidos;
                        JOptionPane.showMessageDialog(vista, MensajesSistema.ERROR_USUARIO_O_CONTRASENIA + "\n" + MensajesSistema.INFO_INTENTOS_RESTANTES + ": " + intentosRestantes, TituloVentanas.VENTANA_ERROR, JOptionPane.ERROR_MESSAGE);
                    }
                }
            }
        } catch (HeadlessException ex) {
            JOptionPane.showMessageDialog(vista, MensajesSistema.ERROR_DESCONOCIDO_LOGGIN, TituloVentanas.VENTANA_ERROR, JOptionPane.ERROR_MESSAGE);
        }
    }

    private void iniciarContadorBloqueo() {
        this.sistemaBloqueado = true;
        this.vista.getBtnIngresar().setEnabled(false);
        this.tiempoRestanteSegundos = 180;
        mostrarMensajeBloqueo();

        Timer timer = new Timer(1000, null);
        timer.addActionListener(e -> {
            this.tiempoRestanteSegundos--;
            if (this.tiempoRestanteSegundos <= 0) {
                this.sistemaBloqueado = false;
                this.intentosFallidos = 0;
                this.vista.getBtnIngresar().setEnabled(true);
                this.vista.getBtnIngresar().setText("Ingresar");
                timer.stop();
                JOptionPane.showMessageDialog(vista, "Sistema desbloqueado. Puede intentar de nuevo.", TituloVentanas.VENTANA_INICIO, JOptionPane.INFORMATION_MESSAGE);
            } else {
                int minutes = this.tiempoRestanteSegundos / 60;
                int segundos = this.tiempoRestanteSegundos % 60;
                this.vista.getBtnIngresar().setText(String.format("Bloqueado (%02d:%02d)", minutes, segundos));
            }
        });
        timer.start();
    }

    private void mostrarMensajeBloqueo() {
        int minutes = this.tiempoRestanteSegundos / 60;
        int segundos = this.tiempoRestanteSegundos % 60;
        JOptionPane.showMessageDialog(vista, MensajesSistema.ERROR_LIMITE_DE_INTENTOS_LOGGIN + " " + String.format("%02d:%02d", minutes, segundos), TituloVentanas.VENTANA_ERROR, JOptionPane.ERROR_MESSAGE);
    }
}