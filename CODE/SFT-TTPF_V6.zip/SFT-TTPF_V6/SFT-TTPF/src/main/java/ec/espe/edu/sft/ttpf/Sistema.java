package ec.espe.edu.sft.ttpf;

import ec.espe.edu.sft.ttpf.View.VentanaIniciarSesion;
import ec.espe.edu.sft.ttpf.controller.LoginController;

public class Sistema {

    public void iniciar() {
        VentanaIniciarSesion vistaLogin = new VentanaIniciarSesion();

        new LoginController(vistaLogin);

        vistaLogin.setVisible(true);
    }
}
