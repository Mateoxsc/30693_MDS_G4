package ec.espe.edu.sft.ttpf.model;

public class Credenciales {

    public static final String USUARIO_ADMIN = "1";//"MERYADMIN"
    public static final String CONTRASENIA_ADMIN = "00";//"ADMINISTRADOR_2003*"

    public static final String USUARIO_COLAB_1 = "2";
    public static final String CONTRASENIA_COLAB_1 = "3";

}
