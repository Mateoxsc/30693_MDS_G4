package ec.espe.edu.sft.ttpf.controller;

import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import static com.mongodb.client.model.Filters.eq;
import com.mongodb.client.model.Updates;
import ec.espe.edu.sft.ttpf.Util.MongoConnection;
import ec.espe.edu.sft.ttpf.View.VentanaGestionExtras;
import ec.espe.edu.sft.ttpf.model.Extra;
import javax.swing.JFrame;
import org.bson.Document;

public class ExtrasController {

    private final VentanaGestionExtras vista;
    private final JFrame vistaPadre;
    
    private final MongoCollection<Document> coleccionExtras;

    public ExtrasController(VentanaGestionExtras vista, JFrame vistaPadre) {
        this.vista = vista;
        this.vistaPadre = vistaPadre;

        MongoDatabase db = MongoConnection.getDatabase();
        this.coleccionExtras = db.getCollection("extras");

        inicializarEventos();
        actualizarTabla();
    }

    private void inicializarEventos() {
        this.vista.getBotonRegistrarExtra().addActionListener(e -> registrarExtra());
        this.vista.getBotonEditarExtra().addActionListener(e -> editarExtra());
        this.vista.getBotonBuscarExtra().addActionListener(e -> buscarExtra());
        this.vista.getBotonEliminarExtra().addActionListener(e -> eliminarExtra());

        this.vista.getBotonRegresar().addActionListener(e -> {
            this.vista.dispose();
            if (this.vistaPadre != null) {
                this.vistaPadre.setVisible(true);
            }
        });
    }

    private void actualizarTabla() {
        this.vista.getModeloTablaExtras().setRowCount(0);
        
        for (Document doc : coleccionExtras.find()) {
            this.vista.getModeloTablaExtras().addRow(new Object[]{
                doc.getInteger("idExtra"),
                doc.getString("articuloExtra"),
                String.format("$%.2f", doc.getDouble("precioExtra"))
            });
        }
    }

    private void registrarExtra() {
        Object[] datos = this.vista.mostrarFormularioExtra(null);
        if (datos == null) {
            return;
        }

        String articulo = (String) datos[0];
        String precioStr = (String) datos[1];

        if (articulo.isEmpty() || precioStr.isEmpty()) {
            this.vista.mostrarMensajeError("Todos los campos son obligatorios.", "Campos Vacíos");
            return;
        }

        try {
            float precio = Float.parseFloat(precioStr);
            if (precio < 0) {
                this.vista.mostrarMensajeError("El precio no puede ser negativo.", "Error de Validación");
                return;
            }

            int siguienteId = generarSiguienteId();

            Document nuevoExtraDoc = new Document("idExtra", siguienteId)
                    .append("articuloExtra", articulo)
                    .append("precioExtra", (double) precio);
            
            coleccionExtras.insertOne(nuevoExtraDoc);
            
            actualizarTabla();
            this.vista.mostrarMensajeInformativo("Artículo extra registrado exitosamente.", "Éxito");

        } catch (NumberFormatException ex) {
            this.vista.mostrarMensajeError("El formato del precio es incorrecto.", "Error de Formato");
        }
    }

    private void editarExtra() {
        String idStr = this.vista.solicitarId("Ingrese el ID del artículo extra a modificar:", "Editar Extra");
        if (idStr == null || idStr.trim().isEmpty()) {
            return;
        }

        try {
            int idBuscar = Integer.parseInt(idStr.trim());
            Extra extraAEditar = buscarExtraPorId(idBuscar);

            if (extraAEditar == null) {
                this.vista.mostrarMensajeError("El artículo extra con el ID especificado no existe.", "No Encontrado");
                return;
            }

            Object[] datos = this.vista.mostrarFormularioExtra(extraAEditar);
            if (datos == null) {
                return;
            }

            String articulo = (String) datos[0];
            String precioStr = (String) datos[1];

            if (articulo.isEmpty() || precioStr.isEmpty()) {
                this.vista.mostrarMensajeError("Los campos no pueden quedar vacíos.", "Error");
                return;
            }

            float precio = Float.parseFloat(precioStr);
            if (precio < 0) {
                this.vista.mostrarMensajeError("El precio debe ser un número positivo.", "Error");
                return;
            }

            // MODIFICADO: Actualización en caliente sobre MongoDB
            coleccionExtras.updateOne(
                eq("idExtra", idBuscar),
                Updates.combine(
                    Updates.set("articuloExtra", articulo),
                    Updates.set("precioExtra", (double) precio)
                )
            );

            actualizarTabla();
            this.vista.mostrarMensajeInformativo("Artículo extra actualizado con éxito.", "Éxito");

        } catch (NumberFormatException ex) {
            this.vista.mostrarMensajeError("ID o precio inválido.", "Error de Formato");
        }
    }

    private void buscarExtra() {
        String idStr = this.vista.solicitarId("Ingrese el ID del artículo extra a buscar:", "Buscar Extra");
        if (idStr == null || idStr.trim().isEmpty()) {
            return;
        }

        try {
            int idBuscar = Integer.parseInt(idStr.trim());
            Extra ex = buscarExtraPorId(idBuscar);

            if (ex != null) {
                this.vista.mostrarDetalleExtra(ex);
            } else {
                this.vista.mostrarMensajeError("Artículo extra no encontrado.", "Búsqueda Fallida");
            }
        } catch (NumberFormatException ex) {
            this.vista.mostrarMensajeError("El ID debe ser un valor numérico.", "Error");
        }
    }

    private void eliminarExtra() {
        String idStr = this.vista.solicitarId("Ingrese el ID del artículo extra a eliminar:", "Eliminar Extra");
        if (idStr == null || idStr.trim().isEmpty()) {
            return;
        }

        try {
            int idBuscar = Integer.parseInt(idStr.trim());
            Extra ex = buscarExtraPorId(idBuscar);

            if (ex == null) {
                this.vista.mostrarMensajeError("Artículo extra no encontrado.", "Error");
                return;
            }

            int confirmacion = this.vista.confirmarEliminacion(ex);
            if (confirmacion == javax.swing.JOptionPane.YES_OPTION) {
                
                coleccionExtras.deleteOne(eq("idExtra", idBuscar));
                
                actualizarTabla();
                this.vista.mostrarMensajeInformativo("El artículo fue eliminado de forma permanente.", "Éxito");
            }
        } catch (NumberFormatException ex) {
            this.vista.mostrarMensajeError("ID inválido.", "Error");
        }
    }

    private Extra buscarExtraPorId(int id) {
        Document doc = coleccionExtras.find(eq("idExtra", id)).first();
        if (doc != null) {
            Extra ex = new Extra(doc.getString("articuloExtra"), doc.getDouble("precioExtra").floatValue());
            ex.setIdExtra(doc.getInteger("idExtra")); 
            return ex;
        }
        return null;
    }

    private int generarSiguienteId() {
        Document maxDoc = coleccionExtras.find().sort(new Document("idExtra", -1)).first();
        if (maxDoc != null) {
            return maxDoc.getInteger("idExtra") + 1;
        }
        return 1;
    }
}