package ec.espe.edu.sft.ttpf.View;

import java.awt.*;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;

public class VentanaGestionColaboradores extends JFrame {

    private JTextField campoTextoNombreColaborador;
    private JTextField campoTextoCedulaColaborador;
    private JTextField campoTextoTelefonoColaborador;
    private JTextField campoTextoUsuarioColaborador;
    private JPasswordField campoTextoContraseniaColaborador;

    private JButton botonAgregar;
    private JButton botonBuscar;
    private JButton botonEditar;
    private JButton botonEliminar;
    private JButton botonSalirColaborador;

    private JTable tablaColaboradores;
    private DefaultTableModel modeloTablaColaboradores;

    private final java.awt.Color colorFondoBase = new java.awt.Color(245, 230, 226);
    private final java.awt.Color colorTarjetaBlanca = new java.awt.Color(253, 246, 244);
    private final java.awt.Color colorAzulBotones = new java.awt.Color(134, 203, 233);
    private final java.awt.Color colorRosaSalir = new java.awt.Color(243, 151, 151);
    private final java.awt.Color colorTextoEstilo = new java.awt.Color(84, 72, 70);
    private final java.awt.Color colorBordeInterno = new java.awt.Color(230, 212, 207);

    private final java.awt.Font fuenteLabels = new java.awt.Font("Segoe UI", java.awt.Font.BOLD, 12);
    private final java.awt.Font fuenteCampos = new java.awt.Font("Segoe UI", java.awt.Font.PLAIN, 13);
    private final java.awt.Font fuenteBotones = new java.awt.Font("Segoe UI", java.awt.Font.BOLD, 13);
    private final java.awt.Font fuenteTablas = new java.awt.Font("SansSerif", java.awt.Font.PLAIN, 13);
    private final java.awt.Font fuenteTitulado = new java.awt.Font("Segoe UI", java.awt.Font.BOLD, 14);

    public VentanaGestionColaboradores() {
        setTitle("Gestionar colaboradores");
        setSize(1200, 650);
        setLayout(new BorderLayout());
        getContentPane().setBackground(colorFondoBase);

        JPanel panelDatos = new JPanel(new GridLayout(3, 4, 12, 12));
        panelDatos.setBackground(colorTarjetaBlanca);
        panelDatos.setPreferredSize(new Dimension(750, 140));

        javax.swing.border.TitledBorder bordeTitulo = javax.swing.BorderFactory.createTitledBorder(
                javax.swing.BorderFactory.createLineBorder(colorBordeInterno, 1, true), " Datos del Colaborador "
        );
        bordeTitulo.setTitleFont(fuenteTitulado);
        bordeTitulo.setTitleColor(colorTextoEstilo);
        panelDatos.setBorder(bordeTitulo);

        JLabel lblNombre = new JLabel("  Nombre-Apellido:");
        lblNombre.setFont(fuenteLabels);
        lblNombre.setForeground(colorTextoEstilo);
        panelDatos.add(lblNombre);
        campoTextoNombreColaborador = new JTextField();
        campoTextoNombreColaborador.setFont(fuenteCampos);
        campoTextoNombreColaborador.setForeground(colorTextoEstilo);
        panelDatos.add(campoTextoNombreColaborador);

        JLabel lblCedula = new JLabel("  Cédula :");
        lblCedula.setFont(fuenteLabels);
        lblCedula.setForeground(colorTextoEstilo);
        panelDatos.add(lblCedula);
        campoTextoCedulaColaborador = new JTextField();
        campoTextoCedulaColaborador.setFont(fuenteCampos);
        campoTextoCedulaColaborador.setForeground(colorTextoEstilo);
        panelDatos.add(campoTextoCedulaColaborador);

        JLabel lblTelefono = new JLabel("  Teléfono Colaborador:");
        lblTelefono.setFont(fuenteLabels);
        lblTelefono.setForeground(colorTextoEstilo);
        panelDatos.add(lblTelefono);
        campoTextoTelefonoColaborador = new JTextField();
        campoTextoTelefonoColaborador.setFont(fuenteCampos);
        campoTextoTelefonoColaborador.setForeground(colorTextoEstilo);
        panelDatos.add(campoTextoTelefonoColaborador);

        JLabel lblUsuario = new JLabel("  Usuario Colaborador:");
        lblUsuario.setFont(fuenteLabels);
        lblUsuario.setForeground(colorTextoEstilo);
        panelDatos.add(lblUsuario);
        campoTextoUsuarioColaborador = new JTextField();
        campoTextoUsuarioColaborador.setFont(fuenteCampos);
        campoTextoUsuarioColaborador.setForeground(colorTextoEstilo);
        panelDatos.add(campoTextoUsuarioColaborador);

        JLabel lblContrasenia = new JLabel("  Contraseña Colaborador:");
        lblContrasenia.setFont(fuenteLabels);
        lblContrasenia.setForeground(colorTextoEstilo);
        panelDatos.add(lblContrasenia);
        campoTextoContraseniaColaborador = new JPasswordField();
        campoTextoContraseniaColaborador.setFont(fuenteCampos);
        campoTextoContraseniaColaborador.setForeground(colorTextoEstilo);
        panelDatos.add(campoTextoContraseniaColaborador);

        panelDatos.add(new JLabel(""));
        panelDatos.add(new JLabel(""));

        JPanel panelBotones = new JPanel(new FlowLayout(FlowLayout.CENTER, 12, 15));
        panelBotones.setBackground(colorFondoBase);

        Dimension tamanoBotones = new Dimension(175, 40);

        botonAgregar = new JButton("Añadir Colaborador");
        botonAgregar.setPreferredSize(tamanoBotones);
        botonAgregar.setFont(fuenteBotones);
        botonAgregar.setBackground(colorAzulBotones);
        botonAgregar.setForeground(colorTextoEstilo);
        botonAgregar.setFocusPainted(false);
        botonAgregar.setBorder(javax.swing.BorderFactory.createLineBorder(colorAzulBotones.darker(), 1, true));

        botonBuscar = new JButton("Buscar (por Cédula)");
        botonBuscar.setPreferredSize(tamanoBotones);
        botonBuscar.setFont(fuenteBotones);
        botonBuscar.setBackground(colorAzulBotones);
        botonBuscar.setForeground(colorTextoEstilo);
        botonBuscar.setFocusPainted(false);
        botonBuscar.setBorder(javax.swing.BorderFactory.createLineBorder(colorAzulBotones.darker(), 1, true));

        botonEditar = new JButton("Editar Información");
        botonEditar.setPreferredSize(tamanoBotones);
        botonEditar.setFont(fuenteBotones);
        botonEditar.setBackground(colorAzulBotones);
        botonEditar.setForeground(colorTextoEstilo);
        botonEditar.setFocusPainted(false);
        botonEditar.setBorder(javax.swing.BorderFactory.createLineBorder(colorAzulBotones.darker(), 1, true));

        botonEliminar = new JButton("Eliminar Colaborador");
        botonEliminar.setPreferredSize(tamanoBotones);
        botonEliminar.setFont(fuenteBotones);
        botonEliminar.setBackground(colorAzulBotones);
        botonEliminar.setForeground(colorTextoEstilo);
        botonEliminar.setFocusPainted(false);
        botonEliminar.setBorder(javax.swing.BorderFactory.createLineBorder(colorAzulBotones.darker(), 1, true));

        botonSalirColaborador = new JButton("Regresar al menú");
        botonSalirColaborador.setPreferredSize(tamanoBotones);
        botonSalirColaborador.setFont(fuenteBotones);
        botonSalirColaborador.setBackground(colorRosaSalir);
        botonSalirColaborador.setForeground(colorTextoEstilo);
        botonSalirColaborador.setFocusPainted(false);
        botonSalirColaborador.setBorder(javax.swing.BorderFactory.createLineBorder(colorRosaSalir.darker(), 1, true));

        panelBotones.add(botonAgregar);
        panelBotones.add(botonBuscar);
        panelBotones.add(botonEditar);
        panelBotones.add(botonEliminar);
        panelBotones.add(botonSalirColaborador);

        JPanel panelSuperior = new JPanel(new BorderLayout());
        panelSuperior.setBackground(colorFondoBase);
        panelSuperior.setBorder(javax.swing.BorderFactory.createEmptyBorder(15, 20, 5, 20));
        panelSuperior.add(panelDatos, BorderLayout.CENTER);
        panelSuperior.add(panelBotones, BorderLayout.SOUTH);

        String[] columnas = {"Cédula", "Nombre", "Usuario", "Contraseña", "Teléfono"};
        modeloTablaColaboradores = new DefaultTableModel(columnas, 0);
        tablaColaboradores = new JTable(modeloTablaColaboradores);

        tablaColaboradores.setFont(fuenteTablas);
        tablaColaboradores.setForeground(colorTextoEstilo);
        tablaColaboradores.setRowHeight(28);
        tablaColaboradores.setGridColor(colorBordeInterno);
        tablaColaboradores.setSelectionBackground(new java.awt.Color(205, 233, 245));
        tablaColaboradores.setSelectionForeground(colorTextoEstilo);

        tablaColaboradores.getTableHeader().setFont(fuenteBotones);
        tablaColaboradores.getTableHeader().setBackground(colorAzulBotones);
        tablaColaboradores.getTableHeader().setForeground(colorTextoEstilo);
        tablaColaboradores.getTableHeader().setReorderingAllowed(false);
        tablaColaboradores.getTableHeader().setBorder(javax.swing.BorderFactory.createLineBorder(colorAzulBotones));

        JScrollPane scrollPane = new JScrollPane(tablaColaboradores);
        scrollPane.setBorder(javax.swing.BorderFactory.createCompoundBorder(
                javax.swing.BorderFactory.createEmptyBorder(10, 20, 20, 20),
                javax.swing.BorderFactory.createLineBorder(colorBordeInterno, 1)
        ));
        scrollPane.getViewport().setBackground(colorTarjetaBlanca);

        add(panelSuperior, BorderLayout.NORTH);
        add(scrollPane, BorderLayout.CENTER);

        setLocationRelativeTo(null);
    }

    public String[] mostrarFormularioEditar(String nombreAct, String usuarioAct, String contraseniaAct, String telefonoAct) {
        JDialog formularioEditar = new JDialog(this, "Formulario de Edición", true);
        formularioEditar.setSize(380, 280);
        formularioEditar.setLocationRelativeTo(this);
        formularioEditar.getContentPane().setBackground(colorFondoBase);
        ((JPanel) formularioEditar.getContentPane()).setBorder(BorderFactory.createEmptyBorder(15, 15, 15, 15));
        formularioEditar.setLayout(new GridLayout(5, 2, 10, 10));

        JTextField txtNuevoNombre = new JTextField(nombreAct);
        JTextField txtNuevoUsuario = new JTextField(usuarioAct);
        JTextField txtNuevaContrasenia = new JTextField(contraseniaAct);
        JTextField txtNuevoTelefono = new JTextField(telefonoAct);

        JTextField[] campos = {txtNuevoNombre, txtNuevoUsuario, txtNuevaContrasenia, txtNuevoTelefono};
        for (JTextField campo : campos) {
            campo.setBackground(colorTarjetaBlanca);
            campo.setForeground(colorTextoEstilo);
            campo.setFont(fuenteCampos);
        }

        JLabel lblNombre = new JLabel("Nombre Completo:");
        JLabel lblUsuario = new JLabel("Usuario:");
        JLabel lblContra = new JLabel("Contraseña:");
        JLabel lblTelf = new JLabel("Teléfono:");

        JLabel[] labels = {lblNombre, lblUsuario, lblContra, lblTelf};
        for (JLabel label : labels) {
            label.setFont(fuenteLabels);
            label.setForeground(colorTextoEstilo);
        }

        formularioEditar.add(lblNombre);
        formularioEditar.add(txtNuevoNombre);
        formularioEditar.add(lblUsuario);
        formularioEditar.add(txtNuevoUsuario);
        formularioEditar.add(lblContra);
        formularioEditar.add(txtNuevaContrasenia);
        formularioEditar.add(lblTelf);
        formularioEditar.add(txtNuevoTelefono);

        JButton btnGuardar = new JButton("Guardar");
        btnGuardar.setFont(fuenteLabels);
        btnGuardar.setBackground(colorAzulBotones);
        btnGuardar.setForeground(colorTextoEstilo);
        btnGuardar.setFocusPainted(false);
        btnGuardar.setBorder(BorderFactory.createLineBorder(colorAzulBotones.darker(), 1, true));

        JButton btnSalir = new JButton("Salir");
        btnSalir.setFont(fuenteLabels);
        btnSalir.setBackground(colorRosaSalir);
        btnSalir.setForeground(colorTextoEstilo);
        btnSalir.setFocusPainted(false);
        btnSalir.setBorder(BorderFactory.createLineBorder(colorRosaSalir.darker(), 1, true));

        final String[] datosResultado = new String[4];

        btnGuardar.addActionListener(e -> {
            datosResultado[0] = txtNuevoNombre.getText().trim();
            datosResultado[1] = txtNuevoUsuario.getText().trim();
            datosResultado[2] = txtNuevaContrasenia.getText().trim();
            datosResultado[3] = txtNuevoTelefono.getText().trim();
            formularioEditar.dispose();
        });

        btnSalir.addActionListener(e -> {
            datosResultado[0] = null;
            formularioEditar.dispose();
        });

        formularioEditar.add(btnGuardar);
        formularioEditar.add(btnSalir);

        formularioEditar.setVisible(true);
        return datosResultado;
    }

    public JTextField getTxtNombreColaborador() {
        return campoTextoNombreColaborador;
    }

    public JTextField getTxtCedulaColaborador() {
        return campoTextoCedulaColaborador;
    }

    public JTextField getTxtTelefonoColaborador() {
        return campoTextoTelefonoColaborador;
    }

    public JTextField getTxtUsuarioColaborador() {
        return campoTextoUsuarioColaborador;
    }

    public JPasswordField getTxtContraseniaColaborador() {
        return campoTextoContraseniaColaborador;
    }

    public JButton getBtnAgregar() {
        return botonAgregar;
    }

    public JButton getBtnBuscar() {
        return botonBuscar;
    }

    public JButton getBtnEditar() {
        return botonEditar;
    }

    public JButton getBtnEliminar() {
        return botonEliminar;
    }

    public JButton getBotonSalirColaborador() {
        return botonSalirColaborador;
    }

    public JTable getTablaColaboradores() {
        return tablaColaboradores;
    }

    public DefaultTableModel getModeloTablaColaboradores() {
        return modeloTablaColaboradores;
    }
}
