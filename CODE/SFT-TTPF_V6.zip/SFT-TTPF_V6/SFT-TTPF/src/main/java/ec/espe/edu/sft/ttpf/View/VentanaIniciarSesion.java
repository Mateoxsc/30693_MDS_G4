package ec.espe.edu.sft.ttpf.View;

import java.awt.*;
import javax.swing.*;

public class VentanaIniciarSesion extends JFrame {

    private JTextField txtUsuario;
    private JPasswordField txtContrasenia;
    private JButton botonIniciarSesion;

    public VentanaIniciarSesion() {
        Color colorFondoBase = new Color(245, 230, 226);
        Color colorCamposBlancos = new Color(253, 246, 244);
        Color colorAzulCapsula = new Color(134, 203, 233);
        Color colorTextoEstilo = new Color(84, 72, 70);
        Color colorBordeSuave = new Color(220, 200, 195);

        setTitle("Iniciar Sesión");
        setSize(450, 420);
        setLocationRelativeTo(null);
        setResizable(false);
        getContentPane().setBackground(colorFondoBase);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        setLayout(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(12, 15, 12, 15);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        Font fuenteTitulo = new Font("Segoe UI", Font.BOLD, 22);
        Font fuenteLabels = new Font("Segoe UI", Font.BOLD, 15);
        Font fuenteCampos = new Font("Segoe UI", Font.PLAIN, 15);

        JPanel panelHeader = new JPanel(new FlowLayout(FlowLayout.CENTER, 12, 0));
        panelHeader.setBackground(colorFondoBase);
        JLabel lblTitulo = new JLabel("INICIAR SESIÓN");
        lblTitulo.setFont(fuenteTitulo);
        lblTitulo.setForeground(colorTextoEstilo);
        panelHeader.add(lblTitulo);

        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.gridwidth = 2;
        gbc.anchor = GridBagConstraints.CENTER;
        add(panelHeader, gbc);

        gbc.gridwidth = 1;
        gbc.anchor = GridBagConstraints.WEST;
        JLabel lblUsuario = new JLabel("Usuario");
        lblUsuario.setFont(fuenteLabels);
        lblUsuario.setForeground(colorTextoEstilo);
        gbc.gridx = 0;
        gbc.gridy = 1;
        add(lblUsuario, gbc);

        txtUsuario = new JTextField() {
            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(colorCamposBlancos);
                g2.fillRoundRect(0, 0, getWidth(), getHeight(), 25, 25);
                g2.setColor(colorBordeSuave);
                g2.drawRoundRect(0, 0, getWidth() - 1, getHeight() - 1, 25, 25);
                g2.dispose();
                super.paintComponent(g);
            }
        };
        txtUsuario.setPreferredSize(new Dimension(220, 38));
        txtUsuario.setFont(fuenteCampos);
        txtUsuario.setForeground(colorTextoEstilo);
        txtUsuario.setOpaque(false);
        txtUsuario.setBorder(BorderFactory.createEmptyBorder(5, 15, 5, 15));
        gbc.gridx = 1;
        gbc.gridy = 1;
        add(txtUsuario, gbc);

        JLabel lblContrasenia = new JLabel("Contraseña");
        lblContrasenia.setFont(fuenteLabels);
        lblContrasenia.setForeground(colorTextoEstilo);
        gbc.gridx = 0;
        gbc.gridy = 2;
        add(lblContrasenia, gbc);

        txtContrasenia = new JPasswordField() {
            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(colorCamposBlancos);
                g2.fillRoundRect(0, 0, getWidth(), getHeight(), 25, 25);
                g2.setColor(colorBordeSuave);
                g2.drawRoundRect(0, 0, getWidth() - 1, getHeight() - 1, 25, 25);
                g2.dispose();
                super.paintComponent(g);
            }
        };
        txtContrasenia.setPreferredSize(new Dimension(220, 38));
        txtContrasenia.setFont(fuenteCampos);
        txtContrasenia.setForeground(colorTextoEstilo);
        txtContrasenia.setOpaque(false);
        txtContrasenia.setBorder(BorderFactory.createEmptyBorder(5, 15, 5, 15));
        gbc.gridx = 1;
        gbc.gridy = 2;
        add(txtContrasenia, gbc);

        botonIniciarSesion = new JButton("Ingresar") {
            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(colorAzulCapsula);
                g2.fillRoundRect(0, 0, getWidth(), getHeight(), 30, 30);
                g2.setColor(colorAzulCapsula.darker());
                g2.drawRoundRect(0, 0, getWidth() - 1, getHeight() - 1, 30, 30);
                g2.dispose();
                super.paintComponent(g);
            }
        };
        botonIniciarSesion.setFont(new Font("Segoe UI", Font.BOLD, 16));
        botonIniciarSesion.setForeground(colorTextoEstilo);
        botonIniciarSesion.setPreferredSize(new Dimension(180, 42));
        botonIniciarSesion.setContentAreaFilled(false);
        botonIniciarSesion.setFocusPainted(false);
        botonIniciarSesion.setBorderPainted(false);

        gbc.gridx = 0;
        gbc.gridy = 3;
        gbc.gridwidth = 2;
        gbc.anchor = GridBagConstraints.CENTER;
        gbc.fill = GridBagConstraints.NONE;
        gbc.insets = new Insets(28, 0, 0, 0);
        add(botonIniciarSesion, gbc);
    }

    public String getUsuario() {
        return txtUsuario.getText();
    }

    public String getContrasenia() {
        return new String(txtContrasenia.getPassword());
    }

    public JButton getBtnIngresar() {
        return botonIniciarSesion;
    }

    public void limpiarCampos() {
        this.txtUsuario.setText("");
        this.txtContrasenia.setText("");
    }

    public void enfocarUsuario() {
        this.txtUsuario.requestFocus();
    }
}