package ec.espe.edu.sft.ttpf.model;

public class Evento {

    private int idEvento;
    private static int id = 1;
    private String nombreEvento;
    private String descripcionEvento;
    private float precioEvento;
    private String tipoEvento;

    public Evento(String nombreEvento, String descripcionEvento, float precioEvento, String tipoEvento) {
        this.idEvento = id++;
        this.nombreEvento = nombreEvento;
        this.descripcionEvento = descripcionEvento;
        this.precioEvento = precioEvento;
        this.tipoEvento = tipoEvento;
    }

    public int getIdEvento() {
        return idEvento;
    }

    public void setIdEvento(int idEvento) {
        this.idEvento = idEvento;
    }

    public String getNombreEvento() {
        return nombreEvento;
    }

    public void setNombreEvento(String nombreEvento) {
        this.nombreEvento = nombreEvento;
    }

    public String getDescripcionEvento() {
        return descripcionEvento;
    }

    public void setDescripcionEvento(String descripcionEvento) {
        this.descripcionEvento = descripcionEvento;
    }

    public float getPrecioEvento() {
        return precioEvento;
    }

    public void setPrecioEvento(float precioEvento) {
        this.precioEvento = precioEvento;
    }

    public String getTipoEvento() {
        return tipoEvento;
    }

    public void setTipoEvento(String tipoEvento) {
        this.tipoEvento = tipoEvento;
    }
}
