package ec.espe.edu.sft.ttpf.View;

import java.awt.*;
import javax.swing.*;

public class VentanaGestionReservas extends JFrame {

    private JButton botonRegresar;

    public VentanaGestionReservas() {
        setTitle("Gestión de Reservas");
        setSize(600, 400);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setUndecorated(true);
        setBackground(new Color(0, 0, 0, 0));

        JPanel panelPrincipal = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2d = (Graphics2D) g.create();
                g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2d.setColor(new Color(238, 224, 255)); 
                g2d.fillRoundRect(0, 0, getWidth(), getHeight(), 40, 40);
                g2d.dispose();
            }
        };
        panelPrincipal.setOpaque(false);
        panelPrincipal.setLayout(new BorderLayout(20, 20));
        panelPrincipal.setBorder(BorderFactory.createEmptyBorder(30, 30, 30, 30));

        JLabel lblTitulo = new JLabel("MÓDULO: GESTIÓN DE RESERVAS", JLabel.CENTER);
        lblTitulo.setFont(new Font("Comic Sans MS", Font.BOLD, 22));
        lblTitulo.setForeground(new Color(74, 40, 120));

        JLabel lblContenido = new JLabel("Aquí irá el diseño de la interfaz para las Reservas.", JLabel.CENTER);
        lblContenido.setFont(new Font("Comic Sans MS", Font.PLAIN, 14));

        botonRegresar = new JButton("Regresar al Menú") {
            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2d = (Graphics2D) g.create();
                g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2d.setColor(new Color(150, 150, 150));
                g2d.fillRoundRect(0, 0, getWidth(), getHeight(), 15, 15);
                g2d.dispose();
                super.paintComponent(g);
            }
        };
        botonRegresar.setFont(new Font("Comic Sans MS", Font.BOLD, 14));
        botonRegresar.setForeground(Color.WHITE);
        botonRegresar.setContentAreaFilled(false);
        botonRegresar.setBorderPainted(false);
        botonRegresar.setFocusPainted(false);

        panelPrincipal.add(lblTitulo, BorderLayout.NORTH);
        panelPrincipal.add(lblContenido, BorderLayout.CENTER);
        panelPrincipal.add(botonRegresar, BorderLayout.SOUTH);
        add(panelPrincipal);
    }

    public JButton getBtnRegresar() {
        return botonRegresar;
    }
}
