package ec.espe.edu.sft.ttpf.model;

public class PaqueteBabyShowerRevelacion extends Evento {

    public PaqueteBabyShowerRevelacion(String nombreEvento, String descripcionEvento, float precioEvento, String tipoEvento) {
        super(nombreEvento, descripcionEvento, precioEvento, tipoEvento);
    }

}
