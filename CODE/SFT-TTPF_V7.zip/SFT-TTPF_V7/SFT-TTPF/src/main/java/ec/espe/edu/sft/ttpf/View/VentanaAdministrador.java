package ec.espe.edu.sft.ttpf.View;

import java.awt.*;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;

public class VentanaAdministrador extends JFrame {

    private JTable tablaReservas;
    private DefaultTableModel modeloTablaReservas;
    private JButton botonGestionColaboradores;
    private JButton botonGestionClientes;
    private JButton botonGestionReservas;
    private JButton botonGestionEventos;
    private JButton botonGestionExtras;
    private JButton botonSalir;

    public VentanaAdministrador() {
        java.awt.Color colorFondoBase = new java.awt.Color(245, 230, 226);
        java.awt.Color colorTarjetaBlanca = new java.awt.Color(253, 246, 244);
        java.awt.Color colorAzulBotones = new java.awt.Color(134, 203, 233);
        java.awt.Color colorSalmonTitulo = new java.awt.Color(246, 187, 142);
        java.awt.Color colorRosaSalir = new java.awt.Color(243, 151, 151);
        java.awt.Color colorTextoEstilo = new java.awt.Color(84, 72, 70);
        java.awt.Color colorBordeInterno = new java.awt.Color(230, 212, 207);

        java.awt.Font fuentePrincipal = new java.awt.Font("Segoe UI", java.awt.Font.BOLD, 17);
        java.awt.Font fuenteBotones = new java.awt.Font("Segoe UI", java.awt.Font.BOLD, 13);
        java.awt.Font fuenteTablas = new java.awt.Font("SansSerif", java.awt.Font.PLAIN, 13);

        setTitle("Ventana Administrador");
        setSize(1200, 650);
        setLayout(new BorderLayout());
        getContentPane().setBackground(colorFondoBase);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        String[] columnas = {"Cédula", "Cliente", "Tipo Evento", "Paquete", "Fecha", "Total", "Abono", "Pendiente", "Estado"};
        modeloTablaReservas = new DefaultTableModel(columnas, 0);
        this.tablaReservas = new JTable(modeloTablaReservas);

        this.tablaReservas.setFont(fuenteTablas);
        this.tablaReservas.setForeground(colorTextoEstilo);
        this.tablaReservas.setRowHeight(28);
        this.tablaReservas.setGridColor(colorBordeInterno);
        this.tablaReservas.setSelectionBackground(new java.awt.Color(205, 233, 245));
        this.tablaReservas.setSelectionForeground(colorTextoEstilo);

        this.tablaReservas.getTableHeader().setFont(fuenteBotones);
        this.tablaReservas.getTableHeader().setBackground(colorAzulBotones);
        this.tablaReservas.getTableHeader().setForeground(colorTextoEstilo);
        this.tablaReservas.getTableHeader().setReorderingAllowed(false);
        this.tablaReservas.getTableHeader().setBorder(javax.swing.BorderFactory.createLineBorder(colorAzulBotones));

        JScrollPane scrollTabla = new JScrollPane(this.tablaReservas);
        scrollTabla.setBorder(javax.swing.BorderFactory.createLineBorder(colorBordeInterno, 1));
        scrollTabla.getViewport().setBackground(colorTarjetaBlanca);

        JPanel panelEncabezado = new JPanel(new FlowLayout(FlowLayout.CENTER, 0, 15));
        panelEncabezado.setBackground(colorFondoBase);

        JPanel panelTablaReservas = new JPanel(new BorderLayout());
        panelTablaReservas.setBackground(colorTarjetaBlanca);
        panelTablaReservas.setBorder(javax.swing.BorderFactory.createCompoundBorder(
                javax.swing.BorderFactory.createEmptyBorder(5, 25, 5, 25),
                javax.swing.BorderFactory.createEmptyBorder(15, 15, 15, 15)
        ));

        JPanel panelBotonesContenedor = new JPanel(new FlowLayout(FlowLayout.CENTER, 0, 15));
        panelBotonesContenedor.setBackground(colorFondoBase);

        JPanel panelBotonesGrid = new JPanel(new GridLayout(2, 3, 25, 15));
        panelBotonesGrid.setBackground(colorFondoBase);

        JLabel etiquetaBienvenidaMenu = new JLabel("BIENVENIDO AL PANEL ADMINISTRADOR", JLabel.CENTER);
        etiquetaBienvenidaMenu.setFont(fuentePrincipal);
        etiquetaBienvenidaMenu.setForeground(colorTextoEstilo);

        JLabel etiquetaTablaDeReservas = new JLabel("  RESERVAS ACTIVAS  ", JLabel.CENTER);
        etiquetaTablaDeReservas.setFont(fuenteBotones);
        etiquetaTablaDeReservas.setForeground(colorTextoEstilo);
        etiquetaTablaDeReservas.setOpaque(true);
        etiquetaTablaDeReservas.setBackground(colorSalmonTitulo);
        etiquetaTablaDeReservas.setBorder(javax.swing.BorderFactory.createLineBorder(colorSalmonTitulo, 4, true));

        JPanel panelContenedorTituloTabla = new JPanel(new FlowLayout(FlowLayout.LEFT, 0, 8));
        panelContenedorTituloTabla.setBackground(colorTarjetaBlanca);
        panelContenedorTituloTabla.add(etiquetaTablaDeReservas);

        Dimension tamanoBotones = new Dimension(220, 42);

        botonGestionColaboradores = new JButton("Gestion Colaboradores");
        botonGestionColaboradores.setPreferredSize(tamanoBotones);
        botonGestionColaboradores.setFont(fuenteBotones);
        botonGestionColaboradores.setBackground(colorAzulBotones);
        botonGestionColaboradores.setForeground(colorTextoEstilo);
        botonGestionColaboradores.setFocusPainted(false);
        botonGestionColaboradores.setBorder(javax.swing.BorderFactory.createLineBorder(colorAzulBotones.darker(), 1, true));

        botonGestionClientes = new JButton("Gestion Clientes");
        botonGestionClientes.setPreferredSize(tamanoBotones);
        botonGestionClientes.setFont(fuenteBotones);
        botonGestionClientes.setBackground(colorAzulBotones);
        botonGestionClientes.setForeground(colorTextoEstilo);
        botonGestionClientes.setFocusPainted(false);
        botonGestionClientes.setBorder(javax.swing.BorderFactory.createLineBorder(colorAzulBotones.darker(), 1, true));

        botonGestionReservas = new JButton("Gestion Reservas");
        botonGestionReservas.setPreferredSize(tamanoBotones);
        botonGestionReservas.setFont(fuenteBotones);
        botonGestionReservas.setBackground(colorAzulBotones);
        botonGestionReservas.setForeground(colorTextoEstilo);
        botonGestionReservas.setFocusPainted(false);
        botonGestionReservas.setBorder(javax.swing.BorderFactory.createLineBorder(colorAzulBotones.darker(), 1, true));

        botonGestionEventos = new JButton("Gestion Servicios");
        botonGestionEventos.setPreferredSize(tamanoBotones);
        botonGestionEventos.setFont(fuenteBotones);
        botonGestionEventos.setBackground(colorAzulBotones);
        botonGestionEventos.setForeground(colorTextoEstilo);
        botonGestionEventos.setFocusPainted(false);
        botonGestionEventos.setBorder(javax.swing.BorderFactory.createLineBorder(colorAzulBotones.darker(), 1, true));

        botonGestionExtras = new JButton("Gestion Extras");
        botonGestionExtras.setPreferredSize(tamanoBotones);
        botonGestionExtras.setFont(fuenteBotones);
        botonGestionExtras.setBackground(colorAzulBotones);
        botonGestionExtras.setForeground(colorTextoEstilo);
        botonGestionExtras.setFocusPainted(false);
        botonGestionExtras.setBorder(javax.swing.BorderFactory.createLineBorder(colorAzulBotones.darker(), 1, true));

        botonSalir = new JButton("Cerrar Sesión");
        botonSalir.setPreferredSize(tamanoBotones);
        botonSalir.setFont(fuenteBotones);
        botonSalir.setBackground(colorRosaSalir);
        botonSalir.setForeground(colorTextoEstilo);
        botonSalir.setFocusPainted(false);
        botonSalir.setBorder(javax.swing.BorderFactory.createLineBorder(colorRosaSalir.darker(), 1, true));

        panelEncabezado.add(etiquetaBienvenidaMenu);

        panelTablaReservas.add(panelContenedorTituloTabla, BorderLayout.NORTH);
        panelTablaReservas.add(scrollTabla, BorderLayout.CENTER);

        panelBotonesGrid.add(botonGestionColaboradores);
        panelBotonesGrid.add(botonGestionClientes);
        panelBotonesGrid.add(botonGestionReservas);

        panelBotonesGrid.add(botonGestionEventos);
        panelBotonesGrid.add(botonGestionExtras);
        panelBotonesGrid.add(botonSalir);

        panelBotonesContenedor.add(panelBotonesGrid);

        add(panelEncabezado, BorderLayout.NORTH);
        add(panelTablaReservas, BorderLayout.CENTER);
        add(panelBotonesContenedor, BorderLayout.SOUTH);

        setLocationRelativeTo(null);
    }

    public JButton getBotonGestionColaboradores() {
        return botonGestionColaboradores;
    }

    public JButton getBotonGestionClientes() {
        return botonGestionClientes;
    }

    public JButton getBotonGestionReservas() {
        return botonGestionReservas;
    }

    public JButton getBotonGestionEventos() {
        return botonGestionEventos;
    }

    public JButton getBotonGestionExtras() {
        return botonGestionExtras;
    }

    public JButton getBotonSalir() {
        return botonSalir;
    }

    public JTable getTablaReservas() {
        return tablaReservas;
    }

    public DefaultTableModel getModeloTablaReservas() {
        return modeloTablaReservas;
    }
}
