package ec.espe.edu.sft.ttpf.controller;

import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import static com.mongodb.client.model.Filters.and;
import static com.mongodb.client.model.Filters.eq;
import com.mongodb.client.model.Updates;
import ec.espe.edu.sft.ttpf.Util.MongoConnection;
import ec.espe.edu.sft.ttpf.View.GestionReservasColaborador;
import ec.espe.edu.sft.ttpf.View.VentanaColaborador;

import java.awt.GridLayout;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import org.bson.Document;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;
import java.util.Date;

public class ReservasColaboradorController {

    private final GestionReservasColaborador vista;
    private final VentanaColaborador vColabPadre;
    private final RolColaboradorController ctrlColabPadre;

    private final MongoCollection<Document> colClientes;
    private final MongoCollection<Document> colEventos;
    private final MongoCollection<Document> colExtras;
    private final MongoCollection<Document> colReservas;

    public ReservasColaboradorController(GestionReservasColaborador vista, VentanaColaborador vColabPadre, RolColaboradorController ctrlColabPadre) {
        this.vista = vista;
        this.vColabPadre = vColabPadre;
        this.ctrlColabPadre = ctrlColabPadre;

        MongoDatabase db = MongoConnection.getDatabase();
        this.colClientes = db.getCollection("clientes");
        this.colEventos = db.getCollection("eventos");
        this.colExtras = db.getCollection("extras");
        this.colReservas = db.getCollection("reservas");

        cargarTiposServicio();
        inicializarEventos();
        cargarExtrasBox();
        limpiarReservasAntiguas();
        cargarTabla();
    }

    private void inicializarEventos() {
        this.vista.getBtnRegresar().addActionListener(e -> {
            this.vista.dispose();
            if (this.vColabPadre != null) {
                if (this.ctrlColabPadre != null) {
                    this.ctrlColabPadre.cargarTablaReservasActivas();
                }
                this.vColabPadre.setVisible(true);
            }
        });

        this.vista.getBtnVerificarCedula().addActionListener(e -> verificarCliente());
        this.vista.getCbTipoServicio().addActionListener(e -> cargarNombresEventos());
        this.vista.getCbNombreEvento().addActionListener(e -> actualizarDetalleEvento());
        this.vista.getCbExtra().addActionListener(e -> actualizarDetalleExtra());

        this.vista.getBtnGuardar().addActionListener(e -> guardarReserva());
        this.vista.getBtnBuscar().addActionListener(e -> buscarReserva());
        this.vista.getBtnRegistrarPago().addActionListener(e -> registrarPago());
    }

    private void limpiarReservasAntiguas() {
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
        LocalDate hoy = LocalDate.now();

        for (Document doc : colReservas.find(eq("estadoPago", "Pagado"))) {
            String fechaStr = doc.getString("fecha");
            if (fechaStr != null && !fechaStr.isEmpty()) {
                try {
                    LocalDate fechaEvento = LocalDate.parse(fechaStr, formatter);
                    long diasTranscurridos = ChronoUnit.DAYS.between(fechaEvento, hoy);

                    if (diasTranscurridos >= 30) {
                        colReservas.deleteOne(eq("_id", doc.getObjectId("_id")));
                    }
                } catch (Exception e) {
                    System.out.println("Error al procesar limpieza automática: " + e.getMessage());
                }
            }
        }
    }

    private void cargarTiposServicio() {
        vista.getCbTipoServicio().removeAllItems();
        vista.getCbTipoServicio().addItem("Seleccione un tipo de evento...");
        for (String tipo : colEventos.distinct("tipoEvento", String.class)) {
            if (tipo != null && !tipo.trim().isEmpty()) {
                vista.getCbTipoServicio().addItem(tipo);
            }
        }
    }

    private void verificarCliente() {
        String cedulaStr = vista.getTxtCedula().getText().trim();
        if (cedulaStr.isEmpty()) {
            JOptionPane.showMessageDialog(vista, "Ingrese una cédula.", "Advertencia", JOptionPane.WARNING_MESSAGE);
            return;
        }

        Document cliente = colClientes.find(eq("cedula", cedulaStr)).first();

        if (cliente == null) {
            try {
                int cedulaInt = Integer.parseInt(cedulaStr);
                cliente = colClientes.find(eq("cedula", cedulaInt)).first();
            } catch (NumberFormatException ignored) {
            }
        }

        if (cliente != null) {
            vista.getTxtNombre().setText(cliente.getString("nombre"));
            vista.getTxtApellido().setText(cliente.getString("apellido"));
            vista.getTxtContacto().setText(cliente.getString("telefono"));
            JOptionPane.showMessageDialog(vista, "Cliente verificado correctamente.", "Información", JOptionPane.INFORMATION_MESSAGE);
        } else {
            JOptionPane.showMessageDialog(vista, "Cliente no encontrado. Registre el cliente primero.", "Advertencia", JOptionPane.WARNING_MESSAGE);
            vista.getTxtNombre().setText("");
            vista.getTxtApellido().setText("");
            vista.getTxtContacto().setText("");
        }
    }

    private void cargarNombresEventos() {
        String tipoSeleccionado = (String) vista.getCbTipoServicio().getSelectedItem();
        vista.getCbNombreEvento().removeAllItems();
        vista.getCbNombreEvento().addItem("Seleccione un paquete...");

        if (tipoSeleccionado != null && !tipoSeleccionado.contains("Seleccione")) {
            for (Document doc : colEventos.find(eq("tipoEvento", tipoSeleccionado))) {
                vista.getCbNombreEvento().addItem(doc.getString("nombreEvento"));
            }
        } else {
            for (Document doc : colEventos.find()) {
                vista.getCbNombreEvento().addItem(doc.getString("nombreEvento"));
            }
        }
    }

    private void actualizarDetalleEvento() {
        String eventoSeleccionado = (String) vista.getCbNombreEvento().getSelectedItem();
        if (eventoSeleccionado != null && !eventoSeleccionado.contains("Seleccione")) {
            Document evento = colEventos.find(eq("nombreEvento", eventoSeleccionado)).first();
            if (evento != null) {
                double precio = ((Number) evento.get("precioEvento")).doubleValue();
                vista.getTxtPrecioEvento().setText(String.format(java.util.Locale.US, "%.2f", precio));
                vista.getTxtDescripcionEvento().setText(evento.getString("descripcionEvento"));
            }
        } else {
            vista.getTxtPrecioEvento().setText("0.00");
            vista.getTxtDescripcionEvento().setText("");
        }
        calcularTotal();
    }

    private void cargarExtrasBox() {
        vista.getCbExtra().removeAllItems();
        vista.getCbExtra().addItem("Sin Extra");
        for (Document doc : colExtras.find()) {
            vista.getCbExtra().addItem(doc.getString("articuloExtra"));
        }
    }

    private void actualizarDetalleExtra() {
        String extraSeleccionado = (String) vista.getCbExtra().getSelectedItem();
        if (extraSeleccionado != null && !extraSeleccionado.equals("Sin Extra")) {
            Document extra = colExtras.find(eq("articuloExtra", extraSeleccionado)).first();
            if (extra != null) {
                double precio = ((Number) extra.get("precioExtra")).doubleValue();
                vista.getTxtPrecioExtra().setText(String.format(java.util.Locale.US, "%.2f", precio));
            }
        } else {
            vista.getTxtPrecioExtra().setText("0.00");
        }
        calcularTotal();
    }

    private void calcularTotal() {
        try {
            double pEvento = Double.parseDouble(vista.getTxtPrecioEvento().getText().replace(",", "."));
            double pExtra = Double.parseDouble(vista.getTxtPrecioExtra().getText().replace(",", "."));
            double total = pEvento + pExtra;
            vista.getTxtPrecioFinal().setText(String.format(java.util.Locale.US, "%.2f", total));
        } catch (NumberFormatException e) {
            vista.getTxtPrecioFinal().setText("0.00");
        }
    }

    private void guardarReserva() {
        if (vista.getTxtNombre().getText().isEmpty()) {
            JOptionPane.showMessageDialog(vista, "Debe verificar un cliente primero.", "Advertencia", JOptionPane.WARNING_MESSAGE);
            return;
        }

        String cbEvento = (String) vista.getCbNombreEvento().getSelectedItem();
        if (cbEvento == null || cbEvento.contains("Seleccione")) {
            JOptionPane.showMessageDialog(vista, "Debe seleccionar un evento válido.", "Advertencia", JOptionPane.WARNING_MESSAGE);
            return;
        }

        Date fechaSeleccionada = vista.getJdcFechaEvento().getDate();
        if (fechaSeleccionada == null) {
            JOptionPane.showMessageDialog(vista, "Por favor, seleccione una fecha en el calendario.", "Advertencia", JOptionPane.WARNING_MESSAGE);
            return;
        }

        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
        String fecha = sdf.format(fechaSeleccionada);
        String cedula = vista.getTxtCedula().getText().trim();

        Document reservaMismaFecha = colReservas.find(and(eq("cedulaCliente", cedula), eq("fecha", fecha))).first();
        if (reservaMismaFecha != null) {
            String msg = "Inconveniente detectado: El cliente con cédula " + cedula + "\nya tiene programada la reserva del evento '"
                    + reservaMismaFecha.getString("evento") + "' para la fecha " + fecha + ".\n\nNo se permiten dos reservas el mismo día.";
            JOptionPane.showMessageDialog(vista, msg, "Error de Conflicto de Fecha", JOptionPane.ERROR_MESSAGE);
            return;
        }

        String clienteNombre = vista.getTxtNombre().getText() + " " + vista.getTxtApellido().getText();
        String extra = (String) vista.getCbExtra().getSelectedItem();
        double total = Double.parseDouble(vista.getTxtPrecioFinal().getText().replace(",", "."));
        
        String tipoServicio = (String) vista.getCbTipoServicio().getSelectedItem();

        Document nuevaReserva = new Document("cedulaCliente", cedula)
                .append("nombreCliente", clienteNombre)
                .append("tipoEvento", tipoServicio) 
                .append("paquete", cbEvento)        
                .append("evento", cbEvento)        
                .append("fecha", fecha)
                .append("extra", extra)
                .append("total", total)
                .append("abono", 0.0)
                .append("saldoPendiente", total)
                .append("estadoPago", "Pendiente");

        colReservas.insertOne(nuevaReserva);
        JOptionPane.showMessageDialog(vista, "¡Reserva guardada con éxito!", "Información", JOptionPane.INFORMATION_MESSAGE);
        cargarTabla();
        limpiarCampos();
    }

    private Document obtenerReservaEspecifica(String cedula) {
        List<Document> reservasEncontradas = new ArrayList<>();
        for (Document res : colReservas.find(eq("cedulaCliente", cedula))) {
            reservasEncontradas.add(res);
        }

        if (reservasEncontradas.isEmpty()) {
            JOptionPane.showMessageDialog(vista, "No se encontraron reservas para esta cédula.", "Advertencia", JOptionPane.WARNING_MESSAGE);
            return null;
        }

        if (reservasEncontradas.size() == 1) {
            return reservasEncontradas.get(0);
        }

        JPanel panelDialogo = new JPanel(new GridLayout(2, 1, 5, 5));
        JComboBox<String> cbFechas = new JComboBox<>();

        for (Document r : reservasEncontradas) {
            cbFechas.addItem(r.getString("fecha") + " - " + r.getString("evento"));
        }

        panelDialogo.add(new JLabel("El cliente posee varias reservas. Seleccione la fecha deseada:"));
        panelDialogo.add(cbFechas);

        int seleccion = JOptionPane.showConfirmDialog(
                vista, 
                panelDialogo, 
                "Seleccionar Reserva Específica", 
                JOptionPane.OK_CANCEL_OPTION, 
                JOptionPane.QUESTION_MESSAGE
        );

        if (seleccion == JOptionPane.OK_OPTION) {
            int index = cbFechas.getSelectedIndex();
            if (index >= 0 && index < reservasEncontradas.size()) {
                return reservasEncontradas.get(index);
            }
        }

        return null; 
    }

    private void registrarPago() {
        String cedulaBusqueda = (String) JOptionPane.showInputDialog(
                vista,
                "Ingrese la cédula del cliente para registrar abono:",
                "Buscar Reserva para Pago",
                JOptionPane.QUESTION_MESSAGE,
                null,
                null,
                ""
        );

        if (cedulaBusqueda == null || cedulaBusqueda.trim().isEmpty()) {
            return;
        }

        Document reserva = obtenerReservaEspecifica(cedulaBusqueda.trim());
        if (reserva == null) {
            return;
        }

        double total = ((Number) reserva.get("total")).doubleValue();
        double abonoActual = reserva.get("abono") != null ? ((Number) reserva.get("abono")).doubleValue() : 0.0;
        double saldoPendiente = reserva.get("saldoPendiente") != null ? ((Number) reserva.get("saldoPendiente")).doubleValue() : total;

        if (saldoPendiente <= 0) {
            JOptionPane.showMessageDialog(vista, "Esta reserva ya se encuentra totalmente PAGADA.", "Información", JOptionPane.INFORMATION_MESSAGE);
            return;
        }

        String inputPago = (String) JOptionPane.showInputDialog(
                vista,
                "--- ESTADO DE CUENTA ---\n"
                + "Cliente: " + reserva.getString("nombreCliente") + "\n"
                + "Evento: " + reserva.getString("evento") + "\n"
                + "Fecha Reserva: " + reserva.getString("fecha") + "\n"
                + "Total Reserva: $" + String.format(java.util.Locale.US, "%.2f", total) + "\n"
                + "Abono Actual: $" + String.format(java.util.Locale.US, "%.2f", abonoActual) + "\n"
                + "Saldo Pendiente: $" + String.format(java.util.Locale.US, "%.2f", saldoPendiente) + "\n\n"
                + "Ingrese el valor a cobrar:",
                "Registrar Abono",
                JOptionPane.QUESTION_MESSAGE
        );

        if (inputPago == null || inputPago.trim().isEmpty()) {
            return;
        }

        try {
            double nuevoPago = Double.parseDouble(inputPago.replace(",", "."));

            if (nuevoPago <= 0) {
                JOptionPane.showMessageDialog(vista, "El valor ingresado debe ser mayor a 0.", "Advertencia", JOptionPane.WARNING_MESSAGE);
                return;
            }
            if (nuevoPago > saldoPendiente) {
                JOptionPane.showMessageDialog(vista, "El valor excede el saldo pendiente. Monto máximo: $" + String.format(java.util.Locale.US, "%.2f", saldoPendiente), "Advertencia", JOptionPane.WARNING_MESSAGE);
                return;
            }

            double nuevoAbono = abonoActual + nuevoPago;
            double nuevoSaldo = total - nuevoAbono;
            String nuevoEstado = (nuevoSaldo <= 0) ? "Pagado" : "Abonado";

            colReservas.updateOne(eq("_id", reserva.getObjectId("_id")),
                    Updates.combine(
                            Updates.set("abono", nuevoAbono),
                            Updates.set("saldoPendiente", nuevoSaldo),
                            Updates.set("estadoPago", nuevoEstado)
                    ));

            JOptionPane.showMessageDialog(vista, "Abono registrado.\nSaldo Pendiente actual: $" + String.format(java.util.Locale.US, "%.2f", nuevoSaldo), "Información", JOptionPane.INFORMATION_MESSAGE);
            cargarTabla();

        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(vista, "Ingrese un número válido (ej. 50.50).", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void cargarTabla() {
        vista.getModeloTablaReservas().setRowCount(0);
        for (Document doc : colReservas.find()) {
            try {
                String cedula = doc.getString("cedulaCliente");
                String cliente = doc.getString("nombreCliente"); 
                
                String tipoEvento = doc.getString("tipoEvento") != null ? doc.getString("tipoEvento") : "No definido";
                String paquete = doc.getString("paquete") != null ? doc.getString("paquete") : doc.getString("evento");

                String fecha = doc.getString("fecha");
                
                double total = doc.get("total") != null ? ((Number) doc.get("total")).doubleValue() : 0.0;
                double abono = doc.get("abono") != null ? ((Number) doc.get("abono")).doubleValue() : 0.0;
                double pendiente = doc.get("saldoPendiente") != null ? ((Number) doc.get("saldoPendiente")).doubleValue() : total;
                String estado = doc.getString("estadoPago") != null ? doc.getString("estadoPago") : "Pendiente";

                vista.getModeloTablaReservas().addRow(new Object[]{
                    cedula,
                    cliente,
                    tipoEvento,
                    paquete,
                    fecha,
                    String.format(java.util.Locale.US, "$%.2f", total),
                    String.format(java.util.Locale.US, "$%.2f", abono),
                    String.format(java.util.Locale.US, "$%.2f", pendiente),
                    estado
                });
            } catch (Exception e) {
                System.out.println("Error procesando una fila de reserva de MongoDB: " + e.getMessage());
            }
        }
    }

    private void buscarReserva() {
        String cedulaBusqueda = (String) JOptionPane.showInputDialog(
                vista,
                "Ingrese la cédula a buscar:",
                "Buscar Reserva",
                JOptionPane.QUESTION_MESSAGE,
                null,
                null,
                ""
        );

        if (cedulaBusqueda == null || cedulaBusqueda.trim().isEmpty()) {
            return;
        }

        Document reserva = obtenerReservaEspecifica(cedulaBusqueda.trim());
        if (reserva != null) {
            double total = reserva.get("total") != null ? ((Number) reserva.get("total")).doubleValue() : 0.0;
            double abono = reserva.get("abono") != null ? ((Number) reserva.get("abono")).doubleValue() : 0.0;
            double pendiente = reserva.get("saldoPendiente") != null ? ((Number) reserva.get("saldoPendiente")).doubleValue() : total;
            String estado = reserva.getString("estadoPago") != null ? reserva.getString("estadoPago") : "Pendiente";

            String info = "--- DATOS DE LA RESERVA ---\n"
                    + "Cédula: " + reserva.getString("cedulaCliente") + "\n"
                    + "Cliente: " + reserva.getString("nombreCliente") + "\n"
                    + "Tipo Evento: " + (reserva.getString("tipoEvento") != null ? reserva.getString("tipoEvento") : "No definido") + "\n"
                    + "Paquete: " + (reserva.getString("paquete") != null ? reserva.getString("paquete") : reserva.getString("evento")) + "\n"
                    + "Fecha: " + reserva.getString("fecha") + "\n"
                    + "Extra: " + reserva.getString("extra") + "\n"
                    + "Total: $" + String.format(java.util.Locale.US, "%.2f", total) + "\n"
                    + "Abono actual: $" + String.format(java.util.Locale.US, "%.2f", abono) + "\n"
                    + "Saldo Pendiente: $" + String.format(java.util.Locale.US, "%.2f", pendiente) + "\n"
                    + "Estado: " + estado;
            JOptionPane.showMessageDialog(vista, info, "Información - Reserva Encontrada", JOptionPane.INFORMATION_MESSAGE);
        }
    }

    private void limpiarCampos() {
        vista.getTxtCedula().setText("");
        vista.getTxtNombre().setText("");
        vista.getTxtApellido().setText("");
        vista.getTxtContacto().setText("");
        vista.getCbTipoServicio().setSelectedIndex(0);
        vista.getCbExtra().setSelectedIndex(0);
        if (vista.getJdcFechaEvento() != null) {
            vista.getJdcFechaEvento().setDate(null);
        }
    }
}