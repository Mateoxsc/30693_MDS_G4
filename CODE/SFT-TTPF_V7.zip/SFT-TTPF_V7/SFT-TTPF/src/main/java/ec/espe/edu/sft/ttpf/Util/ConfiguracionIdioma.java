package ec.espe.edu.sft.ttpf.Util;

import javax.swing.JOptionPane;
import java.util.Locale;

public class ConfiguracionIdioma {

    static {
        JOptionPane.setDefaultLocale(new Locale("es", "ES"));
    }
}
