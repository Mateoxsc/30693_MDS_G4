package ec.espe.edu.sft.ttpf.View;

import com.toedter.calendar.JDateChooser;
import java.awt.*;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;

public class VentanaGestionReservas extends JFrame {

    private final Color colorFondoBase = new Color(245, 230, 226);
    private final Color colorTarjetaBlanca = new Color(253, 246, 244);
    private final Color colorAzulBotones = new Color(134, 203, 233);
    private final Color colorRosaSalir = new Color(243, 151, 151);
    private final Color colorTextoEstilo = new Color(84, 72, 70);
    private final Color colorBordeInterno = new Color(230, 212, 207);
    private final Color colorVerdePagos = new Color(168, 228, 160);

    private final Font fuenteTitulo = new Font("Segoe UI", Font.BOLD, 18);
    private final Font fuenteSubtitulo = new Font("Segoe UI", Font.BOLD, 13);
    private final Font fuenteGeneral = new Font("Segoe UI", Font.PLAIN, 12);
    private final Font fuenteBotones = new Font("Segoe UI", Font.BOLD, 13);

    private JTextField txtCedula;
    private JTextField txtNombre;
    private JTextField txtApellido;
    private JTextField txtContacto;
    private JButton btnVerificarCedula;

    private JComboBox<String> cbTipoServicio;
    private JComboBox<String> cbNombreEvento;
    private JTextField txtPrecioEvento;
    private JTextArea txtDescripcionEvento;

    private JDateChooser jdcFechaEvento;

    private JComboBox<String> cbExtra;
    private JTextField txtPrecioExtra;
    private JTextField txtPrecioFinal;

    private JTable tablaReservas;
    private DefaultTableModel modeloTablaReservas;

    private JButton btnGuardar, btnBuscar, btnEditar, btnEliminar, btnRegistrarPago, btnRegresar;

    public VentanaGestionReservas() {
        setTitle("Gestión de Reservas - Administrador");
        setSize(1250, 720);
        setLayout(new BorderLayout(15, 15));
        getContentPane().setBackground(colorFondoBase);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        JPanel panelEncabezado = new JPanel(new FlowLayout(FlowLayout.CENTER));
        panelEncabezado.setBackground(colorFondoBase);
        JLabel lblTitulo = new JLabel("MÓDULO DE GESTIÓN DE RESERVAS (ADMINISTRADOR)");
        lblTitulo.setFont(fuenteTitulo);
        lblTitulo.setForeground(colorTextoEstilo);
        panelEncabezado.add(lblTitulo);
        add(panelEncabezado, BorderLayout.NORTH);

        JSplitPane splitPane = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT);
        splitPane.setDividerLocation(470);
        splitPane.setBorder(null);
        splitPane.setBackground(colorFondoBase);

        JPanel panelFormulario = new JPanel();
        panelFormulario.setLayout(new BoxLayout(panelFormulario, BoxLayout.Y_AXIS));
        panelFormulario.setBackground(colorTarjetaBlanca);
        panelFormulario.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(colorBordeInterno),
                BorderFactory.createEmptyBorder(15, 15, 15, 15)
        ));

        JLabel lblSeccionCliente = new JLabel("1. Datos del Cliente");
        lblSeccionCliente.setFont(fuenteSubtitulo);
        lblSeccionCliente.setForeground(colorTextoEstilo);
        panelFormulario.add(lblSeccionCliente);
        panelFormulario.add(Box.createRigidArea(new Dimension(0, 8)));

        JPanel gridCliente = new JPanel(new GridLayout(4, 2, 8, 8));
        gridCliente.setBackground(colorTarjetaBlanca);

        txtCedula = new JTextField();
        txtCedula.setFont(fuenteGeneral);
        btnVerificarCedula = new JButton("Verificar");
        btnVerificarCedula.setFont(fuenteGeneral);
        btnVerificarCedula.setBackground(colorAzulBotones);
        btnVerificarCedula.setForeground(colorTextoEstilo);

        JPanel panelCedula = new JPanel(new BorderLayout(5, 0));
        panelCedula.setBackground(colorTarjetaBlanca);
        panelCedula.add(txtCedula, BorderLayout.CENTER);
        panelCedula.add(btnVerificarCedula, BorderLayout.EAST);

        txtNombre = new JTextField();
        txtNombre.setFont(fuenteGeneral);
        txtNombre.setEditable(false);

        txtApellido = new JTextField();
        txtApellido.setFont(fuenteGeneral);
        txtApellido.setEditable(false);

        txtContacto = new JTextField();
        txtContacto.setFont(fuenteGeneral);
        txtContacto.setEditable(false);

        gridCliente.add(crearLabel("Cédula:"));
        gridCliente.add(panelCedula);
        gridCliente.add(crearLabel("Nombre:"));
        gridCliente.add(txtNombre);
        gridCliente.add(crearLabel("Apellido:"));
        gridCliente.add(txtApellido);
        gridCliente.add(crearLabel("Contacto/Teléfono:"));
        gridCliente.add(txtContacto);

        panelFormulario.add(gridCliente);
        panelFormulario.add(Box.createRigidArea(new Dimension(0, 15)));

        JLabel lblSeccionEvento = new JLabel("2. Detalles del Evento");
        lblSeccionEvento.setFont(fuenteSubtitulo);
        lblSeccionEvento.setForeground(colorTextoEstilo);
        panelFormulario.add(lblSeccionEvento);
        panelFormulario.add(Box.createRigidArea(new Dimension(0, 8)));

        JPanel gridEvento = new JPanel(new GridLayout(7, 2, 8, 8));
        gridEvento.setBackground(colorTarjetaBlanca);

        cbTipoServicio = new JComboBox<>(new String[]{"Seleccione...", "Decoraciones", "Fiestas Infantiles", "Paquetes Infantiles", "Baby Shower/Revelación", "Paquetes baby shower revelación"});
        cbTipoServicio.setFont(fuenteGeneral);
        cbNombreEvento = new JComboBox<>(new String[]{"Esperando tipo..."});
        cbNombreEvento.setFont(fuenteGeneral);

        txtPrecioEvento = new JTextField("0.00");
        txtPrecioEvento.setFont(fuenteGeneral);
        txtPrecioEvento.setEditable(false);

        jdcFechaEvento = new JDateChooser();
        jdcFechaEvento.setDateFormatString("dd/MM/yyyy");
        jdcFechaEvento.setFont(fuenteGeneral);

        cbExtra = new JComboBox<>(new String[]{"Sin Extra"});
        cbExtra.setFont(fuenteGeneral);

        txtPrecioExtra = new JTextField("0.00");
        txtPrecioExtra.setFont(fuenteGeneral);
        txtPrecioExtra.setEditable(false);

        txtPrecioFinal = new JTextField("0.00");
        txtPrecioFinal.setFont(new Font("Segoe UI", Font.BOLD, 13));
        txtPrecioFinal.setEditable(false);
        txtPrecioFinal.setBackground(new Color(220, 240, 220));

        gridEvento.add(crearLabel("Tipo Evento:"));
        gridEvento.add(cbTipoServicio);
        gridEvento.add(crearLabel("Paquete:"));
        gridEvento.add(cbNombreEvento);
        gridEvento.add(crearLabel("Precio Base ($):"));
        gridEvento.add(txtPrecioEvento);
        gridEvento.add(crearLabel("Fecha Evento:"));
        gridEvento.add(jdcFechaEvento);
        gridEvento.add(crearLabel("Servicio Extra:"));
        gridEvento.add(cbExtra);
        gridEvento.add(crearLabel("Precio Extra ($):"));
        gridEvento.add(txtPrecioExtra);
        gridEvento.add(crearLabel("Total General ($):"));
        gridEvento.add(txtPrecioFinal);

        panelFormulario.add(gridEvento);
        panelFormulario.add(Box.createRigidArea(new Dimension(0, 10)));

        txtDescripcionEvento = new JTextArea(3, 20);
        txtDescripcionEvento.setFont(fuenteGeneral);
        txtDescripcionEvento.setLineWrap(true);
        txtDescripcionEvento.setWrapStyleWord(true);
        txtDescripcionEvento.setEditable(false);
        JScrollPane scrollDesc = new JScrollPane(txtDescripcionEvento);
        scrollDesc.setBorder(BorderFactory.createLineBorder(colorBordeInterno));

        panelFormulario.add(crearLabel("Descripción del Paquete:"));
        panelFormulario.add(Box.createRigidArea(new Dimension(0, 4)));
        panelFormulario.add(scrollDesc);

        splitPane.setLeftComponent(panelFormulario);

        JPanel panelTabla = new JPanel(new BorderLayout());
        panelTabla.setBackground(colorTarjetaBlanca);
        panelTabla.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(colorBordeInterno),
                BorderFactory.createEmptyBorder(10, 10, 10, 10)
        ));

        JLabel lblTabla = new JLabel("  RESERVAS ACTIVAS EN EL SISTEMA", JLabel.LEFT);
        lblTabla.setFont(fuenteSubtitulo);
        lblTabla.setForeground(colorTextoEstilo);
        panelTabla.add(lblTabla, BorderLayout.NORTH);

        String[] columnas = {"Cédula", "Cliente", "Tipo Evento", "Paquete", "Fecha", "Total", "Abono", "Pendiente", "Estado"};
        modeloTablaReservas = new DefaultTableModel(columnas, 0);
        tablaReservas = new JTable(modeloTablaReservas);
        tablaReservas.setFont(fuenteGeneral);
        tablaReservas.setForeground(colorTextoEstilo);
        tablaReservas.setRowHeight(26);
        tablaReservas.setGridColor(colorBordeInterno);
        tablaReservas.setSelectionBackground(new Color(205, 233, 245));
        tablaReservas.setSelectionForeground(colorTextoEstilo);

        tablaReservas.getTableHeader().setFont(fuenteBotones);
        tablaReservas.getTableHeader().setBackground(colorAzulBotones);
        tablaReservas.getTableHeader().setForeground(colorTextoEstilo);
        tablaReservas.getTableHeader().setReorderingAllowed(false);

        JScrollPane scrollTabla = new JScrollPane(tablaReservas);
        scrollTabla.setBorder(BorderFactory.createLineBorder(colorBordeInterno));
        scrollTabla.getViewport().setBackground(colorTarjetaBlanca);
        panelTabla.add(scrollTabla, BorderLayout.CENTER);

        splitPane.setRightComponent(panelTabla);
        add(splitPane, BorderLayout.CENTER);

        JPanel panelBotones = new JPanel(new FlowLayout(FlowLayout.CENTER, 15, 15));
        panelBotones.setBackground(colorFondoBase);

        Dimension dimBotones = new Dimension(150, 38);

        btnGuardar = estilizarBoton(new JButton("Guardar Reserva"), colorAzulBotones, dimBotones);
        btnBuscar = estilizarBoton(new JButton("Buscar"), colorAzulBotones, dimBotones);
        btnEditar = estilizarBoton(new JButton("Editar"), colorAzulBotones, dimBotones);
        btnEliminar = estilizarBoton(new JButton("Eliminar"), colorAzulBotones, dimBotones);
        btnRegistrarPago = estilizarBoton(new JButton("Registrar Pago"), colorVerdePagos, dimBotones);
        btnRegresar = estilizarBoton(new JButton("Regresar al menú"), colorRosaSalir, dimBotones);

        panelBotones.add(btnGuardar);
        panelBotones.add(btnBuscar);
        panelBotones.add(btnEditar);
        panelBotones.add(btnEliminar);
        panelBotones.add(btnRegistrarPago);
        panelBotones.add(btnRegresar);

        add(panelBotones, BorderLayout.SOUTH);
        setLocationRelativeTo(null);
    }

    private JLabel crearLabel(String texto) {
        JLabel label = new JLabel(texto);
        label.setFont(fuenteGeneral);
        label.setForeground(colorTextoEstilo);
        return label;
    }

    private JButton estilizarBoton(JButton btn, Color color, Dimension dim) {
        btn.setPreferredSize(dim);
        btn.setFont(fuenteBotones);
        btn.setBackground(color);
        btn.setForeground(colorTextoEstilo);
        btn.setFocusPainted(false);
        return btn;
    }

    public JDateChooser getJdcFechaEvento() {
        return jdcFechaEvento;
    }

    public JTextField getTxtCedula() {
        return txtCedula;
    }

    public JTextField getTxtNombre() {
        return txtNombre;
    }

    public JTextField getTxtApellido() {
        return txtApellido;
    }

    public JTextField getTxtContacto() {
        return txtContacto;
    }

    public JButton getBtnVerificarCedula() {
        return btnVerificarCedula;
    }

    public JComboBox<String> getCbTipoServicio() {
        return cbTipoServicio;
    }

    public JComboBox<String> getCbNombreEvento() {
        return cbNombreEvento;
    }

    public JTextField getTxtPrecioEvento() {
        return txtPrecioEvento;
    }

    public JTextArea getTxtDescripcionEvento() {
        return txtDescripcionEvento;
    }

    public JComboBox<String> getCbExtra() {
        return cbExtra;
    }

    public JTextField getTxtPrecioExtra() {
        return txtPrecioExtra;
    }

    public JTextField getTxtPrecioFinal() {
        return txtPrecioFinal;
    }

    public DefaultTableModel getModeloTablaReservas() {
        return modeloTablaReservas;
    }

    public JTable getTablaReservas() {
        return tablaReservas;
    }

    public JButton getBtnGuardar() {
        return btnGuardar;
    }

    public JButton getBtnBuscar() {
        return btnBuscar;
    }

    public JButton getBtnEditar() {
        return btnEditar;
    }

    public JButton getBtnEliminar() {
        return btnEliminar;
    }

    public JButton getBtnRegistrarPago() {
        return btnRegistrarPago;
    }

    public JButton getBtnRegresar() {
        return btnRegresar;
    }
}
