package ec.espe.edu.sft.ttpf.Util;

public class TituloVentanas {

    public static final String VENTANA_INICIO = "INICIO";
    public static final String VENTANA_ADVERTENCIA = "ADVERTENCIA";
    public static final String VENTANA_ERROR = "ERROR";
    public static final String VENTANA_INFO = "INFORMACIÓN";

    //////////////////////////TITULO VENTANAS////////////////////
    public static final String TITULO_ADMINISTRADOR = "ADMINISTRADOR";
    public static final String TITULO_GESTION_EMPLEADO = "GESTION COLABORADOR";
    public static final String TITULO_BUSCAR_CREDENCIALES = "BUSCAR CREDENCIALES";
    public static final String TITULO_EDITAR_COLABORADOR = "EDITAR COLABORADOR";
}
