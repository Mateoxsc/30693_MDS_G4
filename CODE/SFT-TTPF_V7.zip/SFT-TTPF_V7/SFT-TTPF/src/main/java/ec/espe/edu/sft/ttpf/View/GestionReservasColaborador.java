package ec.espe.edu.sft.ttpf.View;

import com.toedter.calendar.JDateChooser;
import java.awt.*;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;

public class GestionReservasColaborador extends JFrame {

    private JTextField txtCedula, txtNombre, txtApellido, txtContacto;
    private JButton btnVerificarCedula;

    private JComboBox<String> cbTipoServicio, cbNombreEvento, cbExtra;
    private JTextField txtPrecioEvento, txtPrecioExtra, txtPrecioFinal;
    private JTextArea txtDescripcionEvento;
    private JDateChooser jdcFechaEvento;

    private JTable tablaReservas;
    private DefaultTableModel modeloTablaReservas;

    private JButton btnGuardar, btnBuscar, btnRegistrarPago, btnRegresar;

    public GestionReservasColaborador() {
        Color colorFondoBase = new Color(245, 230, 226);
        Color colorTarjetaBlanca = new Color(253, 246, 244);
        Color colorAzulBotones = new Color(134, 203, 233);
        Color colorSalmonTitulo = new Color(246, 187, 142);
        Color colorRosaSalir = new Color(243, 151, 151);
        Color colorTextoEstilo = new Color(84, 72, 70);
        Color colorBordeInterno = new Color(230, 212, 207);

        Font fuenteTitulo = new Font("Segoe UI", Font.BOLD, 18);
        Font fuenteSubtitulo = new Font("Segoe UI", Font.BOLD, 13);
        Font fuenteGeneral = new Font("Segoe UI", Font.PLAIN, 12);

        setTitle("Gestión de Reservas - Colaborador");
        setSize(1200, 700);
        setLayout(new BorderLayout(15, 15));
        getContentPane().setBackground(colorFondoBase);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        JPanel panelEncabezado = new JPanel(new FlowLayout(FlowLayout.CENTER));
        panelEncabezado.setBackground(colorFondoBase);
        JLabel lblTitulo = new JLabel("MÓDULO DE RESERVAS (COLABORADOR)");
        lblTitulo.setFont(fuenteTitulo);
        lblTitulo.setForeground(colorTextoEstilo);
        panelEncabezado.add(lblTitulo);
        add(panelEncabezado, BorderLayout.NORTH);

        JSplitPane splitPane = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT);
        splitPane.setDividerLocation(450);
        splitPane.setBorder(null);
        splitPane.setBackground(colorFondoBase);

        JPanel panelFormulario = new JPanel();
        panelFormulario.setLayout(new BoxLayout(panelFormulario, BoxLayout.Y_AXIS));
        panelFormulario.setBackground(colorTarjetaBlanca);
        panelFormulario.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(colorBordeInterno),
                BorderFactory.createEmptyBorder(15, 15, 15, 15)
        ));

        JLabel lblSeccionCliente = new JLabel("1. Datos del Cliente");
        lblSeccionCliente.setFont(fuenteSubtitulo);
        lblSeccionCliente.setForeground(colorTextoEstilo);
        panelFormulario.add(lblSeccionCliente);
        panelFormulario.add(Box.createRigidArea(new Dimension(0, 8)));

        JPanel gridCliente = new JPanel(new GridLayout(3, 2, 8, 8));
        gridCliente.setBackground(colorTarjetaBlanca);

        txtCedula = new JTextField();
        btnVerificarCedula = new JButton("Verificar");
        btnVerificarCedula.setBackground(colorAzulBotones);
        btnVerificarCedula.setForeground(colorTextoEstilo);

        JPanel panelCedula = new JPanel(new BorderLayout(5, 0));
        panelCedula.setBackground(colorTarjetaBlanca);
        panelCedula.add(txtCedula, BorderLayout.CENTER);
        panelCedula.add(btnVerificarCedula, BorderLayout.EAST);

        txtNombre = new JTextField();
        txtNombre.setEditable(false);
        txtApellido = new JTextField();
        txtApellido.setEditable(false);
        txtContacto = new JTextField();
        txtContacto.setEditable(false);

        gridCliente.add(new JLabel("Cédula:"));
        gridCliente.add(panelCedula);
        gridCliente.add(new JLabel("Nombre:"));
        gridCliente.add(txtNombre);
        gridCliente.add(new JLabel("Teléfono:"));
        gridCliente.add(txtContacto);
        panelFormulario.add(gridCliente);
        panelFormulario.add(Box.createRigidArea(new Dimension(0, 15)));

        JLabel lblSeccionEvento = new JLabel("2. Detalles del Evento");
        lblSeccionEvento.setFont(fuenteSubtitulo);
        lblSeccionEvento.setForeground(colorTextoEstilo);
        panelFormulario.add(lblSeccionEvento);
        panelFormulario.add(Box.createRigidArea(new Dimension(0, 8)));

        JPanel gridEvento = new JPanel(new GridLayout(7, 2, 8, 8));
        gridEvento.setBackground(colorTarjetaBlanca);

        cbTipoServicio = new JComboBox<>();
        cbNombreEvento = new JComboBox<>();
        cbExtra = new JComboBox<>();

        txtPrecioEvento = new JTextField("0.00");
        txtPrecioEvento.setEditable(false);
        txtPrecioExtra = new JTextField("0.00");
        txtPrecioExtra.setEditable(false);
        txtPrecioFinal = new JTextField("0.00");
        txtPrecioFinal.setEditable(false);
        txtPrecioFinal.setFont(new Font("Segoe UI", Font.BOLD, 13));

        jdcFechaEvento = new JDateChooser();
        jdcFechaEvento.setDateFormatString("dd/MM/yyyy");

        gridEvento.add(new JLabel("Tipo Evento:"));
        gridEvento.add(cbTipoServicio);
        gridEvento.add(new JLabel("Paquete:"));
        gridEvento.add(cbNombreEvento);
        gridEvento.add(new JLabel("Precio Base:"));
        gridEvento.add(txtPrecioEvento);
        gridEvento.add(new JLabel("Fecha Evento:"));
        gridEvento.add(jdcFechaEvento);
        gridEvento.add(new JLabel("Servicio Extra:"));
        gridEvento.add(cbExtra);
        gridEvento.add(new JLabel("Precio Extra:"));
        gridEvento.add(txtPrecioExtra);
        gridEvento.add(new JLabel("Total General:"));
        gridEvento.add(txtPrecioFinal);
        panelFormulario.add(gridEvento);
        panelFormulario.add(Box.createRigidArea(new Dimension(0, 10)));

        txtDescripcionEvento = new JTextArea(3, 20);
        txtDescripcionEvento.setLineWrap(true);
        txtDescripcionEvento.setWrapStyleWord(true);
        txtDescripcionEvento.setEditable(false);
        JScrollPane scrollDesc = new JScrollPane(txtDescripcionEvento);
        panelFormulario.add(new JLabel("Descripción del Paquete:"));
        panelFormulario.add(scrollDesc);

        splitPane.setLeftComponent(panelFormulario);

        JPanel panelTabla = new JPanel(new BorderLayout());
        panelTabla.setBackground(colorTarjetaBlanca);
        panelTabla.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(colorBordeInterno),
                BorderFactory.createEmptyBorder(10, 10, 10, 10)
        ));

        JLabel lblTabla = new JLabel("   RESERVAS ACTIVAS EN EL SISTEMA", JLabel.LEFT);
        lblTabla.setFont(fuenteSubtitulo);
        lblTabla.setForeground(colorTextoEstilo);
        panelTabla.add(lblTabla, BorderLayout.NORTH);

        String[] columnas = {"Cédula", "Cliente", "Tipo Evento", "Paquete", "Fecha", "Total", "Abono", "Pendiente", "Estado"};
        modeloTablaReservas = new DefaultTableModel(columnas, 0);
        tablaReservas = new JTable(modeloTablaReservas);
        tablaReservas.setRowHeight(25);
        tablaReservas.setGridColor(colorBordeInterno);
        JScrollPane scrollTabla = new JScrollPane(tablaReservas);
        panelTabla.add(scrollTabla, BorderLayout.CENTER);

        splitPane.setRightComponent(panelTabla);
        add(splitPane, BorderLayout.CENTER);

        JPanel panelBotones = new JPanel(new FlowLayout(FlowLayout.CENTER, 20, 15));
        panelBotones.setBackground(colorFondoBase);

        Dimension dimBotones = new Dimension(160, 40);

        btnGuardar = new JButton("Guardar Reserva");
        btnGuardar.setPreferredSize(dimBotones);
        btnGuardar.setBackground(colorAzulBotones);
        btnGuardar.setForeground(colorTextoEstilo);

        btnBuscar = new JButton("Buscar Reserva");
        btnBuscar.setPreferredSize(dimBotones);
        btnBuscar.setBackground(colorAzulBotones);
        btnBuscar.setForeground(colorTextoEstilo);

        btnRegistrarPago = new JButton("Registrar Pago/Abono");
        btnRegistrarPago.setPreferredSize(dimBotones);
        btnRegistrarPago.setBackground(colorSalmonTitulo);
        btnRegistrarPago.setForeground(colorTextoEstilo);

        btnRegresar = new JButton("Regresar");
        btnRegresar.setPreferredSize(dimBotones);
        btnRegresar.setBackground(colorRosaSalir);
        btnRegresar.setForeground(colorTextoEstilo);

        panelBotones.add(btnGuardar);
        panelBotones.add(btnBuscar);
        panelBotones.add(btnRegistrarPago);
        panelBotones.add(btnRegresar);

        add(panelBotones, BorderLayout.SOUTH);
        setLocationRelativeTo(null);
    }

    public JTextField getTxtCedula() {
        return txtCedula;
    }

    public JTextField getTxtNombre() {
        return txtNombre;
    }

    public JTextField getTxtApellido() {
        return txtApellido;
    }

    public JTextField getTxtContacto() {
        return txtContacto;
    }

    public JButton getBtnVerificarCedula() {
        return btnVerificarCedula;
    }

    public JComboBox<String> getCbTipoServicio() {
        return cbTipoServicio;
    }

    public JComboBox<String> getCbNombreEvento() {
        return cbNombreEvento;
    }

    public JComboBox<String> getCbExtra() {
        return cbExtra;
    }

    public JTextField getTxtPrecioEvento() {
        return txtPrecioEvento;
    }

    public JTextField getTxtPrecioExtra() {
        return txtPrecioExtra;
    }

    public JTextField getTxtPrecioFinal() {
        return txtPrecioFinal;
    }

    public JTextArea getTxtDescripcionEvento() {
        return txtDescripcionEvento;
    }

    public JDateChooser getJdcFechaEvento() {
        return jdcFechaEvento;
    }

    public JTable getTablaReservas() {
        return tablaReservas;
    }

    public DefaultTableModel getModeloTablaReservas() {
        return modeloTablaReservas;
    }

    public JButton getBtnGuardar() {
        return btnGuardar;
    }

    public JButton getBtnBuscar() {
        return btnBuscar;
    }

    public JButton getBtnRegistrarPago() {
        return btnRegistrarPago;
    }

    public JButton getBtnRegresar() {
        return btnRegresar;
    }
}
