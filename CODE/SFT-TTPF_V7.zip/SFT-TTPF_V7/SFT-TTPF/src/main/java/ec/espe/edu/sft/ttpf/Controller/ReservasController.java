package ec.espe.edu.sft.ttpf.controller;

import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import static com.mongodb.client.model.Filters.eq;
import static com.mongodb.client.model.Filters.and;
import com.mongodb.client.model.Updates;
import ec.espe.edu.sft.ttpf.Util.MongoConnection;
import ec.espe.edu.sft.ttpf.View.VentanaGestionReservas;
import ec.espe.edu.sft.ttpf.View.VentanaAdministrador;

import java.awt.GridLayout;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import org.bson.Document;

import com.toedter.calendar.JDateChooser;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;
import java.util.Date;

public class ReservasController {

    private VentanaGestionReservas vista;
    private VentanaAdministrador vAdminPadre;

    private MongoCollection<Document> colClientes;
    private MongoCollection<Document> colEventos;
    private MongoCollection<Document> colExtras;
    private MongoCollection<Document> colReservas;

    public ReservasController(VentanaGestionReservas vista, VentanaAdministrador vAdminPadre) {
        this.vista = vista;
        this.vAdminPadre = vAdminPadre;

        MongoDatabase db = MongoConnection.getDatabase();
        this.colClientes = db.getCollection("clientes");
        this.colEventos = db.getCollection("eventos");
        this.colExtras = db.getCollection("extras");
        this.colReservas = db.getCollection("reservas");

        cargarTiposServicio();
        inicializarEventos();
        cargarExtrasBox();

        limpiarReservasAntiguas();

        cargarTabla();
    }

    private void limpiarReservasAntiguas() {
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
        LocalDate hoy = LocalDate.now();

        for (Document doc : colReservas.find(eq("estadoPago", "Pagado"))) {
            String fechaStr = doc.getString("fecha");

            if (fechaStr != null && !fechaStr.isEmpty()) {
                try {
                    LocalDate fechaEvento = LocalDate.parse(fechaStr, formatter);
                    long diasTranscurridos = ChronoUnit.DAYS.between(fechaEvento, hoy);

                    if (diasTranscurridos >= 30) {
                        colReservas.deleteOne(eq("_id", doc.getObjectId("_id")));
                        System.out.println("Reserva antigua eliminada automáticamente: " + doc.getString("cedulaCliente"));
                    }
                } catch (Exception e) {
                    System.out.println("Error al procesar fecha para limpieza automática: " + e.getMessage());
                }
            }
        }
    }

    private void inicializarEventos() {
        this.vista.getBtnRegresar().addActionListener(e -> {
            this.vista.dispose();
            if (this.vAdminPadre != null) {
                this.vAdminPadre.setVisible(true);
            }
        });

        this.vista.getBtnVerificarCedula().addActionListener(e -> verificarCliente());
        this.vista.getCbTipoServicio().addActionListener(e -> cargarNombresEventos());
        this.vista.getCbNombreEvento().addActionListener(e -> actualizarDetalleEvento());
        this.vista.getCbExtra().addActionListener(e -> actualizarDetalleExtra());

        this.vista.getBtnGuardar().addActionListener(e -> guardarReserva());
        this.vista.getBtnBuscar().addActionListener(e -> buscarReserva());
        this.vista.getBtnEliminar().addActionListener(e -> eliminarReserva());
        this.vista.getBtnEditar().addActionListener(e -> editarReserva());

        this.vista.getBtnRegistrarPago().addActionListener(e -> registrarPago());
    }

    private void cargarTiposServicio() {
        vista.getCbTipoServicio().removeAllItems();
        vista.getCbTipoServicio().addItem("Seleccione un tipo de evento...");

        for (String tipo : colEventos.distinct("tipoEvento", String.class)) {
            if (tipo != null && !tipo.trim().isEmpty()) {
                vista.getCbTipoServicio().addItem(tipo);
            }
        }
    }

    private void verificarCliente() {
        String cedulaStr = vista.getTxtCedula().getText().trim();

        if (cedulaStr.isEmpty()) {
            JOptionPane.showMessageDialog(vista, "Ingrese una cédula.", "Advertencia", JOptionPane.WARNING_MESSAGE);
            return;
        }

        int cedulaInt;
        try {
            cedulaInt = Integer.parseInt(cedulaStr);
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(vista, "La cédula debe contener solo números.", "Error de Formato", JOptionPane.ERROR_MESSAGE);
            return;
        }

        Document cliente = colClientes.find(eq("cedula", cedulaInt)).first();

        if (cliente != null) {
            vista.getTxtNombre().setText(cliente.getString("nombre"));
            vista.getTxtApellido().setText(cliente.getString("apellido"));
            vista.getTxtContacto().setText(cliente.getString("telefono"));
        } else {
            JOptionPane.showMessageDialog(vista, "Cliente no encontrado. Por favor, regístrelo primero en Módulo Clientes.", "Advertencia", JOptionPane.WARNING_MESSAGE);
            vista.getTxtNombre().setText("");
            vista.getTxtApellido().setText("");
            vista.getTxtContacto().setText("");
        }
    }

    private void cargarNombresEventos() {
        String tipoSeleccionado = (String) vista.getCbTipoServicio().getSelectedItem();
        vista.getCbNombreEvento().removeAllItems();
        vista.getCbNombreEvento().addItem("Seleccione un paquete...");

        if (tipoSeleccionado != null && !tipoSeleccionado.contains("Seleccione")) {
            for (Document doc : colEventos.find(eq("tipoEvento", tipoSeleccionado))) {
                vista.getCbNombreEvento().addItem(doc.getString("nombreEvento"));
            }
        } else {
            for (Document doc : colEventos.find()) {
                vista.getCbNombreEvento().addItem(doc.getString("nombreEvento"));
            }
        }
    }

    private void actualizarDetalleEvento() {
        String eventoSeleccionado = (String) vista.getCbNombreEvento().getSelectedItem();
        if (eventoSeleccionado != null && !eventoSeleccionado.contains("Seleccione")) {
            Document evento = colEventos.find(eq("nombreEvento", eventoSeleccionado)).first();
            if (evento != null) {
                double precio = ((Number) evento.get("precioEvento")).doubleValue();
                vista.getTxtPrecioEvento().setText(String.format("%.2f", precio).replace(",", "."));
                vista.getTxtDescripcionEvento().setText(evento.getString("descripcionEvento"));
            }
        } else {
            vista.getTxtPrecioEvento().setText("0.00");
            vista.getTxtDescripcionEvento().setText("");
        }
        calcularTotal();
    }

    private void cargarExtrasBox() {
        vista.getCbExtra().removeAllItems();
        vista.getCbExtra().addItem("Sin Extra");
        for (Document doc : colExtras.find()) {
            vista.getCbExtra().addItem(doc.getString("articuloExtra"));
        }
    }

    private void actualizarDetalleExtra() {
        String extraSeleccionado = (String) vista.getCbExtra().getSelectedItem();
        if (extraSeleccionado != null && !extraSeleccionado.equals("Sin Extra")) {
            Document extra = colExtras.find(eq("articuloExtra", extraSeleccionado)).first();
            if (extra != null) {
                double precio = ((Number) extra.get("precioExtra")).doubleValue();
                vista.getTxtPrecioExtra().setText(String.format("%.2f", precio).replace(",", "."));
            }
        } else {
            vista.getTxtPrecioExtra().setText("0.00");
        }
        calcularTotal();
    }

    private void calcularTotal() {
        try {
            double pEvento = Double.parseDouble(vista.getTxtPrecioEvento().getText().replace(",", "."));
            double pExtra = Double.parseDouble(vista.getTxtPrecioExtra().getText().replace(",", "."));
            double total = pEvento + pExtra;
            vista.getTxtPrecioFinal().setText(String.format("%.2f", total).replace(",", "."));
        } catch (NumberFormatException e) {
            vista.getTxtPrecioFinal().setText("0.00");
        }
    }

    private void guardarReserva() {
        if (vista.getTxtNombre().getText().isEmpty()) {
            JOptionPane.showMessageDialog(vista, "Debe verificar un cliente primero.", "Advertencia", JOptionPane.WARNING_MESSAGE);
            return;
        }

        String cedula = vista.getTxtCedula().getText();

        String cbTipoEvento = (String) vista.getCbTipoServicio().getSelectedItem();
        if (cbTipoEvento == null || cbTipoEvento.contains("Seleccione")) {
            JOptionPane.showMessageDialog(vista, "Debe seleccionar un tipo de evento válido.", "Advertencia", JOptionPane.WARNING_MESSAGE);
            return;
        }

        String cbEvento = (String) vista.getCbNombreEvento().getSelectedItem();
        if (cbEvento == null || cbEvento.contains("Seleccione")) {
            JOptionPane.showMessageDialog(vista, "Debe seleccionar un paquete válido.", "Advertencia", JOptionPane.WARNING_MESSAGE);
            return;
        }

        Date fechaSeleccionada = vista.getJdcFechaEvento().getDate();
        if (fechaSeleccionada == null) {
            JOptionPane.showMessageDialog(vista, "Por favor, seleccione una fecha válida en el calendario.", "Advertencia", JOptionPane.WARNING_MESSAGE);
            return;
        }

        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
        String fecha = sdf.format(fechaSeleccionada);

        Document reservaExistenteMismaFecha = colReservas.find(and(eq("cedulaCliente", cedula), eq("fecha", fecha))).first();
        if (reservaExistenteMismaFecha != null) {
            JOptionPane.showMessageDialog(vista,
                    "El cliente con cédula " + cedula + " ya cuenta con una reserva programada para el " + fecha + ".\n"
                    + "Por favor, elija otra fecha para la nueva reserva.",
                    "Reserva Duplicada en Fecha",
                    JOptionPane.ERROR_MESSAGE);
            return;
        }

        String clienteNombre = vista.getTxtNombre().getText() + " " + vista.getTxtApellido().getText();
        String extra = (String) vista.getCbExtra().getSelectedItem();
        double total = Double.parseDouble(vista.getTxtPrecioFinal().getText().replace(",", "."));

        Document nuevaReserva = new Document("cedulaCliente", cedula)
                .append("nombreCliente", clienteNombre)
                .append("tipoEvento", cbTipoEvento)
                .append("evento", cbEvento)
                .append("fecha", fecha)
                .append("extra", extra)
                .append("total", total)
                .append("abono", 0.0)
                .append("saldoPendiente", total)
                .append("estadoPago", "Pendiente");

        colReservas.insertOne(nuevaReserva);
        JOptionPane.showMessageDialog(vista, "¡Reserva guardada con éxito para el cliente: " + clienteNombre + "!", "Información", JOptionPane.INFORMATION_MESSAGE);
        cargarTabla();
        limpiarCampos();
    }

    private void registrarPago() {
        String cedulaBusqueda = JOptionPane.showInputDialog(vista, "Ingrese la cédula del cliente para registrar el pago o abono:");
        if (cedulaBusqueda == null || cedulaBusqueda.trim().isEmpty()) {
            return;
        }

        Document reserva = obtenerReservaEspecifica(cedulaBusqueda.trim());
        if (reserva == null) {
            return;
        }

        double total = ((Number) reserva.get("total")).doubleValue();
        double abonoActual = reserva.get("abono") != null ? ((Number) reserva.get("abono")).doubleValue() : 0.0;
        double saldoPendiente = reserva.get("saldoPendiente") != null ? ((Number) reserva.get("saldoPendiente")).doubleValue() : total;

        if (saldoPendiente <= 0) {
            JOptionPane.showMessageDialog(vista, "Esta reserva ya se encuentra totalmente PAGADA.", "Información", JOptionPane.INFORMATION_MESSAGE);
            return;
        }

        String inputPago = JOptionPane.showInputDialog(vista,
                "--- ESTADO DE CUENTA ---\n"
                + "Cliente: " + reserva.getString("nombreCliente") + "\n"
                + "Fecha Reserva: " + reserva.getString("fecha") + "\n"
                + "Total Reserva: $" + String.format("%.2f", total) + "\n"
                + "Abono Actual: $" + String.format("%.2f", abonoActual) + "\n"
                + "Saldo Pendiente: $" + String.format("%.2f", saldoPendiente) + "\n\n"
                + "Ingrese el valor a cancelar (puede ser un adelanto o el total):");

        if (inputPago == null || inputPago.trim().isEmpty()) {
            return;
        }

        try {
            double nuevoPago = Double.parseDouble(inputPago.replace(",", "."));

            if (nuevoPago <= 0) {
                JOptionPane.showMessageDialog(vista, "El valor ingresado debe ser mayor a 0.", "Advertencia", JOptionPane.WARNING_MESSAGE);
                return;
            }
            if (nuevoPago > saldoPendiente) {
                JOptionPane.showMessageDialog(vista, "El valor excede el saldo pendiente. El monto máximo a cobrar es $" + String.format("%.2f", saldoPendiente), "Advertencia", JOptionPane.WARNING_MESSAGE);
                return;
            }

            double nuevoAbono = abonoActual + nuevoPago;
            double nuevoSaldo = total - nuevoAbono;
            String nuevoEstado = (nuevoSaldo <= 0) ? "Pagado" : "Abonado";

            colReservas.updateOne(eq("_id", reserva.getObjectId("_id")),
                    Updates.combine(
                            Updates.set("abono", nuevoAbono),
                            Updates.set("saldoPendiente", nuevoSaldo),
                            Updates.set("estadoPago", nuevoEstado)
                    ));

            JOptionPane.showMessageDialog(vista, "Pago registrado exitosamente.\nNuevo Saldo Pendiente: $" + String.format("%.2f", nuevoSaldo) + "\nEstado: " + nuevoEstado, "Información", JOptionPane.INFORMATION_MESSAGE);
            cargarTabla();

        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(vista, "Valor inválido. Por favor, ingrese un número (ej. 50.50).", "Error de Formato", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void cargarTabla() {
        vista.getModeloTablaReservas().setRowCount(0);
        for (Document doc : colReservas.find()) {
            double total = doc.get("total") != null ? ((Number) doc.get("total")).doubleValue() : 0.0;
            double abono = doc.get("abono") != null ? ((Number) doc.get("abono")).doubleValue() : 0.0;
            double pendiente = doc.get("saldoPendiente") != null ? ((Number) doc.get("saldoPendiente")).doubleValue() : total;
            String estado = doc.getString("estadoPago") != null ? doc.getString("estadoPago") : "Pendiente";

            String tipoEvento = doc.getString("tipoEvento") != null ? doc.getString("tipoEvento") : "No definido";

            vista.getModeloTablaReservas().addRow(new Object[]{
                doc.getString("cedulaCliente"),
                doc.getString("nombreCliente"),
                tipoEvento, 
                doc.getString("evento"),
                doc.getString("fecha"),
                String.format("$%.2f", total),
                String.format("$%.2f", abono),
                String.format("$%.2f", pendiente),
                estado
            });
        }
    }

    private void limpiarCampos() {
        vista.getTxtCedula().setText("");
        vista.getTxtNombre().setText("");
        vista.getTxtApellido().setText("");
        vista.getTxtContacto().setText("");
        vista.getCbTipoServicio().setSelectedIndex(0);
        vista.getCbExtra().setSelectedIndex(0);

        if (vista.getJdcFechaEvento() != null) {
            vista.getJdcFechaEvento().setDate(null);
        }
    }

    private Document obtenerReservaEspecifica(String cedula) {
        List<Document> reservas = new ArrayList<>();
        for (Document r : colReservas.find(eq("cedulaCliente", cedula))) {
            reservas.add(r);
        }

        if (reservas.isEmpty()) {
            JOptionPane.showMessageDialog(vista, "No se encontraron reservas para esta cédula.", "Información", JOptionPane.INFORMATION_MESSAGE);
            return null;
        }

        if (reservas.size() == 1) {
            return reservas.get(0);
        }

        JPanel panelDesplegable = new JPanel(new GridLayout(2, 1, 10, 10));
        JComboBox<String> cbFechas = new JComboBox<>();

        for (Document r : reservas) {
            cbFechas.addItem(r.getString("fecha") + " - " + r.getString("evento"));
        }

        panelDesplegable.add(new JLabel("Se detectaron varias reservas. Seleccione la fecha/evento:"));
        panelDesplegable.add(cbFechas);

        int confirmResult = JOptionPane.showConfirmDialog(vista, panelDesplegable,
                "Múltiples Reservas Encontradas", JOptionPane.OK_CANCEL_OPTION, JOptionPane.QUESTION_MESSAGE);

        if (confirmResult == JOptionPane.OK_OPTION) {
            int idx = cbFechas.getSelectedIndex();
            if (idx >= 0 && idx < reservas.size()) {
                return reservas.get(idx);
            }
        }
        return null;
    }

    private void buscarReserva() {
        String cedulaBusqueda = JOptionPane.showInputDialog(vista, "Ingrese la cédula del cliente a buscar:");
        if (cedulaBusqueda == null || cedulaBusqueda.trim().isEmpty()) {
            return;
        }

        Document reserva = obtenerReservaEspecifica(cedulaBusqueda.trim());
        if (reserva != null) {
            double total = reserva.get("total") != null ? ((Number) reserva.get("total")).doubleValue() : 0.0;
            double abono = reserva.get("abono") != null ? ((Number) reserva.get("abono")).doubleValue() : 0.0;
            double pendiente = reserva.get("saldoPendiente") != null ? ((Number) reserva.get("saldoPendiente")).doubleValue() : total;
            String estado = reserva.getString("estadoPago") != null ? reserva.getString("estadoPago") : "Pendiente";
            String tipoEv = reserva.getString("tipoEvento") != null ? reserva.getString("tipoEvento") : "No definido";

            String info = "--- DATOS DE LA RESERVA ---\n"
                    + "Cédula: " + reserva.getString("cedulaCliente") + "\n"
                    + "Cliente: " + reserva.getString("nombreCliente") + "\n"
                    + "Tipo de Evento: " + tipoEv + "\n" // NUEVO
                    + "Paquete: " + reserva.getString("evento") + "\n"
                    + "Fecha: " + reserva.getString("fecha") + "\n"
                    + "Extra: " + reserva.getString("extra") + "\n"
                    + "Total a Pagar: $" + String.format("%.2f", total) + "\n"
                    + "Abono actual: $" + String.format("%.2f", abono) + "\n"
                    + "Saldo Pendiente: $" + String.format("%.2f", pendiente) + "\n"
                    + "Estado de Pago: " + estado;
            JOptionPane.showMessageDialog(vista, info, "Reserva Encontrada", JOptionPane.INFORMATION_MESSAGE);
        }
    }

    private void eliminarReserva() {
        String cedulaBusqueda = JOptionPane.showInputDialog(vista, "Ingrese la cédula del cliente para eliminar su reserva:");
        if (cedulaBusqueda == null || cedulaBusqueda.trim().isEmpty()) {
            return;
        }

        Document reserva = obtenerReservaEspecifica(cedulaBusqueda.trim());
        if (reserva != null) {
            int confirm = JOptionPane.showConfirmDialog(vista,
                    "¿Eliminar reserva de " + reserva.getString("nombreCliente")
                    + " para el evento '" + reserva.getString("evento") + "' del " + reserva.getString("fecha") + "?",
                    "Confirmar Eliminación", JOptionPane.YES_NO_OPTION);

            if (confirm == JOptionPane.YES_OPTION) {
                colReservas.deleteOne(eq("_id", reserva.getObjectId("_id")));
                JOptionPane.showMessageDialog(vista, "Reserva eliminada exitosamente.", "Información", JOptionPane.INFORMATION_MESSAGE);
                cargarTabla();
            }
        }
    }

    private void editarReserva() {
        String cedulaBusqueda = JOptionPane.showInputDialog(vista, "Ingrese la cédula del cliente a editar:");
        if (cedulaBusqueda == null || cedulaBusqueda.trim().isEmpty()) {
            return;
        }

        Document reserva = obtenerReservaEspecifica(cedulaBusqueda.trim());
        if (reserva == null) {
            return;
        }

        JPanel panelEditar = new JPanel(new GridLayout(5, 2, 10, 10));

        JComboBox<String> cbEditarTipoServicio = new JComboBox<>();
        cbEditarTipoServicio.addItem("Seleccione un tipo de evento...");
        for (String tipo : colEventos.distinct("tipoEvento", String.class)) {
            if (tipo != null && !tipo.trim().isEmpty()) {
                cbEditarTipoServicio.addItem(tipo);
            }
        }

        JComboBox<String> cbEditarEvento = new JComboBox<>();

        cbEditarTipoServicio.addActionListener(e -> {
            String tipoSeleccionado = (String) cbEditarTipoServicio.getSelectedItem();
            cbEditarEvento.removeAllItems();
            if (tipoSeleccionado != null && !tipoSeleccionado.contains("Seleccione")) {
                for (Document doc : colEventos.find(eq("tipoEvento", tipoSeleccionado))) {
                    cbEditarEvento.addItem(doc.getString("nombreEvento"));
                }
            }
        });

        String tipoActual = reserva.getString("tipoEvento");
        String eventoActual = reserva.getString("evento");

        if (tipoActual != null) {
            cbEditarTipoServicio.setSelectedItem(tipoActual);
        } else {
            Document docEventoActual = colEventos.find(eq("nombreEvento", eventoActual)).first();
            if (docEventoActual != null) {
                cbEditarTipoServicio.setSelectedItem(docEventoActual.getString("tipoEvento"));
            }
        }
        cbEditarEvento.setSelectedItem(eventoActual);

        JComboBox<String> cbEditarExtra = new JComboBox<>();
        cbEditarExtra.addItem("Sin Extra");
        for (Document doc : colExtras.find()) {
            cbEditarExtra.addItem(doc.getString("articuloExtra"));
        }
        cbEditarExtra.setSelectedItem(reserva.getString("extra"));

        JDateChooser jdcEditarFecha = new JDateChooser();
        jdcEditarFecha.setDateFormatString("dd/MM/yyyy");
        try {
            SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
            Date fechaActual = sdf.parse(reserva.getString("fecha"));
            jdcEditarFecha.setDate(fechaActual);
        } catch (ParseException ex) {
            jdcEditarFecha.setDate(null);
        }

        double abonoActual = reserva.get("abono") != null ? ((Number) reserva.get("abono")).doubleValue() : 0.0;
        JTextField txtEditarAbono = new JTextField(String.format("%.2f", abonoActual).replace(",", "."));

        panelEditar.add(new JLabel("Tipo de Servicio:"));
        panelEditar.add(cbEditarTipoServicio);
        panelEditar.add(new JLabel("Evento:"));
        panelEditar.add(cbEditarEvento);
        panelEditar.add(new JLabel("Nueva Fecha:"));
        panelEditar.add(jdcEditarFecha);
        panelEditar.add(new JLabel("Nuevo Extra:"));
        panelEditar.add(cbEditarExtra);
        panelEditar.add(new JLabel("Monto Abonado ($):"));
        panelEditar.add(txtEditarAbono);

        int result = JOptionPane.showConfirmDialog(vista, panelEditar, "Editar Reserva", JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);

        if (result == JOptionPane.OK_OPTION) {
            if (jdcEditarFecha.getDate() == null) {
                JOptionPane.showMessageDialog(vista, "Fecha inválida. Edición cancelada.", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }
            if (cbEditarEvento.getSelectedItem() == null || cbEditarTipoServicio.getSelectedItem().toString().contains("Seleccione")) {
                JOptionPane.showMessageDialog(vista, "Selección de tipo o evento inválida. Edición cancelada.", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }

            double nuevoAbono;
            try {
                nuevoAbono = Double.parseDouble(txtEditarAbono.getText().replace(",", "."));
                if (nuevoAbono < 0) {
                    JOptionPane.showMessageDialog(vista, "El abono no puede ser menor a 0. Edición cancelada.", "Error", JOptionPane.ERROR_MESSAGE);
                    return;
                }
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(vista, "Monto de abono inválido. Edición cancelada.", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }

            SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
            String nuevaFechaStr = sdf.format(jdcEditarFecha.getDate());
            String nuevoTipoEvento = cbEditarTipoServicio.getSelectedItem().toString(); // Extraer nuevo tipo
            String nuevoEvento = cbEditarEvento.getSelectedItem().toString();
            String nuevoExtra = cbEditarExtra.getSelectedItem().toString();

            Document reservaExistenteMismaFecha = colReservas.find(and(eq("cedulaCliente", cedulaBusqueda.trim()), eq("fecha", nuevaFechaStr))).first();
            if (reservaExistenteMismaFecha != null && !reservaExistenteMismaFecha.getObjectId("_id").equals(reserva.getObjectId("_id"))) {
                JOptionPane.showMessageDialog(vista,
                        "No se pudo guardar la edición porque el cliente ya tiene otra reserva en la fecha " + nuevaFechaStr + ".",
                        "Error de Conflicto de Fecha",
                        JOptionPane.ERROR_MESSAGE);
                return;
            }

            double precioEvento = 0.0;
            Document eventoDoc = colEventos.find(eq("nombreEvento", nuevoEvento)).first();
            if (eventoDoc != null) {
                precioEvento = ((Number) eventoDoc.get("precioEvento")).doubleValue();
            }

            double precioExtra = 0.0;
            if (!nuevoExtra.equals("Sin Extra")) {
                Document extraDoc = colExtras.find(eq("articuloExtra", nuevoExtra)).first();
                if (extraDoc != null) {
                    precioExtra = ((Number) extraDoc.get("precioExtra")).doubleValue();
                }
            }

            double nuevoTotal = precioEvento + precioExtra;

            if (nuevoAbono > nuevoTotal) {
                JOptionPane.showMessageDialog(vista,
                        "El abono ingresado ($" + String.format("%.2f", nuevoAbono) + ") es mayor al nuevo costo total ($" + String.format("%.2f", nuevoTotal) + ").\n"
                        + "Se ajustará el abono al total del evento y se marcará como totalmente pagado.",
                        "Ajuste Automático", JOptionPane.WARNING_MESSAGE);
                nuevoAbono = nuevoTotal;
            }

            double nuevoSaldo = nuevoTotal - nuevoAbono;
            String nuevoEstado = (nuevoSaldo <= 0) ? "Pagado" : (nuevoAbono > 0 ? "Abonado" : "Pendiente");

            colReservas.updateOne(eq("_id", reserva.getObjectId("_id")),
                    Updates.combine(
                            Updates.set("tipoEvento", nuevoTipoEvento), // NUEVO
                            Updates.set("evento", nuevoEvento),
                            Updates.set("fecha", nuevaFechaStr),
                            Updates.set("extra", nuevoExtra),
                            Updates.set("total", nuevoTotal),
                            Updates.set("abono", nuevoAbono),
                            Updates.set("saldoPendiente", nuevoSaldo),
                            Updates.set("estadoPago", nuevoEstado)
                    ));

            JOptionPane.showMessageDialog(vista, "Reserva actualizada correctamente.", "Información", JOptionPane.INFORMATION_MESSAGE);
            cargarTabla();
        }
    }
}
