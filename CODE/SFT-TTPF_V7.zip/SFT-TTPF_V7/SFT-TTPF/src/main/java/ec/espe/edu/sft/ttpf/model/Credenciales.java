package ec.espe.edu.sft.ttpf.model;

public class Credenciales {

    public static final String USUARIO_ADMIN = "1";//"MERYADMIN"
    public static final String CONTRASENIA_ADMIN = "0";//"ADMINISTRADOR_2003*"

}
