package ec.espe.edu.sft.ttpf.controller;

import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import ec.espe.edu.sft.ttpf.Util.MongoConnection;
import ec.espe.edu.sft.ttpf.View.GestionReservasColaborador;
import javax.swing.table.DefaultTableModel;
import org.bson.Document;

import ec.espe.edu.sft.ttpf.View.VentanaColaborador;
import ec.espe.edu.sft.ttpf.View.VentanaGestionClientes;
import javax.swing.JFrame;

public class RolColaboradorController {

    private final VentanaColaborador vista;
    private final JFrame vistaPadre;

    public RolColaboradorController(VentanaColaborador vista, JFrame vistaPadre) {
        this.vista = vista;
        this.vistaPadre = vistaPadre;
        inicializarEventos();
        cargarTablaReservasActivas();
    }

    private void inicializarEventos() {
        this.vista.getBotonGestionClientes().addActionListener(e -> {
            VentanaGestionClientes vClientes = new VentanaGestionClientes();
            vClientes.configurarModoColaborador();

            if (this.vistaPadre instanceof ec.espe.edu.sft.ttpf.View.VentanaIniciarSesion) {
                this.vista.setVisible(false);
                new ClientesController(vClientes, this.vista);
                vClientes.setVisible(true);
            }
        });

        this.vista.getBotonGestionReservas().addActionListener(e -> {
            this.vista.setVisible(false);

            GestionReservasColaborador vReservasColab = new GestionReservasColaborador();

            new ReservasColaboradorController(vReservasColab, this.vista, this);

            vReservasColab.setVisible(true);
        });

        this.vista.getBotonSalir().addActionListener(e -> {
            this.vista.dispose();
            if (this.vistaPadre != null) {
                this.vistaPadre.setVisible(true);
            }
        });
    }

    public void cargarTablaReservasActivas() {
        DefaultTableModel modelo = vista.getModeloTablaReservas();
        modelo.setRowCount(0);

        try {
            MongoDatabase db = MongoConnection.getDatabase();
            MongoCollection<Document> colReservas = db.getCollection("reservas");

            for (Document doc : colReservas.find()) {
                try {
                    String cedula = doc.getString("cedulaCliente");
                    String cliente = doc.getString("nombreCliente");

                    String tipoEvento = doc.getString("tipoEvento") != null ? doc.getString("tipoEvento") : "No definido";
                    String paquete = doc.getString("paquete") != null ? doc.getString("paquete") : doc.getString("evento");

                    String fecha = doc.getString("fecha");

                    double total = doc.get("total") != null ? ((Number) doc.get("total")).doubleValue() : 0.0;
                    double abono = doc.get("abono") != null ? ((Number) doc.get("abono")).doubleValue() : 0.0;
                    double pendiente = doc.get("saldoPendiente") != null ? ((Number) doc.get("saldoPendiente")).doubleValue() : total;
                    String estado = doc.getString("estadoPago") != null ? doc.getString("estadoPago") : "Pendiente";

                    modelo.addRow(new Object[]{
                        cedula,
                        cliente,
                        tipoEvento,
                        paquete, 
                        fecha,
                        String.format(java.util.Locale.US, "$%.2f", total),
                        String.format(java.util.Locale.US, "$%.2f", abono),
                        String.format(java.util.Locale.US, "$%.2f", pendiente),
                        estado
                    });
                } catch (Exception e) {
                    System.out.println("Error al cargar fila individual en Colaborador: " + e.getMessage());
                }
            }
        } catch (Exception e) {
            System.out.println("Error general al conectar/cargar MongoDB en Colaborador: " + e.getMessage());
        }
    }
}
