package ec.espe.edu.sft.ttpf.controller;

import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import ec.espe.edu.sft.ttpf.Util.MongoConnection;
import javax.swing.table.DefaultTableModel;
import org.bson.Document;

import ec.espe.edu.sft.ttpf.View.VentanaAdministrador;
import ec.espe.edu.sft.ttpf.View.VentanaGestionColaboradores;
import ec.espe.edu.sft.ttpf.View.VentanaGestionClientes;
import ec.espe.edu.sft.ttpf.View.VentanaGestionReservas;
import ec.espe.edu.sft.ttpf.View.VentanaGestionEventos;
import ec.espe.edu.sft.ttpf.View.VentanaGestionExtras;
import ec.espe.edu.sft.ttpf.View.VentanaIniciarSesion;
import javax.swing.JFrame;

public class AdministradorController {

    private VentanaAdministrador vista;
    private JFrame ventanaIniciarSesion;

    public AdministradorController(VentanaAdministrador vista, JFrame ventanaIniciarSesion) {
        this.vista = vista;
        this.ventanaIniciarSesion = ventanaIniciarSesion;
        inicializarEventos();
        cargarTablaReservasActivas(); 
    }

    public AdministradorController(VentanaAdministrador vista) {
        this.vista = vista;
        this.ventanaIniciarSesion = null;
        inicializarEventos();
        cargarTablaReservasActivas();
    }

    private void inicializarEventos() {
        vista.getBotonGestionColaboradores().addActionListener(e -> abrirGestionColaboradores());
        vista.getBotonGestionClientes().addActionListener(e -> abrirGestionClientes());
        vista.getBotonGestionReservas().addActionListener(e -> abrirGestionReservas());
        vista.getBotonGestionEventos().addActionListener(e -> abrirGestionEventos());
        vista.getBotonGestionExtras().addActionListener(e -> abrirGestionExtras());
        vista.getBotonSalir().addActionListener(e -> cerrarSesion());
    }

   public void cargarTablaReservasActivas() {
        DefaultTableModel modelo = vista.getModeloTablaReservas();
        modelo.setRowCount(0);

        MongoDatabase db = MongoConnection.getDatabase();
        MongoCollection<Document> colReservas = db.getCollection("reservas");

        for (Document doc : colReservas.find()) {
            try {
                String cedula = doc.getString("cedulaCliente");
                String cliente = doc.getString("nombreCliente"); 
                
                String tipoEvento = doc.getString("tipoEvento") != null ? doc.getString("tipoEvento") : "No definido";
                String paquete = doc.getString("paquete") != null ? doc.getString("paquete") : doc.getString("evento"); 

                String fecha = doc.getString("fecha");
                
                double total = doc.get("total") != null ? ((Number) doc.get("total")).doubleValue() : 0.0;
                double abono = doc.get("abono") != null ? ((Number) doc.get("abono")).doubleValue() : 0.0;
                double pendiente = doc.get("saldoPendiente") != null ? ((Number) doc.get("saldoPendiente")).doubleValue() : total;
                String estado = doc.getString("estadoPago") != null ? doc.getString("estadoPago") : "Pendiente";

                modelo.addRow(new Object[]{
                    cedula, 
                    cliente, 
                    tipoEvento,  
                    paquete,     
                    fecha, 
                    String.format("$%.2f", total), 
                    String.format("$%.2f", abono), 
                    String.format("$%.2f", pendiente), 
                    estado
                });
            } catch (Exception e) {
                System.out.println("Error al cargar reserva en admin: " + e.getMessage());
            }
        }
    }

    private void abrirGestionColaboradores() {
        vista.setVisible(false);
        VentanaGestionColaboradores vistaColab = new VentanaGestionColaboradores();
        new ColaboradoresController(vistaColab, vista);
        vistaColab.setVisible(true);
    }

    private void abrirGestionClientes() {
        vista.setVisible(false);
        VentanaGestionClientes vistaClientes = new VentanaGestionClientes();
        new ClientesController(vistaClientes, vista);
        vistaClientes.setVisible(true);
    }

    private void abrirGestionReservas() {
        vista.setVisible(false);
        VentanaGestionReservas vistaReservas = new VentanaGestionReservas();
        new ReservasController(vistaReservas, vista);
        vistaReservas.setVisible(true);
    }

    private void abrirGestionEventos() {
        vista.setVisible(false);
        VentanaGestionEventos vistaEventos = new VentanaGestionEventos();
        new EventosController(vistaEventos, vista);
        vistaEventos.setVisible(true);
    }

    private void abrirGestionExtras() {
        vista.setVisible(false);
        VentanaGestionExtras vistaExtras = new VentanaGestionExtras();
        new ExtrasController(vistaExtras, vista);
        vistaExtras.setVisible(true);
    }

    private void cerrarSesion() {
        vista.dispose();
        if (this.ventanaIniciarSesion != null) {
            this.ventanaIniciarSesion.setVisible(true);
        } else {
            VentanaIniciarSesion nuevoLogin = new VentanaIniciarSesion();
            new LoginController(nuevoLogin);
            nuevoLogin.setVisible(true);
        }
    }
}