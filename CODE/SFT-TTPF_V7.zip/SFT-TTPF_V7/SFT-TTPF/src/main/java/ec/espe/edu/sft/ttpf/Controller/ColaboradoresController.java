package ec.espe.edu.sft.ttpf.controller;

import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import static com.mongodb.client.model.Filters.eq;
import static com.mongodb.client.model.Filters.or;
import com.mongodb.client.model.Updates;
import ec.espe.edu.sft.ttpf.Util.MongoConnection;
import ec.espe.edu.sft.ttpf.View.VentanaGestionColaboradores;
import ec.espe.edu.sft.ttpf.View.VentanaAdministrador;
import ec.espe.edu.sft.ttpf.Util.MensajesSistema;
import ec.espe.edu.sft.ttpf.Util.TituloVentanas;
import javax.swing.JOptionPane;
import org.bson.Document;

public class ColaboradoresController {

    private final VentanaGestionColaboradores vista;
    private final VentanaAdministrador ventanaAdministrador;
    private final MongoCollection<Document> coleccionColaboradores;

    public ColaboradoresController(VentanaGestionColaboradores vista, VentanaAdministrador ventanaAdministrador) {
        this.vista = vista;
        this.ventanaAdministrador = ventanaAdministrador;

        MongoDatabase db = MongoConnection.getDatabase();
        this.coleccionColaboradores = db.getCollection("colaboradores");

        inicializarEventos();
        cargarDatosDesdeMongoDB();
    }

    private void inicializarEventos() {
        vista.getBtnAgregar().addActionListener(e -> agregarColaborador());
        vista.getBtnBuscar().addActionListener(e -> buscarColaborador());
        vista.getBtnEditar().addActionListener(e -> editarColaborador());
        vista.getBtnEliminar().addActionListener(e -> eliminarColaborador());

        vista.getBotonSalirColaborador().addActionListener(e -> {
            vista.dispose();
            if (ventanaAdministrador != null) {
                ventanaAdministrador.setVisible(true);
            }
        });
    }

private void cargarDatosDesdeMongoDB() {
        vista.getModeloTablaColaboradores().setRowCount(0);

        for (Document doc : coleccionColaboradores.find()) {
            String cedulaMostrar = "";
            if (doc.get("cedula") != null) {
                cedulaMostrar = String.valueOf(doc.get("cedula"));
            }

            vista.getModeloTablaColaboradores().addRow(new Object[]{
                cedulaMostrar,
                doc.getString("nombre"),
                doc.getString("usuario"),
                doc.getString("contrasenia"),
                doc.getString("telefono")
            });
        }
    }
    private void agregarColaborador() {
        String nombre = vista.getTxtNombreColaborador().getText().trim();
        String cedulaStr = vista.getTxtCedulaColaborador().getText().trim();
        String usuario = vista.getTxtUsuarioColaborador().getText().trim();
        String contrasenia = new String(vista.getTxtContraseniaColaborador().getPassword()).trim();

        if (nombre.isBlank() || cedulaStr.isBlank() || usuario.isBlank() || contrasenia.isBlank()) {
            JOptionPane.showMessageDialog(vista, MensajesSistema.ERROR_CAMPOS_VACIOS, TituloVentanas.VENTANA_ADVERTENCIA, JOptionPane.WARNING_MESSAGE);
            return;
        }

        if (!ec.espe.edu.sft.ttpf.Util.ValidacionCrearUsuarioCliente.validarCedula(cedulaStr)) {
            JOptionPane.showMessageDialog(vista, MensajesSistema.ERROR_CEDULA_INVALIDA, TituloVentanas.VENTANA_ERROR, JOptionPane.ERROR_MESSAGE);
            return;
        }

        try {
            Long.parseLong(cedulaStr);
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(vista, MensajesSistema.ERROR_CEDULA_SOLO_NUMEROS, TituloVentanas.VENTANA_ERROR, JOptionPane.ERROR_MESSAGE);
            return;
        }

        Document duplicado = coleccionColaboradores.find(
                or(
                        eq("cedula", cedulaStr),
                        eq("usuario", usuario)
                )
        ).first();

        if (duplicado != null) {
            Object cedBD = duplicado.get("cedula");
            String cedBDStr = (cedBD instanceof Integer) ? String.valueOf(cedBD) : duplicado.getString("cedula");

            if (cedStrEquals(cedBDStr, cedulaStr)) {
                JOptionPane.showMessageDialog(vista, MensajesSistema.ERROR_CEDULA_DUPLICADA, TituloVentanas.VENTANA_ERROR, JOptionPane.ERROR_MESSAGE);
            } else {
                JOptionPane.showMessageDialog(vista, MensajesSistema.ERROR_USUARIO_DUPLICADO, TituloVentanas.VENTANA_ERROR, JOptionPane.ERROR_MESSAGE);
            }
            return;
        }

        String telefonoInput = vista.getTxtTelefonoColaborador().getText().trim();
        if (!telefonoInput.matches("^0\\d{9}$")) {
            JOptionPane.showMessageDialog(vista,
                    "El número de teléfono no es válido.\nDebe comenzar con '0' y tener exactamente 10 dígitos.",
                    "Error de Validación",
                    JOptionPane.ERROR_MESSAGE);
            return;
        }

        Document nuevoColaborador = new Document("cedula", cedulaStr)
                .append("nombre", nombre)
                .append("usuario", usuario)
                .append("contrasenia", contrasenia)
                .append("telefono", telefonoInput);

        coleccionColaboradores.insertOne(nuevoColaborador);

        cargarDatosDesdeMongoDB();

        vista.getTxtNombreColaborador().setText("");
        vista.getTxtCedulaColaborador().setText("");
        vista.getTxtUsuarioColaborador().setText("");
        vista.getTxtContraseniaColaborador().setText("");
        vista.getTxtTelefonoColaborador().setText("");

        JOptionPane.showMessageDialog(vista, MensajesSistema.EXITO_COLABORADOR_AGREGADO, TituloVentanas.VENTANA_INFO, JOptionPane.INFORMATION_MESSAGE);
    }

    private void buscarColaborador() {
        String cedulaBuscar = JOptionPane.showInputDialog(vista, MensajesSistema.INFO_INGRESO_CEDULA_BUSCAR, "Buscar Credenciales", JOptionPane.QUESTION_MESSAGE);

        if (cedulaBuscar == null || cedulaBuscar.trim().isEmpty()) {
            return;
        }
        cedulaBuscar = cedulaBuscar.trim();

        Document colab = coleccionColaboradores.find(eq("cedula", cedulaBuscar)).first();

        if (colab == null) {
            try {
                int cedulaInt = Integer.parseInt(cedulaBuscar);
                colab = coleccionColaboradores.find(eq("cedula", cedulaInt)).first();
            } catch (NumberFormatException ignored) {
            }
        }

        if (colab != null) {
            Object cedObj = colab.get("cedula");
            String cedulaEncontrada = (cedObj instanceof Integer) ? String.valueOf(cedObj) : colab.getString("cedula");

            String info = "Información del Colaborador:\n\n"
                    + "Nombre: " + colab.getString("nombre") + "\n"
                    + "Cédula: " + cedulaEncontrada + "\n"
                    + "Usuario: " + colab.getString("usuario") + "\n"
                    + "Contraseña: " + colab.getString("contrasenia") + "\n"
                    + "Teléfono: " + colab.getString("telefono");
            JOptionPane.showMessageDialog(vista, info, "Credenciales Encontradas", JOptionPane.INFORMATION_MESSAGE);
        } else {
            JOptionPane.showMessageDialog(vista, MensajesSistema.ADVERTENCIA_COLABORADOR_NO_ENCONTRADO, TituloVentanas.VENTANA_ADVERTENCIA, JOptionPane.WARNING_MESSAGE);
        }
    }

    private void editarColaborador() {
        String cedulaBuscar = JOptionPane.showInputDialog(vista, "Ingrese la Cédula del colaborador a editar:", "Editar Colaborador", JOptionPane.QUESTION_MESSAGE);

        if (cedulaBuscar == null) {
            return;
        }
        cedulaBuscar = cedulaBuscar.trim();
        if (cedulaBuscar.isEmpty()) {
            JOptionPane.showMessageDialog(vista, "Debe ingresar una cédula para buscar.", "Error", JOptionPane.WARNING_MESSAGE);
            return;
        }

        Document colabDoc = coleccionColaboradores.find(eq("cedula", cedulaBuscar)).first();
        Object filtroId = cedulaBuscar;

        if (colabDoc == null) {
            try {
                int cedulaInt = Integer.parseInt(cedulaBuscar);
                colabDoc = coleccionColaboradores.find(eq("cedula", cedulaInt)).first();
                if (colabDoc != null) {
                    filtroId = cedulaInt; // Mantiene compatibilidad si era numérico
                }
            } catch (NumberFormatException ignored) {
            }
        }

        if (colabDoc == null) {
            JOptionPane.showMessageDialog(vista, "El colaborador con cédula " + cedulaBuscar + " no está registrado.", "No Encontrado", JOptionPane.ERROR_MESSAGE);
            return;
        }

        String nombreActual = colabDoc.getString("nombre");
        String usuarioActual = colabDoc.getString("usuario");
        String contraseniaActual = colabDoc.getString("contrasenia");
        String telefonoActual = colabDoc.getString("telefono");

        String[] nuevosDatos = vista.mostrarFormularioEditar(nombreActual, usuarioActual, contraseniaActual, telefonoActual);

        if (nuevosDatos == null || nuevosDatos[0] == null) {
            return;
        }
        String nombre = nuevosDatos[0];
        String usuario = nuevosDatos[1];
        String contrasenia = nuevosDatos[2];
        String telefono = nuevosDatos[3];

        if (nombre.isEmpty() || usuario.isEmpty() || contrasenia.isEmpty() || telefono.isEmpty()) {
            JOptionPane.showMessageDialog(vista, "Error: No se pueden guardar campos vacíos.", "Campos Vacíos", JOptionPane.WARNING_MESSAGE);
            return;
        }

        if (!telefono.matches("^0\\d{9}$")) {
            JOptionPane.showMessageDialog(vista, "El número de teléfono no es válido.\nDebe comenzar con '0' y tener exactamente 10 dígitos.", "Error de Validación", JOptionPane.ERROR_MESSAGE);
            return;
        }

        coleccionColaboradores.updateOne(
                eq("cedula", filtroId),
                Updates.combine(
                        Updates.set("nombre", nombre),
                        Updates.set("usuario", usuario),
                        Updates.set("contrasenia", contrasenia),
                        Updates.set("telefono", telefono)
                )
        );

        cargarDatosDesdeMongoDB();

        JOptionPane.showMessageDialog(vista, "Cambios guardados exitosamente", "Éxito", JOptionPane.INFORMATION_MESSAGE);
    }

    private void eliminarColaborador() {
        String cedulaEliminar = JOptionPane.showInputDialog(vista, MensajesSistema.INFO_INGRESO_CEDULA_ELIMINAR, "Eliminar Colaborador", JOptionPane.QUESTION_MESSAGE);

        if (cedulaEliminar == null || cedulaEliminar.trim().isEmpty()) {
            return;
        }
        cedulaEliminar = cedulaEliminar.trim();

        Document docExiste = coleccionColaboradores.find(eq("cedula", cedulaEliminar)).first();
        Object filtroId = cedulaEliminar;

        if (docExiste == null) {
            try {
                int cedulaInt = Integer.parseInt(cedulaEliminar);
                docExiste = coleccionColaboradores.find(eq("cedula", cedulaInt)).first();
                if (docExiste != null) {
                    filtroId = cedulaInt;
                }
            } catch (NumberFormatException ignored) {
            }
        }

        if (docExiste != null) {
            enclosedEliminar(filtroId, cedulaEliminar);
        } else {
            JOptionPane.showMessageDialog(vista, MensajesSistema.ADVERTENCIA_COLABORADOR_NO_ENCONTRADO, TituloVentanas.VENTANA_ADVERTENCIA, JOptionPane.WARNING_MESSAGE);
        }
    }

    private void enclosedEliminar(Object filtroId, String cedulaStr) {
        int confirmacion = JOptionPane.showConfirmDialog(vista, MensajesSistema.CONFIRMACION_ELIMINAR_COLABORADOR + cedulaStr + "?", "Confirmar Eliminación", JOptionPane.YES_NO_OPTION);
        if (confirmacion == JOptionPane.YES_OPTION) {

            coleccionColaboradores.deleteOne(eq("cedula", filtroId));

            cargarDatosDesdeMongoDB();

            JOptionPane.showMessageDialog(vista, MensajesSistema.EXITO_COLABORADOR_ELIMINADO, TituloVentanas.VENTANA_INFO, JOptionPane.INFORMATION_MESSAGE);
        }
    }

    private boolean cedStrEquals(String s1, String s2) {
        if (s1 == null || s2 == null) {
            return false;
        }
        return s1.trim().equals(s2.trim());
    }
}
