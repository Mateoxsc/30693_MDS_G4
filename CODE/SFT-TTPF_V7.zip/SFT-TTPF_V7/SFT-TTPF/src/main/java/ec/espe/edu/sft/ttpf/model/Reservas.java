package ec.espe.edu.sft.ttpf.model;

public class Reservas {

    private Cliente cliente;
    private Evento evento;
    private Extra extra;

    public Reservas(Cliente cliente, Evento evento, Extra extra) {
        this.cliente = cliente;
        this.evento = evento;
        this.extra = extra;
    }

    public Cliente getCliente() {
        return cliente;
    }

    public void setCliente(Cliente cliente) {
        this.cliente = cliente;
    }

    public Evento getEvento() {
        return evento;
    }

    public void setEvento(Evento evento) {
        this.evento = evento;
    }

    public Extra getExtra() {
        return extra;
    }

    public void setExtra(Extra extra) {
        this.extra = extra;
    }

    @Override
    public String toString() {
        return "Reserva del Cliente: " + cliente.getNombre() + " " + cliente.getApellido() + "\n"
                + "Evento: " + evento.getNombreEvento() + " - $" + evento.getPrecioEvento() + "\n"
                + "Extra: " + extra.getArticuloExtra() + " - $" + extra.getPrecioExtra();
    }
}