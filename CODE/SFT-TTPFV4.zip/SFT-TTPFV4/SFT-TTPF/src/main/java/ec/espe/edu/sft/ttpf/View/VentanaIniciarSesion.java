package ec.espe.edu.sft.ttpf.View;

import ec.espe.edu.sft.ttpf.Util.TituloVentanas;
import java.awt.*;
import javax.swing.*;

public class VentanaIniciarSesion extends JFrame {

    private JTextField campoTextoUsuario;
    private JPasswordField campoTextoContrasenia;
    private JButton btnIngresar;

    public VentanaIniciarSesion() {
        Color colorFondoBase = new Color(245, 230, 226);
        Color colorCamposBlancos = new Color(253, 246, 244);
        Color colorAzulCapsula = new Color(134, 203, 233);
        Color colorTextoEstilo = new Color(84, 72, 70);
        Color colorBordeSuave = new Color(220, 200, 195);

        setTitle("Iniciar Sesión");
        setSize(450, 420);
        setLocationRelativeTo(null);
        setResizable(false);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        getContentPane().setBackground(colorFondoBase);

        setLayout(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(12, 15, 12, 15);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        Font fuenteTitulo = new Font("Segoe UI", Font.BOLD, 22);
        Font fuenteLabels = new Font("Segoe UI", Font.BOLD, 15);
        Font fuenteCampos = new Font("Segoe UI", Font.PLAIN, 15);

        JPanel panelHeader = new JPanel(new FlowLayout(FlowLayout.CENTER, 12, 0));
        panelHeader.setBackground(colorFondoBase);

        JLabel lblTitulo = new JLabel("INICIAR SESIÓN");
        lblTitulo.setFont(fuenteTitulo);
        lblTitulo.setForeground(colorTextoEstilo);
        panelHeader.add(lblTitulo);

        try {
            java.net.URL imgURL = getClass().getResource("/ec/espe/edu/sft/ttpf/imagenes/logo.png");
            if (imgURL != null) {
                ImageIcon iconoOriginal = new ImageIcon(imgURL);
                Image imagenRedim = iconoOriginal.getImage().getScaledInstance(45, 45, Image.SCALE_SMOOTH);
                JLabel lblLogo = new JLabel(new ImageIcon(imagenRedim));
                panelHeader.add(lblLogo);
            }
        } catch (Exception e) {
            System.out.println("Sugerencia: Coloca tu logo en la carpeta de imágenes para que se muestre.");
        }

        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.gridwidth = 2;
        gbc.anchor = GridBagConstraints.CENTER;
        add(panelHeader, gbc);

        gbc.gridwidth = 1;
        gbc.anchor = GridBagConstraints.WEST;
        JLabel lblUsuario = new JLabel("Usuario");
        lblUsuario.setFont(fuenteLabels);
        lblUsuario.setForeground(colorTextoEstilo);
        gbc.gridx = 0;
        gbc.gridy = 1;
        add(lblUsuario, gbc);

        campoTextoUsuario = new JTextField() {
            @Override
            protected void paintComponent(java.awt.Graphics g) {
                java.awt.Graphics2D g2 = (java.awt.Graphics2D) g.create();
                g2.setRenderingHint(java.awt.RenderingHints.KEY_ANTIALIASING, java.awt.RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(colorCamposBlancos);
                g2.fillRoundRect(0, 0, getWidth(), getHeight(), 25, 25);
                g2.setColor(colorBordeSuave);
                g2.drawRoundRect(0, 0, getWidth() - 1, getHeight() - 1, 25, 25);
                g2.dispose();
                super.paintComponent(g);
            }
        };
        campoTextoUsuario.setPreferredSize(new Dimension(220, 38));
        campoTextoUsuario.setFont(fuenteCampos);
        campoTextoUsuario.setForeground(colorTextoEstilo);
        campoTextoUsuario.setOpaque(false);
        campoTextoUsuario.setBorder(javax.swing.BorderFactory.createEmptyBorder(5, 15, 5, 15));
        gbc.gridx = 1;
        gbc.gridy = 1;
        add(campoTextoUsuario, gbc);

        JLabel lblContrasenia = new JLabel("Contraseña");
        lblContrasenia.setFont(fuenteLabels);
        lblContrasenia.setForeground(colorTextoEstilo);
        gbc.gridx = 0;
        gbc.gridy = 2;
        add(lblContrasenia, gbc);

        campoTextoContrasenia = new JPasswordField() {
            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(colorCamposBlancos);
                g2.fillRoundRect(0, 0, getWidth(), getHeight(), 25, 25);
                g2.setColor(colorBordeSuave);
                g2.drawRoundRect(0, 0, getWidth() - 1, getHeight() - 1, 25, 25);
                g2.dispose();
                super.paintComponent(g);
            }
        };
        campoTextoContrasenia.setPreferredSize(new Dimension(220, 38));
        campoTextoContrasenia.setFont(fuenteCampos);
        campoTextoContrasenia.setForeground(colorTextoEstilo);
        campoTextoContrasenia.setOpaque(false);
        campoTextoContrasenia.setBorder(javax.swing.BorderFactory.createEmptyBorder(5, 15, 5, 15));
        gbc.gridx = 1;
        gbc.gridy = 2;
        add(campoTextoContrasenia, gbc);

        btnIngresar = new JButton("Ingresar") {
            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(colorAzulCapsula);
                g2.fillRoundRect(0, 0, getWidth(), getHeight(), 30, 30);
                g2.setColor(colorAzulCapsula.darker());
                g2.drawRoundRect(0, 0, getWidth() - 1, getHeight() - 1, 30, 30);
                g2.dispose();
                super.paintComponent(g);
            }
        };
        btnIngresar.setFont(new Font("Segoe UI", Font.BOLD, 16));
        btnIngresar.setForeground(colorTextoEstilo);
        btnIngresar.setPreferredSize(new Dimension(180, 42));
        btnIngresar.setContentAreaFilled(false);
        btnIngresar.setFocusPainted(false);
        btnIngresar.setBorderPainted(false);

        gbc.gridx = 0;
        gbc.gridy = 3;
        gbc.gridwidth = 2;
        gbc.anchor = GridBagConstraints.CENTER;
        gbc.fill = GridBagConstraints.NONE;
        gbc.insets = new Insets(28, 0, 0, 0);
        add(btnIngresar, gbc);
    }

    public String getUsuario() {
        return campoTextoUsuario.getText();
    }

    public String getContrasenia() {
        return new String(campoTextoContrasenia.getPassword());
    }

    public JButton getBtnIngresar() {
        return btnIngresar;
    }
    

public void limpiarCampos() {
    this.campoTextoUsuario.setText("");
    this.campoTextoContrasenia.setText("");
}

}
