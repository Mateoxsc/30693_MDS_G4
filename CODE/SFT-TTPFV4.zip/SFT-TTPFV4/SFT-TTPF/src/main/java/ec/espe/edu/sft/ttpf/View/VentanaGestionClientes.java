package ec.espe.edu.sft.ttpf.View;

import java.awt.*;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;

public class VentanaGestionClientes extends JFrame {

    private JTextField campoTextoCedulaCliente;
    private JTextField campoTextoNombreCliente;
    private JTextField campoTextoApellidoCliente;
    private JTextField campoTextoContactoCliente;

    private JButton botonAgregar;
    private JButton botonEditar;
    private JButton botonEliminar;
    private JButton botonBuscar;
    private JButton botonRegresarMenu;

    private JTable tablaClientes;
    private DefaultTableModel modeloTablaClientes;

    public VentanaGestionClientes() {
        java.awt.Color colorFondoBase = new java.awt.Color(245, 230, 226);
        java.awt.Color colorTarjetaBlanca = new java.awt.Color(253, 246, 244);
        java.awt.Color colorAzulBotones = new java.awt.Color(134, 203, 233);
        java.awt.Color colorRosaSalir = new java.awt.Color(243, 151, 151);
        java.awt.Color colorTextoEstilo = new java.awt.Color(84, 72, 70);
        java.awt.Color colorBordeInterno = new java.awt.Color(230, 212, 207);

        java.awt.Font fuenteLabels = new java.awt.Font("Segoe UI", java.awt.Font.BOLD, 12);
        java.awt.Font fuenteCampos = new java.awt.Font("Segoe UI", java.awt.Font.PLAIN, 13);
        java.awt.Font fuenteBotones = new java.awt.Font("Segoe UI", java.awt.Font.BOLD, 13);
        java.awt.Font fuenteTablas = new java.awt.Font("SansSerif", java.awt.Font.PLAIN, 13);
        java.awt.Font fuenteTitulado = new java.awt.Font("Segoe UI", java.awt.Font.BOLD, 14);

        setTitle("Gestionar Clientes");
        setSize(1200, 650);
        setLayout(new BorderLayout());
        getContentPane().setBackground(colorFondoBase);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        // Panel de datos del cliente superior
        JPanel panelDatos = new JPanel(new GridLayout(2, 4, 12, 12));
        panelDatos.setBackground(colorTarjetaBlanca);
        panelDatos.setPreferredSize(new Dimension(750, 110));

        javax.swing.border.TitledBorder bordeTitulo = javax.swing.BorderFactory.createTitledBorder(
                javax.swing.BorderFactory.createLineBorder(colorBordeInterno, 1, true), " Datos del Cliente "
        );
        bordeTitulo.setTitleFont(fuenteTitulado);
        bordeTitulo.setTitleColor(colorTextoEstilo);
        panelDatos.setBorder(bordeTitulo);

        JLabel lblCedula = new JLabel("  Cédula:");
        lblCedula.setFont(fuenteLabels);
        lblCedula.setForeground(colorTextoEstilo);
        panelDatos.add(lblCedula);
        campoTextoCedulaCliente = new JTextField();
        campoTextoCedulaCliente.setFont(fuenteCampos);
        campoTextoCedulaCliente.setForeground(colorTextoEstilo);
        panelDatos.add(campoTextoCedulaCliente);

        JLabel lblNombre = new JLabel("  Nombre:");
        lblNombre.setFont(fuenteLabels);
        lblNombre.setForeground(colorTextoEstilo);
        panelDatos.add(lblNombre);
        campoTextoNombreCliente = new JTextField();
        campoTextoNombreCliente.setFont(fuenteCampos);
        campoTextoNombreCliente.setForeground(colorTextoEstilo);
        panelDatos.add(campoTextoNombreCliente);

        JLabel lblApellido = new JLabel("  Apellido:");
        lblApellido.setFont(fuenteLabels);
        lblApellido.setForeground(colorTextoEstilo);
        panelDatos.add(lblApellido);
        campoTextoApellidoCliente = new JTextField();
        campoTextoApellidoCliente.setFont(fuenteCampos);
        campoTextoApellidoCliente.setForeground(colorTextoEstilo);
        panelDatos.add(campoTextoApellidoCliente);

        JLabel lblContacto = new JLabel("  Contacto:");
        lblContacto.setFont(fuenteLabels);
        lblContacto.setForeground(colorTextoEstilo);
        panelDatos.add(lblContacto);
        campoTextoContactoCliente = new JTextField();
        campoTextoContactoCliente.setFont(fuenteCampos);
        campoTextoContactoCliente.setForeground(colorTextoEstilo);
        panelDatos.add(campoTextoContactoCliente);

        // Panel de botones horizontal inferior de los datos
        JPanel panelBotones = new JPanel(new FlowLayout(FlowLayout.CENTER, 12, 15));
        panelBotones.setBackground(colorFondoBase);

        Dimension tamanoBotones = new Dimension(175, 40);

        botonAgregar = new JButton("Agregar Cliente");
        botonAgregar.setPreferredSize(tamanoBotones);
        botonAgregar.setFont(fuenteBotones);
        botonAgregar.setBackground(colorAzulBotones);
        botonAgregar.setForeground(colorTextoEstilo);
        botonAgregar.setFocusPainted(false);
        botonAgregar.setBorder(javax.swing.BorderFactory.createLineBorder(colorAzulBotones.darker(), 1, true));

        botonBuscar = new JButton("Buscar Cliente");
        botonBuscar.setPreferredSize(tamanoBotones);
        botonBuscar.setFont(fuenteBotones);
        botonBuscar.setBackground(colorAzulBotones);
        botonBuscar.setForeground(colorTextoEstilo);
        botonBuscar.setFocusPainted(false);
        botonBuscar.setBorder(javax.swing.BorderFactory.createLineBorder(colorAzulBotones.darker(), 1, true));

        botonEditar = new JButton("Editar Info. Cliente");
        botonEditar.setPreferredSize(tamanoBotones);
        botonEditar.setFont(fuenteBotones);
        botonEditar.setBackground(colorAzulBotones);
        botonEditar.setForeground(colorTextoEstilo);
        botonEditar.setFocusPainted(false);
        botonEditar.setBorder(javax.swing.BorderFactory.createLineBorder(colorAzulBotones.darker(), 1, true));

        botonEliminar = new JButton("Eliminar Cliente");
        botonEliminar.setPreferredSize(tamanoBotones);
        botonEliminar.setFont(fuenteBotones);
        botonEliminar.setBackground(colorAzulBotones);
        botonEliminar.setForeground(colorTextoEstilo);
        botonEliminar.setFocusPainted(false);
        botonEliminar.setBorder(javax.swing.BorderFactory.createLineBorder(colorAzulBotones.darker(), 1, true));

        botonRegresarMenu = new JButton("Regresar al menú");
        botonRegresarMenu.setPreferredSize(tamanoBotones);
        botonRegresarMenu.setFont(fuenteBotones);
        botonRegresarMenu.setBackground(colorRosaSalir);
        botonRegresarMenu.setForeground(colorTextoEstilo);
        botonRegresarMenu.setFocusPainted(false);
        botonRegresarMenu.setBorder(javax.swing.BorderFactory.createLineBorder(colorRosaSalir.darker(), 1, true));

        panelBotones.add(botonAgregar);
        panelBotones.add(botonBuscar);
        panelBotones.add(botonEditar);
        panelBotones.add(botonEliminar);
        panelBotones.add(botonRegresarMenu);

        JPanel panelSuperior = new JPanel(new BorderLayout());
        panelSuperior.setBackground(colorFondoBase);
        panelSuperior.setBorder(javax.swing.BorderFactory.createEmptyBorder(15, 20, 5, 20));
        panelSuperior.add(panelDatos, BorderLayout.CENTER);
        panelSuperior.add(panelBotones, BorderLayout.SOUTH);

        // Configuración de la Tabla con las columnas solicitadas
        String[] columnas = {"Cédula", "Nombre", "Apellido", "Contacto"};
        modeloTablaClientes = new DefaultTableModel(columnas, 0);
        tablaClientes = new JTable(modeloTablaClientes);

        tablaClientes.setFont(fuenteTablas);
        tablaClientes.setForeground(colorTextoEstilo);
        tablaClientes.setRowHeight(28);
        tablaClientes.setGridColor(colorBordeInterno);
        tablaClientes.setSelectionBackground(new java.awt.Color(205, 233, 245));
        tablaClientes.setSelectionForeground(colorTextoEstilo);

        tablaClientes.getTableHeader().setFont(fuenteBotones);
        tablaClientes.getTableHeader().setBackground(colorAzulBotones);
        tablaClientes.getTableHeader().setForeground(colorTextoEstilo);
        tablaClientes.getTableHeader().setReorderingAllowed(false);
        tablaClientes.getTableHeader().setBorder(javax.swing.BorderFactory.createLineBorder(colorAzulBotones));

        JScrollPane scrollPane = new JScrollPane(tablaClientes);
        scrollPane.setBorder(javax.swing.BorderFactory.createCompoundBorder(
                javax.swing.BorderFactory.createEmptyBorder(10, 20, 20, 20),
                javax.swing.BorderFactory.createLineBorder(colorBordeInterno, 1)
        ));
        scrollPane.getViewport().setBackground(colorTarjetaBlanca);

        add(panelSuperior, BorderLayout.NORTH);
        add(scrollPane, BorderLayout.CENTER);

        setLocationRelativeTo(null);
    }

    public JTextField getTxtCedulaCliente() {
        return campoTextoCedulaCliente;
    }

    public JTextField getTxtNombreCliente() {
        return campoTextoNombreCliente;
    }

    public JTextField getTxtApellidoCliente() {
        return campoTextoApellidoCliente;
    }

    public JTextField getTxtContactoCliente() {
        return campoTextoContactoCliente;
    }

    public JButton getBtnAgregar() {
        return botonAgregar;
    }

    public JButton getBtnBuscar() {
        return botonBuscar;
    }

    public JButton getBtnEditar() {
        return botonEditar;
    }

    public JButton getBtnEliminar() {
        return botonEliminar;
    }

    public JButton getBtnRegresar() {
        return botonRegresarMenu;
    }

    public JTable getTablaClientes() {
        return tablaClientes;
    }

    public DefaultTableModel getModeloTablaClientes() {
        return modeloTablaClientes;
    }
}
