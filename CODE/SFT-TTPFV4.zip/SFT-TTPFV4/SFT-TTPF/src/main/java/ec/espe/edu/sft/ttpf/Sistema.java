package ec.espe.edu.sft.ttpf;

import ec.espe.edu.sft.ttpf.Util.MensajesSistema;
import ec.espe.edu.sft.ttpf.Util.TituloVentanas;
import ec.espe.edu.sft.ttpf.View.VentanaAdministrador;
import ec.espe.edu.sft.ttpf.controller.AdministradorController;
import ec.espe.edu.sft.ttpf.model.Credenciales;
import java.awt.FlowLayout;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.Image;
import java.awt.HeadlessException;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import javax.swing.JOptionPane;
import javax.swing.Timer;

public class Sistema {

    private JFrame ventanaIniciarSesion;
    private JTextField txtUsuario;
    private JPasswordField txtContrasenia;
    private JButton botonIniciarSesion;

    private int intentosFallidos = 0;
    private boolean sistemaBloqueado = false;
    private int tiempoRestanteSegundos = 180;

    public void iniciar() {
        Color colorFondoBase = new Color(245, 230, 226);
        Color colorCamposBlancos = new Color(253, 246, 244);
        Color colorAzulCapsula = new Color(134, 203, 233);
        Color colorTextoEstilo = new Color(84, 72, 70);
        Color colorBordeSuave = new Color(220, 200, 195);

        ventanaIniciarSesion = new JFrame("Iniciar Sesión");
        ventanaIniciarSesion.setSize(450, 420);
        ventanaIniciarSesion.setLocationRelativeTo(null);
        ventanaIniciarSesion.setResizable(false);
        ventanaIniciarSesion.getContentPane().setBackground(colorFondoBase);
        ventanaIniciarSesion.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        ventanaIniciarSesion.setLayout(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(12, 15, 12, 15);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        Font fuenteTitulo = new Font("Segoe UI", Font.BOLD, 22);
        Font fuenteLabels = new Font("Segoe UI", Font.BOLD, 15);
        Font fuenteCampos = new Font("Segoe UI", Font.PLAIN, 15);

        JPanel panelHeader = new JPanel(new FlowLayout(FlowLayout.CENTER, 12, 0));
        panelHeader.setBackground(colorFondoBase);
        JLabel lblTitulo = new JLabel("INICIAR SESIÓN");
        lblTitulo.setFont(fuenteTitulo);
        lblTitulo.setForeground(colorTextoEstilo);
        panelHeader.add(lblTitulo);

        try {
            java.net.URL imgURL = getClass().getResource("/ec/espe/edu/sft/ttpf/imagenes/logo.png");
            if (imgURL != null) {
                ImageIcon iconoOriginal = new ImageIcon(imgURL);
                Image imagenRedim = iconoOriginal.getImage().getScaledInstance(45, 45, Image.SCALE_SMOOTH);
                JLabel lblLogo = new JLabel(new ImageIcon(imagenRedim));
                panelHeader.add(lblLogo);
            }
        } catch (Exception e) {
            System.out.println("Sugerencia: Coloca tu logo en la carpeta de imágenes para que se muestre.");
        }

        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.gridwidth = 2;
        gbc.anchor = GridBagConstraints.CENTER;
        ventanaIniciarSesion.add(panelHeader, gbc);

        gbc.gridwidth = 1;
        gbc.anchor = GridBagConstraints.WEST;
        JLabel lblUsuario = new JLabel("Usuario");
        lblUsuario.setFont(fuenteLabels);
        lblUsuario.setForeground(colorTextoEstilo);
        gbc.gridx = 0;
        gbc.gridy = 1;
        ventanaIniciarSesion.add(lblUsuario, gbc);

        txtUsuario = new JTextField() {
            @Override
            protected void paintComponent(java.awt.Graphics g) {
                java.awt.Graphics2D g2 = (java.awt.Graphics2D) g.create();
                g2.setRenderingHint(java.awt.RenderingHints.KEY_ANTIALIASING, java.awt.RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(colorCamposBlancos);
                g2.fillRoundRect(0, 0, getWidth(), getHeight(), 25, 25);
                g2.setColor(colorBordeSuave);
                g2.drawRoundRect(0, 0, getWidth() - 1, getHeight() - 1, 25, 25);
                g2.dispose();
                super.paintComponent(g);
            }
        };
        txtUsuario.setPreferredSize(new Dimension(220, 38));
        txtUsuario.setFont(fuenteCampos);
        txtUsuario.setForeground(colorTextoEstilo);
        txtUsuario.setOpaque(false);
        txtUsuario.setBorder(javax.swing.BorderFactory.createEmptyBorder(5, 15, 5, 15));
        gbc.gridx = 1;
        gbc.gridy = 1;
        ventanaIniciarSesion.add(txtUsuario, gbc);

        JLabel lblContrasenia = new JLabel("Contraseña");
        lblContrasenia.setFont(fuenteLabels);
        lblContrasenia.setForeground(colorTextoEstilo);
        gbc.gridx = 0;
        gbc.gridy = 2;
        ventanaIniciarSesion.add(lblContrasenia, gbc);

        txtContrasenia = new JPasswordField() {
            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(colorCamposBlancos);
                g2.fillRoundRect(0, 0, getWidth(), getHeight(), 25, 25);
                g2.setColor(colorBordeSuave);
                g2.drawRoundRect(0, 0, getWidth() - 1, getHeight() - 1, 25, 25);
                g2.dispose();
                super.paintComponent(g);
            }
        };
        txtContrasenia.setPreferredSize(new Dimension(220, 38));
        txtContrasenia.setFont(fuenteCampos);
        txtContrasenia.setForeground(colorTextoEstilo);
        txtContrasenia.setOpaque(false);
        txtContrasenia.setBorder(javax.swing.BorderFactory.createEmptyBorder(5, 15, 5, 15));
        gbc.gridx = 1;
        gbc.gridy = 2;
        ventanaIniciarSesion.add(txtContrasenia, gbc);

        botonIniciarSesion = new JButton("Ingresar") {
            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(colorAzulCapsula);
                g2.fillRoundRect(0, 0, getWidth(), getHeight(), 30, 30);
                g2.setColor(colorAzulCapsula.darker());
                g2.drawRoundRect(0, 0, getWidth() - 1, getHeight() - 1, 30, 30);
                g2.dispose();
                super.paintComponent(g);
            }
        };
        botonIniciarSesion.setFont(new Font("Segoe UI", Font.BOLD, 16));
        botonIniciarSesion.setForeground(colorTextoEstilo);
        botonIniciarSesion.setPreferredSize(new Dimension(180, 42));
        botonIniciarSesion.setContentAreaFilled(false);
        botonIniciarSesion.setFocusPainted(false);
        botonIniciarSesion.setBorderPainted(false);

        botonIniciarSesion.addActionListener(e -> validacionLoggin(txtUsuario.getText(), new String(txtContrasenia.getPassword())));

        gbc.gridx = 0;
        gbc.gridy = 3;
        gbc.gridwidth = 2;
        gbc.anchor = GridBagConstraints.CENTER;
        gbc.fill = GridBagConstraints.NONE;
        gbc.insets = new Insets(28, 0, 0, 0);
        ventanaIniciarSesion.add(botonIniciarSesion, gbc);

        this.ventanaIniciarSesion.setVisible(true);
    }

    private void validacionLoggin(String usuario, String contrasenia) {
        if (sistemaBloqueado) {
            mostrarMensajeBloqueo();
            return;
        }
        try {
            if (usuario == null || usuario.isBlank() || contrasenia == null || contrasenia.isBlank()) {
                JOptionPane.showMessageDialog(null, MensajesSistema.ERROR_CAMPOS_VACIOS, TituloVentanas.VENTANA_ADVERTENCIA, JOptionPane.WARNING_MESSAGE);
                return;
            }

            // CASO 1: Es Administrador
            if (usuario.equals(Credenciales.USUARIO_ADMIN) && contrasenia.equals(Credenciales.CONTRASENIA_ADMIN)) {
                JOptionPane.showMessageDialog(null, MensajesSistema.EXITO_LOGGIN, TituloVentanas.VENTANA_INICIO, JOptionPane.INFORMATION_MESSAGE);
                this.intentosFallidos = 0;

                limpiarCampos();
                ventanaIniciarSesion.setVisible(false);

                VentanaAdministrador vAdmin = new VentanaAdministrador();
                new AdministradorController(vAdmin, ventanaIniciarSesion);
                vAdmin.setVisible(true);

            } else if (usuario.equals(Credenciales.USUARIO_COLAB_1) && contrasenia.equals(Credenciales.CONTRASENIA_COLAB_1)) {
                JOptionPane.showMessageDialog(null, MensajesSistema.EXITO_LOGGIN, TituloVentanas.VENTANA_INICIO, JOptionPane.INFORMATION_MESSAGE);
                this.intentosFallidos = 0;

                limpiarCampos();
                ventanaIniciarSesion.setVisible(false);

                ec.espe.edu.sft.ttpf.View.VentanaColaborador vColab = new ec.espe.edu.sft.ttpf.View.VentanaColaborador();
                new ec.espe.edu.sft.ttpf.controller.ColaboradorController(vColab, ventanaIniciarSesion);
                vColab.setVisible(true);

            } else {
                this.intentosFallidos++;

                limpiarCampos();
                txtUsuario.requestFocus();

                if (this.intentosFallidos >= 3) {
                    iniciarContadorBloqueo();
                } else {
                    int intentosRestantes = 3 - this.intentosFallidos;
                    JOptionPane.showMessageDialog(null, MensajesSistema.ERROR_USUARIO_O_CONTRASENIA + "\n" + MensajesSistema.INFO_INTENTOS_RESTANTES + ": " + intentosRestantes, TituloVentanas.VENTANA_ERROR, JOptionPane.ERROR_MESSAGE);
                }
            }
        } catch (HeadlessException ex) {
            JOptionPane.showMessageDialog(null, MensajesSistema.ERROR_DESCONOCIDO_LOGGIN, TituloVentanas.VENTANA_ERROR, JOptionPane.ERROR_MESSAGE);
        }
    }

    private void iniciarContadorBloqueo() {
        this.sistemaBloqueado = true;
        this.botonIniciarSesion.setEnabled(false);
        this.tiempoRestanteSegundos = 180;
        mostrarMensajeBloqueo();
        Timer timer = new Timer(1000, null);
        timer.addActionListener(e -> {
            this.tiempoRestanteSegundos--;
            if (this.tiempoRestanteSegundos <= 0) {
                this.sistemaBloqueado = false;
                this.intentosFallidos = 0;
                this.botonIniciarSesion.setEnabled(true);
                this.botonIniciarSesion.setText("Ingresar");
                timer.stop();
                JOptionPane.showMessageDialog(null, "Sistema desbloqueado. Puede intentar de nuevo.", TituloVentanas.VENTANA_INICIO, JOptionPane.INFORMATION_MESSAGE);
            } else {
                int minutes = this.tiempoRestanteSegundos / 60;
                int segundos = this.tiempoRestanteSegundos % 60;
                this.botonIniciarSesion.setText(String.format("Bloqueado (%02d:%02d)", minutes, segundos));
            }
        });
        timer.start();
    }

    private void mostrarMensajeBloqueo() {
        int minutes = this.tiempoRestanteSegundos / 60;
        int segundos = this.tiempoRestanteSegundos % 60;
        JOptionPane.showMessageDialog(null, MensajesSistema.ERROR_LIMITE_DE_INTENTOS_LOGGIN + " " + String.format("%02d:%02d", minutes, segundos), TituloVentanas.VENTANA_ERROR, JOptionPane.ERROR_MESSAGE);
    }

    public void limpiarCampos() {
        this.txtUsuario.setText("");
        this.txtContrasenia.setText("");
    }
}
