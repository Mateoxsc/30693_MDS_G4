package ec.espe.edu.sft.ttpf.controller;

import ec.espe.edu.sft.ttpf.View.VentanaAdministrador;
import ec.espe.edu.sft.ttpf.View.VentanaGestionColaboradores;
import ec.espe.edu.sft.ttpf.View.VentanaGestionClientes;
import ec.espe.edu.sft.ttpf.View.VentanaGestionReservas;
import ec.espe.edu.sft.ttpf.View.VentanaIniciarSesion; // Importación necesaria
import ec.espe.edu.sft.ttpf.model.Empleado;
import java.util.ArrayList;
import javax.swing.JFrame;

public class AdministradorController {

    private VentanaAdministrador vista;
    private JFrame ventanaIniciarSesion;

    private ArrayList<Empleado> listaColaboradores = new ArrayList<>();

    // CONSTRUCTOR 1: Se usa desde LoginController (Recibe la ventana de Login existente)
    public AdministradorController(VentanaAdministrador vista, JFrame ventanaIniciarSesion) {
        this.vista = vista;
        this.ventanaIniciarSesion = ventanaIniciarSesion;
        inicializarEventos();
    }

    public AdministradorController(VentanaAdministrador vista) {
        this.vista = vista;
        this.ventanaIniciarSesion = null;
        inicializarEventos();
    }

    private void inicializarEventos() {
        vista.getBotonGestionColaboradores().addActionListener(e -> abrirGestionColaboradores());
        vista.getBotonGestionClientes().addActionListener(e -> abrirGestionClientes());
        vista.getBotonGestionReservas().addActionListener(e -> abrirGestionReservas());
        vista.getBotonSalir().addActionListener(e -> cerrarSesion());
    }

    private void abrirGestionColaboradores() {
        vista.setVisible(false);
        VentanaGestionColaboradores vistaColab = new VentanaGestionColaboradores();
        new ColaboradoresController(vistaColab, vista, listaColaboradores);
        vistaColab.setVisible(true);
    }

    private void abrirGestionClientes() {
        vista.setVisible(false);
        VentanaGestionClientes vistaClientes = new VentanaGestionClientes();
        new ClientesController(vistaClientes, vista);
        vistaClientes.setVisible(true);
    }

    private void abrirGestionReservas() {
        vista.setVisible(false);
        VentanaGestionReservas vistaReservas = new VentanaGestionReservas();
        new ReservasController(vistaReservas, vista);
        vistaReservas.setVisible(true);
    }

    private void cerrarSesion() {
        vista.dispose();

        if (this.ventanaIniciarSesion != null) {
            this.ventanaIniciarSesion.setVisible(true);
        } else {
            VentanaIniciarSesion nuevoLogin = new VentanaIniciarSesion();
            new LoginController(nuevoLogin);
            nuevoLogin.setVisible(true);
        }
    }
}
