package ec.espe.edu.sft.ttpf.controller;

import ec.espe.edu.sft.ttpf.View.VentanaGestionClientes;
import javax.swing.JFrame; // <-- IMPORTANTE: Agregamos la importación de JFrame

public class ClientesController {

    private VentanaGestionClientes vista;
    private JFrame vPadre; // <-- CAMBIO: De 'VentanaAdministrador' a 'JFrame' para soportar ambos roles

    // CAMBIO: El segundo parámetro ahora acepta cualquier JFrame (Admin o Colaborador)
    public ClientesController(VentanaGestionClientes vista, JFrame vPadre) {
        this.vista = vista;
        this.vPadre = vPadre;

        inicializarEventos();
    }

    private void inicializarEventos() {
        // Evento para el botón regresar
        this.vista.getBtnRegresar().addActionListener(e -> {
            this.vista.dispose();
            if (this.vPadre != null) {
                this.vPadre.setVisible(true); // Reabre dinámicamente la ventana que lo invocó
            }
        });

        // Aquí enlazarás los métodos de la lógica para el CRUD de clientes en el futuro:
        // this.vista.getBtnAgregar().addActionListener(e -> agregarCliente());
        // this.vista.getBtnEditar().addActionListener(e -> editarCliente());
        // this.vista.getBtnEliminar().addActionListener(e -> eliminarCliente());
        // this.vista.getBtnBuscar().addActionListener(e -> buscarCliente());
    }
}