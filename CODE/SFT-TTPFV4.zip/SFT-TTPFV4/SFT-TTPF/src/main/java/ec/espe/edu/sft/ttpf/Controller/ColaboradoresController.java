package ec.espe.edu.sft.ttpf.controller;

import ec.espe.edu.sft.ttpf.View.VentanaGestionColaboradores;
import ec.espe.edu.sft.ttpf.View.VentanaAdministrador;
import ec.espe.edu.sft.ttpf.Util.MensajesSistema;
import ec.espe.edu.sft.ttpf.Util.TituloVentanas;
import ec.espe.edu.sft.ttpf.model.Empleado;
import java.util.ArrayList;
import javax.swing.JOptionPane;

public class ColaboradoresController {

    private VentanaGestionColaboradores vista;
    private VentanaAdministrador ventanaAdministrador;
    private ArrayList<Empleado> listaColaboradores;

    public ColaboradoresController(VentanaGestionColaboradores vista, VentanaAdministrador ventanaAdministrador, ArrayList<Empleado> listaColaboradores) {
        this.vista = vista;
        this.ventanaAdministrador = ventanaAdministrador;
        this.listaColaboradores = listaColaboradores;
        inicializarEventos();
    }

    private void inicializarEventos() {
        vista.getBtnAgregar().addActionListener(e -> agregarColaborador());
        vista.getBtnBuscar().addActionListener(e -> buscarColaborador());
        vista.getBtnEditar().addActionListener(e -> editarColaborador());
        vista.getBtnEliminar().addActionListener(e -> eliminarColaborador());

        vista.getBotonSalirColaborador().addActionListener(e -> {
            vista.dispose();
            ventanaAdministrador.setVisible(true);
        });
    }

    // === TU LOGICA IDENTICA DE AGREGAR ===
    private void agregarColaborador() {
        String nombre = vista.getTxtNombreColaborador().getText().trim();
        String cedulaStr = vista.getTxtCedulaColaborador().getText().trim();
        String usuario = vista.getTxtUsuarioColaborador().getText().trim();
        String contrasenia = new String(vista.getTxtContraseniaColaborador().getPassword()).trim();

        if (nombre.isBlank() || cedulaStr.isBlank() || usuario.isBlank() || contrasenia.isBlank()) {
            JOptionPane.showMessageDialog(null, MensajesSistema.ERROR_CAMPOS_VACIOS, TituloVentanas.VENTANA_ADVERTENCIA, JOptionPane.WARNING_MESSAGE);
            return;
        }

        if (!ec.espe.edu.sft.ttpf.Util.ValidacionCrearUsuarioCliente.validarCedula(cedulaStr)) {
            JOptionPane.showMessageDialog(null, MensajesSistema.ERROR_CEDULA_INVALIDA, TituloVentanas.VENTANA_ERROR, JOptionPane.ERROR_MESSAGE);
            return;
        }

        int cedulaInt;
        try {
            cedulaInt = Integer.parseInt(cedulaStr);
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(null, MensajesSistema.ERROR_CEDULA_SOLO_NUMEROS, TituloVentanas.VENTANA_ERROR, JOptionPane.ERROR_MESSAGE);
            return;
        }

        for (Empleado colab : listaColaboradores) {
            if (colab.getCedula() == cedulaInt) {
                JOptionPane.showMessageDialog(null, MensajesSistema.ERROR_CEDULA_DUPLICADA, TituloVentanas.VENTANA_ERROR, JOptionPane.ERROR_MESSAGE);
                return;
            }
            if (colab.getUsuario().equals(usuario)) {
                JOptionPane.showMessageDialog(null, MensajesSistema.ERROR_USUARIO_DUPLICADO, TituloVentanas.VENTANA_ERROR, JOptionPane.ERROR_MESSAGE);
                return;
            }
        }

        String telefonoInput = vista.getTxtTelefonoColaborador().getText().trim();

        if (!telefonoInput.matches("^0\\d{9}$")) {
            JOptionPane.showMessageDialog(null,
                    "El número de teléfono no es válido.\nDebe comenzar con '0' y tener exactamente 10 dígitos.",
                    "Error de Validación",
                    JOptionPane.ERROR_MESSAGE);
            return;
        }

        Empleado nuevoColaborador = new Empleado(
                cedulaInt,
                nombre,
                "",
                "",
                usuario,
                contrasenia,
                telefonoInput
        );

        listaColaboradores.add(nuevoColaborador);

        vista.getModeloTablaColaboradores().addRow(new Object[]{
            String.valueOf(cedulaInt),
            nombre,
            usuario,
            contrasenia,
            nuevoColaborador.getTelefono()
        });

        vista.getTxtNombreColaborador().setText("");
        vista.getTxtCedulaColaborador().setText("");
        vista.getTxtUsuarioColaborador().setText("");
        vista.getTxtContraseniaColaborador().setText("");
        vista.getTxtTelefonoColaborador().setText("");

        JOptionPane.showMessageDialog(null, MensajesSistema.EXITO_COLABORADOR_AGREGADO, TituloVentanas.VENTANA_INFO, JOptionPane.INFORMATION_MESSAGE);
    }

    // === TU LOGICA IDENTICA DE BUSCAR ===
    private void buscarColaborador() {
        String cedulaBuscar = JOptionPane.showInputDialog(null, MensajesSistema.INFO_INGRESO_CEDULA_BUSCAR, "Buscar Credenciales", JOptionPane.QUESTION_MESSAGE);

        if (cedulaBuscar == null || cedulaBuscar.trim().isEmpty()) {
            return;
        }

        int cedulaBusqueda;
        try {
            cedulaBusqueda = Integer.parseInt(cedulaBuscar.trim());
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(null, MensajesSistema.ERROR_CEDULA_SOLO_NUMEROS, TituloVentanas.VENTANA_ERROR, JOptionPane.ERROR_MESSAGE);
            return;
        }

        for (Empleado colab : listaColaboradores) {
            if (colab.getCedula() == cedulaBusqueda) {
                String info = "Información del Colaborador:\n\n"
                        + "Nombre: " + colab.getNombre() + "\n"
                        + "Cédula: " + colab.getCedula() + "\n"
                        + "Usuario: " + colab.getUsuario() + "\n"
                        + "Contraseña: " + colab.getContrasenia();
                JOptionPane.showMessageDialog(null, info, "Credenciales Encontradas", JOptionPane.INFORMATION_MESSAGE);
                return;
            }
        }

        JOptionPane.showMessageDialog(null, MensajesSistema.ADVERTENCIA_COLABORADOR_NO_ENCONTRADO, TituloVentanas.VENTANA_ADVERTENCIA, JOptionPane.WARNING_MESSAGE);
    }

    // === TU LOGICA IDENTICA DE EDITAR ===
    private void editarColaborador() {
        String cedulaBuscar = JOptionPane.showInputDialog(vista,
                "Ingrese la Cédula del colaborador a editar:",
                "Editar Colaborador",
                JOptionPane.QUESTION_MESSAGE);

        if (cedulaBuscar == null) {
            return;
        }

        cedulaBuscar = cedulaBuscar.trim();
        if (cedulaBuscar.isEmpty()) {
            JOptionPane.showMessageDialog(vista, "Debe ingresar una cédula para buscar.", "Error", JOptionPane.WARNING_MESSAGE);
            return;
        }

        int filaEncontrada = -1;
        for (int i = 0; i < vista.getTablaColaboradores().getRowCount(); i++) {
            String cedulaTabla = vista.getTablaColaboradores().getValueAt(i, 0).toString().trim();
            if (cedulaTabla.equals(cedulaBuscar)) {
                filaEncontrada = i;
                break;
            }
        }

        if (filaEncontrada == -1) {
            JOptionPane.showMessageDialog(vista, "El colaborador con cédula " + cedulaBuscar + " no está registrado.", "No Encontrado", JOptionPane.ERROR_MESSAGE);
            return;
        }

        String nombreActual = vista.getTablaColaboradores().getValueAt(filaEncontrada, 1).toString();
        String usuarioActual = vista.getTablaColaboradores().getValueAt(filaEncontrada, 2).toString();
        String contraseniaActual = vista.getTablaColaboradores().getValueAt(filaEncontrada, 3).toString();
        String telefonoActual = vista.getTablaColaboradores().getValueAt(filaEncontrada, 4).toString();

        javax.swing.JDialog formularioEditar = new javax.swing.JDialog(vista, "Formulario de Edición", true);
        formularioEditar.setSize(380, 280);
        formularioEditar.setLocationRelativeTo(vista);
        formularioEditar.setLayout(new java.awt.GridLayout(6, 2, 10, 10));

        javax.swing.JTextField txtNuevoNombre = new javax.swing.JTextField(nombreActual);
        javax.swing.JTextField txtNuevoUsuario = new javax.swing.JTextField(usuarioActual);
        javax.swing.JTextField txtNuevaContrasenia = new javax.swing.JTextField(contraseniaActual);
        javax.swing.JTextField txtNuevoTelefono = new javax.swing.JTextField(telefonoActual);

        formularioEditar.add(new javax.swing.JLabel("  Nombre Completo:"));
        formularioEditar.add(txtNuevoNombre);
        formularioEditar.add(new javax.swing.JLabel("  Usuario:"));
        formularioEditar.add(txtNuevoUsuario);
        formularioEditar.add(new javax.swing.JLabel("  Contraseña:"));
        formularioEditar.add(txtNuevaContrasenia);
        formularioEditar.add(new javax.swing.JLabel("  Teléfono:"));
        formularioEditar.add(txtNuevoTelefono);

        javax.swing.JButton btnGuardar = new javax.swing.JButton("Guardar");
        javax.swing.JButton btnSalir = new javax.swing.JButton("Salir");

        formularioEditar.add(btnGuardar);
        formularioEditar.add(btnSalir);

        final int filaPosicion = filaEncontrada;

        btnGuardar.addActionListener(e -> {
            String nombre = txtNuevoNombre.getText().trim();
            String usuario = txtNuevoUsuario.getText().trim();
            String contrasenia = txtNuevaContrasenia.getText().trim();
            String telefono = txtNuevoTelefono.getText().trim();

            if (nombre.isEmpty() || usuario.isEmpty() || contrasenia.isEmpty() || telefono.isEmpty()) {
                JOptionPane.showMessageDialog(formularioEditar, "Error: No se pueden guardar campos vacíos.", "Campos Vacíos", JOptionPane.WARNING_MESSAGE);
                return;
            }

            if (!telefono.matches("^0\\d{9}$")) {
                JOptionPane.showMessageDialog(formularioEditar,
                        "El número de teléfono no es válido.\nDebe comenzar con '0' y tener exactamente 10 dígitos.",
                        "Error de Validación",
                        JOptionPane.ERROR_MESSAGE);
                return;
            }

            vista.getModeloTablaColaboradores().setValueAt(nombre, filaPosicion, 1);
            vista.getModeloTablaColaboradores().setValueAt(usuario, filaPosicion, 2);
            vista.getModeloTablaColaboradores().setValueAt(contrasenia, filaPosicion, 3);
            vista.getModeloTablaColaboradores().setValueAt(telefono, filaPosicion, 4);

            if (filaPosicion < listaColaboradores.size()) {
                Empleado emp = listaColaboradores.get(filaPosicion);
                // Mantenemos tu asignación lógica
            }

            JOptionPane.showMessageDialog(vista, "Cambios guardados exitosamente", "Éxito", JOptionPane.INFORMATION_MESSAGE);
            formularioEditar.dispose();
        });

        btnSalir.addActionListener(e -> {
            formularioEditar.dispose();
        });

        formularioEditar.setVisible(true);
    }

    // === TU LOGICA IDENTICA DE ELIMINAR ===
    private void eliminarColaborador() {
        String cedulaEliminar = JOptionPane.showInputDialog(null, MensajesSistema.INFO_INGRESO_CEDULA_ELIMINAR, "Eliminar Colaborador", JOptionPane.QUESTION_MESSAGE);

        if (cedulaEliminar == null || cedulaEliminar.trim().isEmpty()) {
            return;
        }

        int cedulaBusqueda;
        try {
            cedulaBusqueda = Integer.parseInt(cedulaEliminar.trim());
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(null, MensajesSistema.ERROR_CEDULA_SOLO_NUMEROS, TituloVentanas.VENTANA_ERROR, JOptionPane.ERROR_MESSAGE);
            return;
        }

        boolean encontrado = false;
        for (int i = 0; i < listaColaboradores.size(); i++) {
            if (listaColaboradores.get(i).getCedula() == cedulaBusqueda) {
                encontrado = true;

                int confirmacion = JOptionPane.showConfirmDialog(null, MensajesSistema.CONFIRMACION_ELIMINAR_COLABORADOR + cedulaBusqueda + "?", "Confirmar Eliminación", JOptionPane.YES_NO_OPTION);

                if (confirmacion == JOptionPane.YES_OPTION) {
                    listaColaboradores.remove(i);
                    vista.getModeloTablaColaboradores().removeRow(i);

                    JOptionPane.showMessageDialog(null, MensajesSistema.EXITO_COLABORADOR_ELIMINADO, TituloVentanas.VENTANA_INFO, JOptionPane.INFORMATION_MESSAGE);
                }
                break;
            }
        }

        if (!encontrado) {
            JOptionPane.showMessageDialog(null, MensajesSistema.ADVERTENCIA_COLABORADOR_NO_ENCONTRADO, TituloVentanas.VENTANA_ADVERTENCIA, JOptionPane.WARNING_MESSAGE);
        }
    }
}
