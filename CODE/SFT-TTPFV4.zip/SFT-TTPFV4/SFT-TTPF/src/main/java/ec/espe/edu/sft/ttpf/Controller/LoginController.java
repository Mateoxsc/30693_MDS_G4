package ec.espe.edu.sft.ttpf.controller;

import ec.espe.edu.sft.ttpf.Util.MensajesSistema;
import ec.espe.edu.sft.ttpf.Util.TituloVentanas;
import ec.espe.edu.sft.ttpf.View.VentanaIniciarSesion;
import ec.espe.edu.sft.ttpf.View.VentanaAdministrador;
import ec.espe.edu.sft.ttpf.View.VentanaColaborador; 
import ec.espe.edu.sft.ttpf.model.Credenciales;
import javax.swing.JOptionPane;
import javax.swing.SwingUtilities;

public class LoginController {

    private VentanaIniciarSesion vista;

    public LoginController(VentanaIniciarSesion vista) {
        this.vista = vista;
        inicializarEventos();
    }

    private void inicializarEventos() {
        this.vista.getBtnIngresar().addActionListener(e -> validarAcceso());
    }

  private void validarAcceso() {
    String usuario = vista.getUsuario();
    String contrasenia = vista.getContrasenia();

    // CASO 1: Administrador
    if (usuario.equals(Credenciales.USUARIO_ADMIN) && contrasenia.equals(Credenciales.CONTRASENIA_ADMIN)) {
        vista.limpiarCampos(); 
        vista.setVisible(false);

        VentanaAdministrador vistaAdmin = new VentanaAdministrador();
        new AdministradorController(vistaAdmin, vista);
        vistaAdmin.setVisible(true);

    // CASO 2: Colaborador
    } else if (usuario.equals(Credenciales.USUARIO_COLAB_1) && contrasenia.equals(Credenciales.CONTRASENIA_COLAB_1)) {
        vista.limpiarCampos(); 
        vista.setVisible(false); // Ocultamos el login

        SwingUtilities.invokeLater(() -> {
            VentanaColaborador vistaColab = new VentanaColaborador();
            new ColaboradorController(vistaColab, vista); 
            
            // Asegura que los subcomponentes internos calculen bien sus tamaños estéticos
            vistaColab.revalidate();
            vistaColab.repaint();
            vistaColab.setVisible(true); 
        });

    } else {
        JOptionPane.showMessageDialog(vista, MensajesSistema.ERROR_USUARIO_O_CONTRASENIA, TituloVentanas.VENTANA_ERROR, JOptionPane.ERROR_MESSAGE);
        vista.limpiarCampos(); 
    }
}
}