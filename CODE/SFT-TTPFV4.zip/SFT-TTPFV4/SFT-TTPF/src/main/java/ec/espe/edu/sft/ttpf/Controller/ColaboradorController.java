package ec.espe.edu.sft.ttpf.controller;

import ec.espe.edu.sft.ttpf.View.VentanaColaborador;
import ec.espe.edu.sft.ttpf.View.VentanaGestionClientes;
import javax.swing.JFrame; // <-- CORRECCIÓN 1: Importamos JFrame genérico

public class ColaboradorController {

    private VentanaColaborador vista;
    private JFrame vLoginPadre; // <-- CORRECCIÓN 1: Cambiado a JFrame para acoplarse a tu clase Sistema

    // El constructor ahora acepta el JFrame de tu login sin lanzar error de tipos incompatibles
    public ColaboradorController(VentanaColaborador vista, JFrame vLoginPadre) {
        this.vista = vista;
        this.vLoginPadre = vLoginPadre;
        inicializarEventos();
    }

    private void inicializarEventos() {
        this.vista.getBotonGestionClientes().addActionListener(e -> {
            this.vista.setVisible(false);
            VentanaGestionClientes vClientes = new VentanaGestionClientes();

            // <-- CORRECCIÓN 2: Pasamos 'this.vista' en lugar de 'null' 
            // para que el ClientesController sepa a qué ventana regresar
            new ClientesController(vClientes, this.vista); 
            vClientes.setVisible(true);
        });

        this.vista.getBotonGestionReservas().addActionListener(e -> {
            // Lógica futura para la gestión de reservas
        });

        this.vista.getBotonSalir().addActionListener(e -> {
            this.vista.dispose();
            if (this.vLoginPadre != null) {
                this.vLoginPadre.setVisible(true); // Regresa con éxito al Login de la clase Sistema
            }
        });
    }
}